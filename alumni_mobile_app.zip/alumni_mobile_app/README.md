# Alumni Portal — Flutter client

Flutter mobile client for the PHP **Alumni Tracking System**, built on the
`mobile_api_demo` architecture (config → `ApiService` → feature services → models → pages,
`ValueNotifier` state, bottom navigation, light/dark mode).

It talks to the PHP backend only through HTTP (`/Api/...`); it never touches MySQL.
Full backend setup, API contract, security notes and limitations are in the
backend project: `alumni_tracking_system/MOBILE_INTEGRATION.md` and `docs/API.md`.

## Run
1. Start Apache + MySQL (XAMPP), apply `migrations/001_mobile_api.sql` in the backend.
2. `copy .env.example .env` and set `API_BASE_URL`
   (emulator `http://10.0.2.2/alumni_tracking_system/Api`; physical phone `http://<PC LAN IP>/alumni_tracking_system/Api`).
3. `flutter pub get` then `flutter run`.
4. Log in with an existing **Alumni** account from the web portal.

## Features
Login/logout (secure token storage) · Dashboard · Educational background · Employment ·
Licensures and professional examination history (managed together) · Trainings & advanced studies (list/add/edit/delete) ·
Announcements · Job opportunities · Events (register/cancel) · Tracer surveys (custom studies) ·
Profile view/edit · Change password. The 13-section CHED GTS survey is completed in the web portal (for now).

## Architecture (what changed from the demo)
| Demo convention | Here |
|---|---|
| `lib/config/api_config.dart` + `.env` | kept; fallback now the alumni emulator URL |
| `lib/services/api_service.dart` ("Do not Modify") | **untouched**; auth is injected via `AuthClient` (an `http.Client`) |
| `XxxService(api)` + `XxxModel.fromJson` | same, one pair per alumni feature |
| `views/pages/<feature>/index.dart, add.dart, edit.dart` | `index.dart` + a single `form.dart` for add **and** edit (generic `RecordListPage` / `FormScaffold` widgets) |
| `selectedPageNotifier`, `isDarkModeNotifier` | kept; added `sessionNotifier` (null ⇒ login page) |
| Students/Courses | removed (demo-specific) |

`AuthClient` adds `Authorization: Bearer`, signs the user out on an expired token, and lets
`ApiService` surface the server's own error text instead of "HTTP 401".

## Checks
- `flutter analyze`
- `flutter test`
- `flutter test integration_test/alumni_flow_test.dart -d <device> --dart-define=ALUMNI_USER=… --dart-define=ALUMNI_PASS=…`
  (live; uses a test account, creates and deletes one `ZZ-TEST-EXAM-…` record)

Debug builds allow `http://` for local XAMPP; release builds require HTTPS.
