import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/auth_service.dart';
import 'package:alumni_mobile_app/services/exam_service.dart';
import 'package:alumni_mobile_app/services/profile_service.dart';
import 'package:alumni_mobile_app/services/token_store.dart';

const baseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2/alumni_tracking_system/Api',
);
const user = String.fromEnvironment('ALUMNI_USER');
const pass = String.fromEnvironment('ALUMNI_PASS');

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  test('login, read, write, logout, and access is revoked', () async {
    expect(user.isNotEmpty && pass.isNotEmpty, true,
        reason: 'Pass --dart-define=ALUMNI_USER and ALUMNI_PASS.');
    final store = MemoryTokenStore();
    final api = ApiService(baseUrl: baseUrl, client: AuthClient(store));
    addTearDown(api.close);
    final auth = AuthService(api, store);

    // 1. wrong password rejected with the server message
    await expectLater(
      auth.login(user, 'definitely-wrong-password'),
      throwsA(predicate((e) => '$e'.contains('Invalid username or password'))),
    );
    expect(await store.read(), isNull);

    // 2. protected endpoint without a token is rejected
    await expectLater(api.request('Profile/details'), throwsException);

    // 3. valid login
    final me = await auth.login(user, pass);
    expect(me.role, 'Alumni');
    expect(await store.read(), isNotNull);

    // 4. read own profile
    final profile = await ProfileService(api).getDetails();
    expect(profile.firstName, isNotEmpty);

    // 5. write -> read back -> delete
    final name = 'ZZ-TEST-EXAM-${DateTime.now().millisecondsSinceEpoch}';
    final exams = ExamService(api);
    await exams.add(name: name, result: 'Pending');
    final created = (await exams.getAll()).firstWhere((e) => e.name == name);
    await exams.delete(created.id);
    expect((await exams.getAll()).any((e) => e.name == name), false);

    // 6. logout revokes the token server-side
    final oldToken = (await store.read())!;
    await auth.logout();
    expect(await store.read(), isNull);
    await store.write(oldToken);
    await expectLater(api.request('Profile/details'), throwsException);
  });
}
