import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/services/academic_service.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/employment_service.dart';
import 'package:alumni_mobile_app/services/exam_service.dart';
import 'package:alumni_mobile_app/services/feed_service.dart';
import 'package:alumni_mobile_app/services/licensure_service.dart';
import 'package:alumni_mobile_app/services/profile_service.dart';
import 'package:alumni_mobile_app/services/tracer_service.dart';
import 'package:alumni_mobile_app/services/training_service.dart';
import 'helpers.dart';

const base = '/alumni_tracking_system/Api';

(ApiService, List<http.Request>) mock([Object? body]) {
  final log = <http.Request>[];
  final api = ApiService(
    baseUrl: 'http://localhost$base',
    client: MockClient((r) async {
      log.add(r);
      return jsonResponse(
        body ?? {'status': 'success', 'success': true, 'message': 'Saved'},
      );
    }),
  );
  addTearDown(api.close);
  return (api, log);
}

void main() {
  test('Employments: list route, add/edit POST form, delete POST', () async {
    final (api, log) = mock();
    final svc = EmploymentService(api);
    const input = EmploymentInput(
      statusId: 2,
      employer: 'ACME',
      tenureId: 3,
      relatedToDegree: true,
      isCurrent: true,
      dateHired: '2024-01-05',
      dateEnded: '2025-01-01', // must be dropped for a current job
    );
    await svc.add(input);
    expect(log.last.url.path, '$base/Employments/add');
    expect(log.last.method, 'POST');
    expect(log.last.bodyFields['employment_status_id'], '2');
    expect(log.last.bodyFields['employment_type_id'], '3');
    expect(log.last.bodyFields['industry_id'], '');
    expect(log.last.bodyFields['related_to_degree'], '1');
    expect(log.last.bodyFields['is_current'], '1');
    expect(log.last.bodyFields['date_ended'], '');
    await svc.update(9, input);
    expect(log.last.url.path, '$base/Employments/edit/9');
    await svc.delete(9);
    expect(log.last.url.path, '$base/Employments/delete/9');
    expect(log.last.method, 'POST');
  });

  test('Employments list parses {data: [...]}', () async {
    final (api, log) = mock({
      'data': [
        {'id': 1, 'employment_status_id': 1, 'status_name': 'Employed'},
      ],
    });
    final rows = await EmploymentService(api).getAll();
    expect(rows.single.statusName, 'Employed');
    expect(log.single.url.path, '$base/Employments/all');
    expect(log.single.method, 'GET');
  });

  test('Academics / Licensures / Exams / Trainings form fields', () async {
    final (api, log) = mock();
    await AcademicService(api).add(programId: 3, graduationYear: 2020, major: 'Web');
    expect(log.last.url.path, '$base/Academics/add');
    expect(log.last.bodyFields, {
      'program_id': '3', 'graduation_year': '2020', 'major': 'Web', 'batch': '', 'student_id': '',
    });

    await LicensureService(api).update(5, licenseTypeId: 2, statusId: 1, examinationYear: '2021');
    expect(log.last.url.path, '$base/Licensures/edit/5');
    expect(log.last.bodyFields, {'license_type_id': '2', 'status_id': '1', 'examination_year': '2021'});

    await ExamService(api).add(name: 'LET', result: 'Passed', rating: '88.5');
    expect(log.last.url.path, '$base/Exams/add');
    expect(log.last.bodyFields, {'exam_name': 'LET', 'date_taken': '', 'rating': '88.5', 'result': 'Passed'});

    await TrainingService(api).add(
      const TrainingInput(title: 'Cyber', type: 'Training', purpose: 'Promotion', purposeOther: 'ignored'),
    );
    expect(log.last.bodyFields['training_title'], 'Cyber');
    expect(log.last.bodyFields['purpose_other'], '');
  });

  test('Feed: browse routes and event registration use POST', () async {
    final (api, log) = mock({'data': []});
    final feed = FeedService(api);
    await feed.getAnnouncements();
    await feed.getJobs();
    await feed.getEvents();
    expect(log.map((r) => r.url.path), [
      '$base/Browse/announcements', '$base/Browse/jobs', '$base/Browse/events',
    ]);
    final (api2, log2) = mock();
    await FeedService(api2).registerForEvent(4);
    expect(log2.last.url.path, '$base/Events/register/4');
    expect(log2.last.method, 'POST');
    await FeedService(api2).cancelEventRegistration(4);
    expect(log2.last.url.path, '$base/Events/cancel/4');
  });

  test('Tracer submit uses answers[<id>] like the web form', () async {
    final (api, log) = mock();
    await TracerService(api).submit(2, {5: 'Yes', 6: 'B'});
    expect(log.last.url.path, '$base/Tracer/submit');
    expect(log.last.bodyFields, {
      'tracer_study_id': '2', 'answers[5]': 'Yes', 'answers[6]': 'B',
    });
  });

  test('Profile update and password forms', () async {
    final (api, log) = mock();
    await ProfileService(api).update(
      const ProfileInput(
        firstName: 'Juan', lastName: 'Cruz', dateOfBirth: '1999-04-03', gender: 'Male',
        civilStatusId: 1, regionId: 2, province: 'Isabela',
      ),
    );
    expect(log.last.url.path, '$base/Profile/update');
    expect(log.last.bodyFields['date_of_birth'], '1999-04-03');
    expect(log.last.bodyFields['residence_type_id'], '');
    await ProfileService(api).changePassword(current: 'a', next: 'bbbbbbbb', confirm: 'bbbbbbbb');
    expect(log.last.url.path, '$base/Profile/password');
    expect(log.last.bodyFields['confirm_password'], 'bbbbbbbb');
  });

  test('mutations reject server errors and unconfirmed writes', () async {
    for (final body in [
      {'status': 'error', 'message': 'Program and graduation year are required.'},
      {'message': 'Not confirmed'},
    ]) {
      final (api, _) = mock(body);
      await expectLater(AcademicService(api).delete(1), throwsException);
    }
  });
}
