import 'package:flutter_test/flutter_test.dart';
import 'package:alumni_mobile_app/models/academic_model.dart';
import 'package:alumni_mobile_app/models/dashboard_model.dart';
import 'package:alumni_mobile_app/models/employment_model.dart';
import 'package:alumni_mobile_app/models/feed_models.dart';
import 'package:alumni_mobile_app/models/licensure_model.dart';
import 'package:alumni_mobile_app/models/lookup_model.dart';
import 'package:alumni_mobile_app/models/profile_model.dart';
import 'package:alumni_mobile_app/models/session_user.dart';
import 'package:alumni_mobile_app/models/tracer_models.dart';
import 'package:alumni_mobile_app/models/training_model.dart';
import 'helpers.dart';

void main() {
  test('SessionUser parses PHP payload and rejects missing fields', () {
    final u = SessionUser.fromJson(Map<String, dynamic>.from(userJson));
    expect(u.id, 7);
    expect(u.alumniNumber, 'A-2020-001');
    expect(() => SessionUser.fromJson({'id': 1}), throwsFormatException);
  });

  test('records accept string ids/flags from PHP', () {
    final e = EmploymentModel.fromJson({
      'id': '4',
      'employment_status_id': '2',
      'status_name': 'Employed',
      'employer': 'ACME',
      'is_current': '1',
      'is_first_job': '0',
      'related_to_degree': '1',
      'employment_type_id': null,
      'date_hired': '2024-01-05',
    });
    expect(e.id, 4);
    expect(e.isCurrent, true);
    expect(e.isFirstJob, false);
    expect(e.relatedToDegree, true);
    expect(e.tenureId, isNull);

    final a = AcademicModel.fromJson({
      'id': 1,
      'program_id': '3',
      'program_name': 'BSIT',
      'graduation_year': '2020',
    });
    expect(a.graduationYear, 2020);

    final l = LicensureModel.fromJson({
      'id': 1,
      'license_type_id': 2,
      'status_id': 1,
      'license_name': 'LET',
      'status_name': 'Passed',
      'examination_year': null,
    });
    expect(l.examinationYear, isNull);

    expect(
      TrainingModel.fromJson({'id': 1, 'training_title': 'Cyber', 'training_year': '2023'}).year,
      2023,
    );
  });

  test('models reject invalid records', () {
    expect(() => AcademicModel.fromJson({'id': 1}), throwsFormatException);
    expect(
      () => EmploymentModel.fromJson({'id': 0, 'employment_status_id': 1}),
      throwsFormatException,
    );
    expect(() => EventModel.fromJson({'id': 1}), throwsFormatException);
    expect(() => LookupItem.fromJson({'id': 1}), throwsFormatException);
  });

  test('EventModel reads is_registered count', () {
    expect(EventModel.fromJson({'id': 1, 'title': 'T', 'is_registered': '1'}).isRegistered, true);
    expect(EventModel.fromJson({'id': 1, 'title': 'T', 'is_registered': 0}).isRegistered, false);
  });

  test('Lookups parse lists and nameOf resolves ids', () {
    final l = Lookups.fromJson({
      'programs': [
        {'id': 1, 'name': 'BSIT', 'code': 'IT'},
      ],
      'regions': [
        {'id': 2, 'name': 'Region II'},
      ],
    });
    expect(l.programs.single.code, 'IT');
    expect(Lookups.nameOf(l.regions, 2), 'Region II');
    expect(Lookups.nameOf(l.regions, 9), isNull);
    expect(l.industries, isEmpty);
  });

  test('TracerQuestionnaire parses options, answers and yes/no choices', () {
    final q = TracerQuestionnaire.fromJson({
      'study': {'id': 1, 'title': 'Study', 'description': 'D'},
      'questions': [
        {'id': 5, 'question': 'Employed?', 'question_type': 'yes_no', 'options': [], 'is_required': 1},
        {'id': 6, 'question': 'Pick', 'question_type': 'select', 'options': ['A', 'B'], 'is_required': 0},
      ],
      'answers': {'5': 'Yes'},
    });
    expect(q.questions.first.choices, ['Yes', 'No']);
    expect(q.questions.first.isRequired, true);
    expect(q.questions.last.choices, ['A', 'B']);
    expect(q.answers[5], 'Yes');
  });

  test('TracerStudyModel flags GTS studies', () {
    final s = TracerStudyModel.fromJson({
      'id': 1, 'title': 'GTS 2026', 'survey_type': 'gts', 'answered': '0', 'in_progress': '1',
    });
    expect(s.isGts, true);
    expect(s.inProgress, true);
  });

  test('DashboardModel parses summary', () {
    final d = DashboardModel.fromJson({
      'alumni': {'first_name': 'Juan', 'alumni_number': 'A-1', 'verification_status': 'verified'},
      'attendance': {'attended': 1, 'total': 4, 'rate': 25},
      'announcements': [
        {'id': 1, 'title': 'Hi', 'content': 'x'},
      ],
      'events': [],
      'studies': [],
    });
    expect(d.eventsTotal, 4);
    expect(d.attendanceRate, 25.0);
    expect(d.announcements.single.title, 'Hi');
    expect(() => DashboardModel.fromJson({}), throwsException);
  });

  test('ProfileModel builds full name and rejects missing names', () {
    final p = ProfileModel.fromJson({
      'first_name': 'Juan', 'middle_name': 'S', 'last_name': 'Cruz', 'suffix': 'Jr.',
      'civil_status_id': '1',
    });
    expect(p.fullName, 'Juan S Cruz Jr.');
    expect(p.civilStatusId, 1);
    expect(() => ProfileModel.fromJson({'first_name': 'A'}), throwsFormatException);
  });
}
