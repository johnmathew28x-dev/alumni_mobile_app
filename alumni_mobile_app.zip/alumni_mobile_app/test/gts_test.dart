import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/models/gts_models.dart';
import 'package:alumni_mobile_app/models/tracer_models.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/gts_service.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'package:alumni_mobile_app/views/pages/tracer/gts/gts_form.dart';
import 'package:alumni_mobile_app/views/pages/tracer/gts/gts_sections.dart';
import 'package:alumni_mobile_app/views/pages/tracer/gts/index.dart';
import 'helpers.dart';

Map<String, dynamic> surveyJson({
  String status = 'draft',
  String? state,
  Object? isFirst,
  Object? relevant,
  int last = 1,
}) => {
  'id': 1,
  'status': status,
  'employment_state': state,
  'current_is_first_job': isFirst,
  'curriculum_relevant': relevant,
  'last_section': last,
  'submitted_at': null,
};

List<Map<String, dynamic>> list(List<(int, String, bool)> rows) => [
  for (final r in rows) {'id': r.$1, 'name': r.$2, 'is_other': r.$3},
];

Map<String, dynamic> optionsJson() => {
  'civil_statuses': list([(1, 'Single', false)]),
  'regions': list([(1, 'Region VII', false)]),
  'residence_types': list([(1, 'Owned', false)]),
  'course_reasons': list([(1, 'High grades in the course', false), (9, 'Other', true)]),
  'unemployment_reasons': list([(1, 'Advance or further study', false), (8, 'Other', true)]),
  'employment_types': list([(1, 'Regular', false), (2, 'Self-employed', false)]),
  'industries': list([(1, 'Education', false)]),
  'accept_reasons': list([(1, 'Salaries and benefits', false)]),
  'change_reasons': list([(1, 'Career challenge', false)]),
  'duration_ranges': list([(1, 'Less than a month', false)]),
  'job_search_methods': list([(1, 'Walk-in applicant', false)]),
  'job_levels': list([(1, 'Rank or clerical', false)]),
  'salary_ranges': list([(1, 'Below P5,000', false)]),
  'competencies': list([(1, 'Communication skills', false), (7, 'Other', true)]),
};

Map<String, dynamic> dataJson(Map<String, dynamic> survey) => {
  'survey': survey,
  'general': {
    'first_name': 'Juan', 'middle_name': null, 'last_name': 'Cruz', 'suffix': null,
    'date_of_birth': '2000-05-06', 'gender': 'Male', 'contact_number': '0917 111 2222',
    'email': 'juan@example.com', 'address': '1 Rizal St', 'civil_status_id': 1,
    'region_id': 1, 'province': 'Cebu', 'city_municipality': 'Cebu City', 'residence_type_id': null,
  },
  'education': {'degree': 'BEEd', 'program_name': 'Bachelor of Elementary Education', 'graduation_year': 2022},
  'course': {'ids': [], 'other': ''},
  'unemployment': {'ids': [], 'other': ''},
  'current': null,
  'first': null,
  'accept': {'ids': [], 'other': ''},
  'change': {'ids': [], 'other': ''},
  'competencies': {'ids': [], 'other': ''},
  'feedback': '',
};

Map<String, dynamic> startJson({
  Map<String, dynamic>? survey,
  bool editable = true,
}) => {
  'status': 'success',
  'success': true,
  'message': 'OK',
  'study_id': 7,
  'editable': editable,
  'sections': {
    '1': 'General Information', '2': 'Educational Background', '3': 'Professional Examinations',
    '4': 'Reasons for Taking the Course', '5': 'Trainings / Advanced Studies', '6': 'Employment Status',
    '7': 'Current Employment', '8': 'First Job', '9': 'Job Search', '10': 'Job Level and Earnings',
    '11': 'Curriculum Relevance', '12': 'Competencies', '13': 'Curriculum Feedback', '14': 'Review and Submit',
  },
  'data': dataJson(survey ?? surveyJson(last: 4)),
  'options': optionsJson(),
};

void main() {
  group('GtsSurvey section rules (same as the web form)', () {
    test('before Employment Status is answered only sections 1-6, 13, 14 apply', () {
      final s = GtsSurvey.fromJson(surveyJson());
      expect(s.visibleSections, [1, 2, 3, 4, 5, 6, 13, 14]);
    });

    test('not employed skips sections 7-12', () {
      final s = GtsSurvey.fromJson(surveyJson(state: 'not_employed'));
      expect(s.visibleSections, [1, 2, 3, 4, 5, 6, 13, 14]);
    });

    test('employed shows 7-11; 12 only when the curriculum was relevant', () {
      final no = GtsSurvey.fromJson(surveyJson(state: 'employed', relevant: '0'));
      expect(no.visibleSections, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14]);
      final yes = GtsSurvey.fromJson(surveyJson(state: 'employed', relevant: '1'));
      expect(yes.isVisible(12), isTrue);
    });

    test('merged means employed and current job is the first job', () {
      expect(GtsSurvey.fromJson(surveyJson(state: 'employed', isFirst: '1')).merged, isTrue);
      expect(GtsSurvey.fromJson(surveyJson(state: 'employed', isFirst: '0')).merged, isFalse);
      expect(GtsSurvey.fromJson(surveyJson(state: 'not_employed', isFirst: '1')).merged, isFalse);
    });
  });

  test('GtsStart parses sections, data and options', () {
    final s = GtsStart.fromJson(startJson());
    expect(s.studyId, 7);
    expect(s.editable, isTrue);
    expect(s.sections[14], 'Review and Submit');
    expect(s.data.survey.lastSection, 4);
    expect(s.data.general['first_name'], 'Juan');
    expect(s.options.of('course_reasons').last.isOther, isTrue);
    expect(s.options.of('missing_list'), isEmpty);
  });

  test('GtsReview parses rows and the missing list', () {
    final r = GtsReview.fromJson({
      'sections': [
        {'title': '1. General Information', 'rows': [['Name', 'Juan Cruz'], ['Sex', null]]},
      ],
      'missing': ['4. Reasons for taking the course: select at least one.'],
    });
    expect(r.sections.single.rows.first, ('Name', 'Juan Cruz'));
    expect(r.sections.single.rows.last.$2, '—');
    expect(r.missing, hasLength(1));
  });

  group('GtsService', () {
    late List<http.Request> log;
    late GtsService service;
    setUp(() {
      log = [];
      service = GtsService(
        ApiService(
          baseUrl: 'http://localhost/alumni_tracking_system/Api',
          client: AuthClient(
            MemoryTokenStore('tok'),
            inner: MockClient((r) async {
              log.add(r);
              if (r.url.path.endsWith('/saveSection/7')) {
                return jsonResponse({
                  'status': 'success',
                  'message': 'Section 4 saved.',
                  'data': {'survey': surveyJson(last: 5)},
                });
              }
              return jsonResponse({'status': 'success', 'message': 'Done.'});
            }),
          ),
        ),
      );
    });

    test('indexed encodes checklists as PHP arrays', () {
      expect(GtsService.indexed('course_reason_ids', ['1', '9']), {
        'course_reason_ids[0]': '1',
        'course_reason_ids[1]': '9',
      });
    });

    test('saveSection posts the fields with the section number', () async {
      final survey = await service.saveSection(7, 4, {
        ...GtsService.indexed('course_reason_ids', ['1']),
        'course_reason_other': '',
      });
      final r = log.single;
      expect(r.method, 'POST');
      expect(r.url.path, endsWith('/Gts/saveSection/7'));
      expect(r.bodyFields['section'], '4');
      expect(r.bodyFields['course_reason_ids[0]'], '1');
      expect(survey.lastSection, 5);
    });

    test('submit posts to Gts/submit', () async {
      await service.submit(7);
      expect(log.single.method, 'POST');
      expect(log.single.url.path, endsWith('/Gts/submit/7'));
    });
  });

  group('section questions', () {
    GtsData data(Map<String, dynamic> survey) => GtsData.fromJson(dataJson(survey));
    final options = GtsOptions.fromJson(optionsJson());
    List<String> names(int n, Map<String, dynamic> survey) =>
        gtsFields(n, data(survey), options).map((f) => f.name).where((x) => x.isNotEmpty).toList();

    test('section 8 omits the first-job questions when the current job is the first job', () {
      final merged = names(8, surveyJson(state: 'employed', isFirst: '1'));
      expect(merged, ['duration_id', 'accept_reason_ids']);
      final separate = names(8, surveyJson(state: 'employed', isFirst: '0'));
      expect(separate, containsAll(['first_job_position', 'first_industry_id', 'duration_id']));
    });

    test('section 9 asks why jobs were changed only for employed people with a different first job', () {
      expect(names(9, surveyJson(state: 'employed', isFirst: '0')), contains('change_reason_ids'));
      expect(names(9, surveyJson(state: 'employed', isFirst: '1')), isNot(contains('change_reason_ids')));
    });

    test('section 10 asks for the present job only when it differs from the first', () {
      expect(names(10, surveyJson(state: 'employed', isFirst: '0')), contains('current_job_level_id'));
      expect(names(10, surveyJson(state: 'employed', isFirst: '1')), isNot(contains('current_job_level_id')));
    });

    test('initial values map saved answers to field names', () {
      final d = GtsData.fromJson({
        ...dataJson(surveyJson(state: 'employed', isFirst: '1', relevant: '1')),
        'current': {'employment_type_id': 2, 'job_position': 'Teacher', 'related_to_degree': 1, 'industry_id': 1},
      });
      final v = gtsInitial(7, d);
      expect(v.text['employment_type_id'], '2');
      expect(v.text['related_to_degree'], '1');
      expect(v.text['current_is_first_job'], '1');
      expect(gtsInitial(11, d).text['curriculum_relevant'], '1');
    });
  });

  group('section form', () {
    Future<GlobalKey<GtsSectionFormState>> pumpSection(
      WidgetTester tester,
      int n, {
      Map<String, dynamic>? survey,
    }) async {
      tester.view.physicalSize = const Size(390, 1600);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final d = GtsData.fromJson(dataJson(survey ?? surveyJson()));
      final key = GlobalKey<GtsSectionFormState>();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: GtsSectionForm(
              key: key,
              fields: gtsFields(n, d, GtsOptions.fromJson(optionsJson())),
              initial: gtsInitial(n, d),
            ),
          ),
        ),
      );
      return key;
    }

    testWidgets('a required checklist cannot be left empty', (tester) async {
      final key = await pumpSection(tester, 4);
      expect(key.currentState!.collect(), isNull);
      await tester.pump();
      expect(find.text('Select at least one.'), findsOneWidget);
    });

    testWidgets('picked reasons are sent as an indexed array', (tester) async {
      final key = await pumpSection(tester, 4);
      await tester.tap(find.text('High grades in the course'));
      await tester.pump();
      final form = key.currentState!.collect()!;
      expect(form['course_reason_ids[0]'], '1');
      expect(form['course_reason_other'], '');
    });

    testWidgets('choosing Other requires the text and sends it', (tester) async {
      final key = await pumpSection(tester, 4);
      await tester.tap(find.text('Other'));
      await tester.pump();
      expect(find.text('Please specify *'), findsOneWidget);
      expect(key.currentState!.collect(), isNull);
      await tester.enterText(find.byType(TextFormField), 'Family business');
      final form = key.currentState!.collect()!;
      expect(form['course_reason_ids[0]'], '9');
      expect(form['course_reason_other'], 'Family business');
    });

    testWidgets('unemployment reasons only appear when not employed', (tester) async {
      await pumpSection(tester, 6);
      expect(find.text('Advance or further study'), findsNothing);
      await tester.tap(find.text('No, I am not currently employed'));
      await tester.pump();
      expect(find.text('Advance or further study'), findsOneWidget);
      await tester.tap(find.text('Yes, I am currently employed'));
      await tester.pump();
      expect(find.text('Advance or further study'), findsNothing);
    });

    testWidgets('the employment status must be answered', (tester) async {
      final key = await pumpSection(tester, 6);
      expect(key.currentState!.collect(), isNull);
    });

    testWidgets('section 1 is prefilled and validates the academic rules', (tester) async {
      final key = await pumpSection(tester, 1);
      final form = key.currentState!.collect()!;
      expect(form['first_name'], 'Juan');
      expect(form['gender'], 'Male');
      expect(form['civil_status_id'], '1');
      expect(form['date_of_birth'], '2000-05-06');
    });
  });

  group('survey page', () {
    late List<http.Request> log;
    late int lastSection;

    Future<void> pump(
      WidgetTester tester, {
      bool editable = true,
      int last = 4,
    }) async {
      tester.view.physicalSize = const Size(390, 1600);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      lastSection = last;
      final api = ApiService(
        baseUrl: 'http://localhost/alumni_tracking_system/Api',
        client: AuthClient(
          MemoryTokenStore('tok'),
          inner: MockClient((r) async {
            log.add(r);
            final p = r.url.path;
            if (p.endsWith('/Gts/start/7')) {
              return jsonResponse(
                startJson(
                  survey: surveyJson(last: lastSection, status: editable ? 'draft' : 'submitted'),
                  editable: editable,
                ),
              );
            }
            if (p.endsWith('/Gts/saveSection/7')) {
              lastSection = 5;
              return jsonResponse({
                'status': 'success',
                'message': 'Section 4 saved.',
                'data': {'survey': surveyJson(last: 5)},
              });
            }
            if (p.endsWith('/Gts/review/7')) {
              return jsonResponse({
                'status': 'success',
                'sections': [
                  {'title': '1. General Information', 'rows': [['Name', 'Juan Cruz']]},
                ],
                'missing': ['4. Reasons for taking the course: select at least one.'],
              });
            }
            return jsonResponse({'data': []});
          }),
        ),
      );
      addTearDown(api.close);
      await tester.pumpWidget(
        MaterialApp(
          home: GtsPage(
            api: api,
            study: const TracerStudyModel(
              id: 7,
              title: 'CHED GTS',
              surveyType: 'gts',
              answered: false,
              inProgress: true,
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
    }

    setUp(() => log = []);

    testWidgets('resumes at the last section and shows the progress', (tester) async {
      await pump(tester);
      expect(find.text('4. Reasons for Taking the Course'), findsOneWidget);
      expect(find.text('Step 4 of 8'), findsOneWidget);
    });

    testWidgets('Save & Continue posts the section, then opens the next one', (tester) async {
      await pump(tester);
      await tester.tap(find.text('High grades in the course'));
      await tester.pump();
      await tester.tap(find.text('Save & Continue'));
      await tester.pumpAndSettle();

      final post = log.firstWhere((r) => r.url.path.endsWith('/Gts/saveSection/7'));
      expect(post.bodyFields['section'], '4');
      expect(post.bodyFields['course_reason_ids[0]'], '1');
      expect(find.text('5. Trainings / Advanced Studies'), findsOneWidget);
      expect(find.text('Add or edit trainings'), findsOneWidget);
    });

    testWidgets('an invalid section is not sent to the server', (tester) async {
      await pump(tester);
      await tester.tap(find.text('Save & Continue'));
      await tester.pumpAndSettle();
      expect(log.any((r) => r.url.path.contains('/saveSection/')), isFalse);
      expect(find.text('4. Reasons for Taking the Course'), findsOneWidget);
    });

    testWidgets('Back returns to the previous section without saving', (tester) async {
      await pump(tester);
      await tester.tap(find.text('Back'));
      await tester.pumpAndSettle();
      expect(find.textContaining('3. Professional Examinations'), findsOneWidget);
      expect(log.any((r) => r.url.path.contains('/saveSection/')), isFalse);
    });

    testWidgets('a submitted survey is a read-only review', (tester) async {
      await pump(tester, editable: false);
      expect(find.textContaining('can no longer be edited'), findsOneWidget);
      expect(find.text('Save & Continue'), findsNothing);
      expect(find.text('Submit survey'), findsNothing);
      expect(find.text('Juan Cruz'), findsOneWidget);
    });

    testWidgets('review blocks submitting while answers are missing', (tester) async {
      await pump(tester, last: 14);
      expect(find.textContaining('Please complete the following'), findsOneWidget);
      final submit = find.widgetWithText(FilledButton, 'Submit survey');
      // FilledButton.icon builds a subclass, so look the button up by its label.
      final button = submit.evaluate().isNotEmpty
          ? tester.widget<FilledButton>(submit)
          : tester.widget<FilledButton>(
              find.ancestor(of: find.text('Submit survey'), matching: find.byWidgetPredicate((w) => w is FilledButton)),
            );
      expect(button.onPressed, isNull);
    });
  });
}
