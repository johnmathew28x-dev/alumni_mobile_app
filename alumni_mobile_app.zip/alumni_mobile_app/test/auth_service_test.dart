import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/auth_service.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'helpers.dart';

AuthService build(
  MemoryTokenStore store,
  Future<http.Response> Function(http.Request) handler,
) {
  final api = ApiService(
    baseUrl: 'http://localhost/alumni_tracking_system/Api',
    client: AuthClient(store, inner: MockClient(handler)),
  );
  return AuthService(api, store);
}

void main() {
  test('login posts credentials, stores the token and parses the user', () async {
    final store = MemoryTokenStore();
    late http.Request sent;
    final auth = build(store, (r) async {
      sent = r;
      return jsonResponse({
        'status': 'success',
        'success': true,
        'message': 'Login successful.',
        'token': 'tok123',
        'expires_at': '2026-11-13 10:00:00',
        'user': userJson,
      });
    });
    final user = await auth.login('juan', 'secret99');
    expect(sent.method, 'POST');
    expect(sent.url.path, '/alumni_tracking_system/Api/Auth/login');
    expect(sent.bodyFields['username'], 'juan');
    expect(sent.bodyFields['password'], 'secret99');
    expect(await store.read(), 'tok123');
    expect(user.alumniId, 3);
    expect(user.role, 'Alumni');
  });

  test('invalid login throws the server message and stores nothing', () async {
    final store = MemoryTokenStore();
    final auth = build(
      store,
      (_) async => jsonResponse({
        'status': 'error',
        'message': 'Invalid username or password.',
      }, 401),
    );
    await expectLater(
      auth.login('juan', 'wrong'),
      throwsA(predicate((e) => '$e'.contains('Invalid username or password.'))),
    );
    expect(await store.read(), isNull);
  });

  test('restore: no token -> null without any request', () async {
    var calls = 0;
    final auth = build(MemoryTokenStore(), (_) async {
      calls++;
      return jsonResponse({});
    });
    expect(await auth.restore(), isNull);
    expect(calls, 0);
  });

  test('restore: valid token returns the user', () async {
    final auth = build(
      MemoryTokenStore('tok'),
      (_) async => jsonResponse({
        'status': 'success',
        'message': 'OK',
        'user': userJson,
      }),
    );
    expect((await auth.restore())!.username, 'juan');
  });

  test('restore: rejected token -> null and token cleared', () async {
    final store = MemoryTokenStore('old');
    final auth = build(
      store,
      (_) async => jsonResponse({'status': 'error', 'message': 'expired'}, 401),
    );
    expect(await auth.restore(), isNull);
    expect(await store.read(), isNull);
  });

  test('restore: network failure rethrows and keeps the token', () async {
    final store = MemoryTokenStore('keep');
    final auth = build(store, (_) async => throw http.ClientException('down'));
    await expectLater(auth.restore(), throwsException);
    expect(await store.read(), 'keep');
  });

  test('logout clears the local token even if the server call fails', () async {
    final store = MemoryTokenStore('tok');
    final auth = build(store, (_) async => throw http.ClientException('down'));
    await auth.logout();
    expect(await store.read(), isNull);
  });

  test('logout calls Auth/logout with POST', () async {
    final store = MemoryTokenStore('tok');
    late http.Request sent;
    final auth = build(store, (r) async {
      sent = r;
      return jsonResponse({'status': 'success', 'message': 'Logged out.'});
    });
    await auth.logout();
    expect(sent.method, 'POST');
    expect(sent.url.path, endsWith('/Auth/logout'));
    expect(sent.headers['authorization'], 'Bearer tok');
  });
}
