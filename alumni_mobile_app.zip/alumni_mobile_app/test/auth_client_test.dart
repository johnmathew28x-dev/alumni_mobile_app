import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'helpers.dart';

ApiService apiWith(
  TokenStore store,
  Future<http.Response> Function(http.Request) handler, {
  void Function()? onUnauthorized,
  List<http.Request>? log,
}) => ApiService(
  baseUrl: 'http://localhost/alumni_tracking_system/Api',
  client: AuthClient(
    store,
    inner: MockClient((r) {
      log?.add(r);
      return handler(r);
    }),
    onUnauthorized: onUnauthorized,
  ),
);

void main() {
  test('adds the bearer header only when a token is stored', () async {
    final log = <http.Request>[];
    final withToken = apiWith(
      MemoryTokenStore('abc123'),
      (_) async => jsonResponse({'status': 'success', 'message': 'ok'}),
      log: log,
    );
    await withToken.request('Auth/me');
    expect(log.single.headers['authorization'], 'Bearer abc123');
    withToken.close();

    log.clear();
    final noToken = apiWith(
      MemoryTokenStore(),
      (_) async => jsonResponse({'status': 'success', 'message': 'ok'}),
      log: log,
    );
    await noToken.request('Auth/login', form: {'username': 'a'});
    expect(log.single.headers.containsKey('authorization'), false);
    noToken.close();
  });

  test('surfaces the server message for 4xx API errors', () async {
    final api = apiWith(
      MemoryTokenStore(),
      (_) async => jsonResponse({
        'status': 'error',
        'message': 'Invalid username or password.',
      }, 401),
    );
    await expectLater(
      api.request('Auth/login', form: {'username': 'x', 'password': 'y'}),
      throwsA(
        predicate((e) => e.toString().contains('Invalid username or password.')),
      ),
    );
    api.close();
  });

  test('401 with a token clears it and signals logout', () async {
    final store = MemoryTokenStore('expired');
    var signalled = 0;
    final api = apiWith(
      store,
      (_) async => jsonResponse({
        'status': 'error',
        'message': 'Your session has expired. Please log in again.',
      }, 401),
      onUnauthorized: () => signalled++,
    );
    await expectLater(api.request('Profile/details'), throwsException);
    expect(await store.read(), isNull);
    expect(signalled, 1);
    api.close();
  });

  test('401 without a token (bad login) does not signal logout', () async {
    var signalled = 0;
    final api = apiWith(
      MemoryTokenStore(),
      (_) async => jsonResponse({'status': 'error', 'message': 'No'}, 401),
      onUnauthorized: () => signalled++,
    );
    await expectLater(api.request('Auth/login', form: {'a': 'b'}), throwsException);
    expect(signalled, 0);
    api.close();
  });

  test('non-JSON 4xx/5xx responses stay generic HTTP errors', () async {
    for (final code in [404, 500]) {
      final api = apiWith(
        MemoryTokenStore(),
        (_) async => http.Response('<html>oops</html>', code),
      );
      await expectLater(
        api.request('Nope/all'),
        throwsA(predicate((e) => e.toString().contains('HTTP $code'))),
      );
      api.close();
    }
  });
}
