import 'dart:convert';
import 'package:http/http.dart' as http;

http.Response jsonResponse(Object body, [int status = 200]) => http.Response(
  jsonEncode(body),
  status,
  headers: {'content-type': 'application/json'},
);

const userJson = {
  'id': 7,
  'username': 'juan',
  'role': 'Alumni',
  'alumni_id': 3,
  'alumni_number': 'A-2020-001',
  'full_name': 'Juan Dela Cruz',
  'picture_url': 'http://10.0.2.2/alumni_tracking_system/img/default-avatar.svg',
};
