import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/registration_service.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'helpers.dart';

RegistrationService build(Future<http.Response> Function(http.Request) handler) {
  final api = ApiService(
    baseUrl: 'http://localhost/alumni_tracking_system/Api',
    client: AuthClient(MemoryTokenStore(), inner: MockClient(handler)),
  );
  return RegistrationService(api);
}

const _input = RegistrationInput(
  firstName: ' Ana ',
  lastName: 'Cruz',
  username: 'ana.cruz',
  email: 'ana@example.com',
  password: ' secret99 ',
  confirmPassword: ' secret99 ',
  programId: 2,
  graduationYear: 2024,
);

void main() {
  test('getPrograms reads the public Auth/programs list without a token', () async {
    late http.Request sent;
    final service = build((r) async {
      sent = r;
      return jsonResponse({
        'status': 'success',
        'message': 'OK',
        'data': [
          {'id': 2, 'name': 'BS Information Technology', 'code': 'BSIT'},
        ],
      });
    });
    final programs = await service.getPrograms();
    expect(sent.method, 'GET');
    expect(sent.url.path, '/alumni_tracking_system/Api/Auth/programs');
    expect(sent.headers.containsKey('Authorization'), isFalse);
    expect(programs.single.id, 2);
    expect(programs.single.code, 'BSIT');
  });

  test('register posts only the allowed fields (no role or status)', () async {
    late http.Request sent;
    final service = build((r) async {
      sent = r;
      return jsonResponse({
        'status': 'success',
        'success': true,
        'message': 'Registration successful!',
      }, 201);
    });
    await service.register(_input);
    expect(sent.method, 'POST');
    expect(sent.url.path, '/alumni_tracking_system/Api/Auth/register');
    expect(sent.bodyFields, {
      'first_name': 'Ana',
      'last_name': 'Cruz',
      'username': 'ana.cruz',
      'email': 'ana@example.com',
      'password': ' secret99 ', // passwords are not trimmed
      'confirm_password': ' secret99 ',
      'program_id': '2',
      'graduation_year': '2024',
    });
    expect(sent.bodyFields.containsKey('role'), isFalse);
    expect(sent.bodyFields.containsKey('status'), isFalse);
  });

  for (final entry in {
    409: 'Username is already taken.',
    422: 'Passwords do not match.',
    429: 'Too many registration attempts. Please try again later.',
  }.entries) {
    test('register surfaces the server message for HTTP ${entry.key}', () async {
      final service = build(
        (_) async => jsonResponse({
          'status': 'error',
          'message': entry.value,
        }, entry.key),
      );
      await expectLater(
        service.register(_input),
        throwsA(predicate((e) => '$e'.contains(entry.value))),
      );
    });
  }
}
