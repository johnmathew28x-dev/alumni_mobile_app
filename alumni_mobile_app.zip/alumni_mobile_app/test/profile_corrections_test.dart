import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/models/profile_model.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/profile_service.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'package:alumni_mobile_app/views/pages/profile/index.dart';
import 'helpers.dart';

const _ok = {'status': 'success', 'success': true, 'message': 'Done.'};

Map<String, dynamic> details({String submission = 'draft'}) => {
  'alumni_number': 'NEC-2026-00007',
  'first_name': 'Juan',
  'middle_name': null,
  'last_name': 'Dela Cruz',
  'suffix': null,
  'date_of_birth': '2000-05-06',
  'gender': 'Male',
  'contact_number': '0917 111 2222',
  'email': 'juan@example.com',
  'address': '1 Rizal St',
  'civil_status_id': 1,
  'region_id': 1,
  'province': 'Cebu',
  'city_municipality': 'Cebu City',
  'residence_type_id': null,
  'verification_status': 'pending',
  'submission_status': submission,
};

const _lookups = {
  'civil_statuses': [
    {'id': 1, 'name': 'Single'},
  ],
  'regions': [
    {'id': 1, 'name': 'Region VII'},
  ],
  'residence_types': [
    {'id': 1, 'name': 'Owned'},
  ],
};

Map<String, dynamic> correction(String status, {String? note}) => {
  'id': 4,
  'source': 'alumni',
  'status': status,
  'reason': 'Wrong birth month',
  'review_note': note,
  'created': '2026-10-15 09:30:00',
  'change_list': [
    {'field': 'date_of_birth', 'label': 'Date of Birth', 'sensitive': true, 'old': '2000-05-06', 'new': '2000-06-05'},
  ],
};

void main() {
  group('ProfileModel', () {
    test('reads submission_status and defaults to draft', () {
      expect(ProfileModel.fromJson(details()).isLocked, isFalse);
      expect(ProfileModel.fromJson(details(submission: 'submitted')).isLocked, isTrue);
      final noField = Map<String, dynamic>.from(details())..remove('submission_status');
      expect(ProfileModel.fromJson(noField).submissionStatus, 'draft');
    });

    test('toForm uses empty text for missing values', () {
      final f = ProfileModel.fromJson(details()).toForm();
      expect(f['middle_name'], '');
      expect(f['residence_type_id'], '');
      expect(f['civil_status_id'], '1');
      expect(f['date_of_birth'], '2000-05-06');
      expect(f.length, 13);
    });
  });

  group('ProfileService', () {
    late List<http.Request> log;
    late ProfileService service;
    setUp(() {
      log = [];
      service = ProfileService(
        ApiService(
          baseUrl: 'http://localhost/alumni_tracking_system/Api',
          client: AuthClient(
            MemoryTokenStore('tok'),
            inner: MockClient((r) async {
              log.add(r);
              if (r.url.path.endsWith('/Profile/corrections')) {
                return jsonResponse({'data': [correction('pending')]});
              }
              return jsonResponse(_ok);
            }),
          ),
        ),
      );
    });

    test('submit sends the saved fields plus the privacy confirmation', () async {
      await service.submit(ProfileModel.fromJson(details()));
      final r = log.single;
      expect(r.method, 'POST');
      expect(r.url.path, endsWith('/Profile/submit'));
      expect(r.bodyFields['privacy_ack'], '1');
      expect(r.bodyFields['first_name'], 'Juan');
      expect(r.bodyFields['civil_status_id'], '1');
    });

    test('requestCorrection posts the fields and the trimmed reason', () async {
      await service.requestCorrection(
        const ProfileInput(
          firstName: 'Juan',
          lastName: 'Dela Cruz',
          dateOfBirth: '2000-06-05',
          gender: 'Male',
          civilStatusId: 1,
          regionId: 1,
          province: 'Cebu',
        ),
        reason: '  Wrong birth month  ',
      );
      final r = log.single;
      expect(r.url.path, endsWith('/Profile/requestCorrection'));
      expect(r.bodyFields['reason'], 'Wrong birth month');
      expect(r.bodyFields['date_of_birth'], '2000-06-05');
    });

    test('getCorrections parses the alumnus\'s own requests', () async {
      final list = await service.getCorrections();
      expect(log.single.url.path, endsWith('/Profile/corrections'));
      expect(list.single.isPending, isTrue);
      expect(list.single.changes.single.newValue, '2000-06-05');
    });
  });

  group('profile screen', () {
    late List<http.Request> log;

    Future<void> pump(
      WidgetTester tester, {
      required String submission,
      List<Map<String, dynamic>> corrections = const [],
    }) async {
      tester.view.physicalSize = const Size(390, 1400);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = ApiService(
        baseUrl: 'http://localhost/alumni_tracking_system/Api',
        client: AuthClient(
          MemoryTokenStore('tok'),
          inner: MockClient((r) async {
            log.add(r);
            final p = r.url.path;
            if (p.endsWith('/Profile/details')) {
              return jsonResponse({'status': 'success', 'message': 'OK', 'data': details(submission: submission)});
            }
            if (p.endsWith('/Lookups/all')) {
              return jsonResponse({'status': 'success', 'message': 'OK', 'data': _lookups});
            }
            if (p.endsWith('/Profile/corrections')) {
              return jsonResponse({'data': corrections});
            }
            return jsonResponse(_ok);
          }),
        ),
      );
      addTearDown(api.close);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(body: ProfilePage(api: api, onSignOut: () async {})),
        ),
      );
      await tester.pumpAndSettle();
    }

    setUp(() => log = []);

    testWidgets('draft: can edit and submit, cannot request a correction', (tester) async {
      await pump(tester, submission: 'draft');
      expect(find.text('Edit profile'), findsOneWidget);
      expect(find.text('Submit & lock'), findsOneWidget);
      expect(find.text('Request correction'), findsNothing);
      expect(find.text('Not yet submitted'), findsOneWidget);
      // No correction history is requested before the profile is submitted.
      expect(log.any((r) => r.url.path.endsWith('/Profile/corrections')), isFalse);
    });

    testWidgets('Submit & lock needs the privacy confirmation before posting', (tester) async {
      await pump(tester, submission: 'draft');
      await tester.tap(find.text('Submit & lock'));
      await tester.pumpAndSettle();
      expect(find.text('Privacy Notice'), findsOneWidget);

      final confirm = find.descendant(
        of: find.byType(AlertDialog),
        matching: find.widgetWithText(FilledButton, 'Submit & lock'),
      );
      expect(tester.widget<FilledButton>(confirm).onPressed, isNull);

      await tester.tap(find.byType(CheckboxListTile));
      await tester.pumpAndSettle();
      await tester.tap(confirm);
      await tester.pumpAndSettle();

      final post = log.firstWhere((r) => r.url.path.endsWith('/Profile/submit'));
      expect(post.bodyFields['privacy_ack'], '1');
    });

    testWidgets('locked: no edit, offers Request correction and shows history', (tester) async {
      await pump(
        tester,
        submission: 'submitted',
        corrections: [correction('rejected', note: 'Please attach proof')],
      );
      expect(find.text('Edit profile'), findsNothing);
      expect(find.text('Submit & lock'), findsNothing);
      expect(find.text('Request correction'), findsOneWidget);
      expect(find.text('Submitted (locked)'), findsOneWidget);
      expect(find.textContaining('Please attach proof'), findsOneWidget);
    });

    testWidgets('a pending request replaces the button with a notice', (tester) async {
      await pump(tester, submission: 'submitted', corrections: [correction('pending')]);
      expect(find.text('Request correction'), findsNothing);
      expect(find.textContaining('awaiting administrator review'), findsOneWidget);
    });

    testWidgets('correction form refuses to send when nothing changed', (tester) async {
      await pump(tester, submission: 'submitted');
      await tester.tap(find.text('Request correction'));
      await tester.pumpAndSettle();
      // The reason is the last field of the form.
      await tester.enterText(
        find.byType(TextFormField).last,
        'I just want to test this',
      );
      await tester.ensureVisible(find.text('Send request'));
      await tester.tap(find.text('Send request'));
      await tester.pumpAndSettle();
      expect(find.textContaining('No changes were detected'), findsWidgets);
      expect(log.any((r) => r.url.path.endsWith('/Profile/requestCorrection')), isFalse);
    });
  });
}
