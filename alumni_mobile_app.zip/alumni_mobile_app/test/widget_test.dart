import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:alumni_mobile_app/data/notifiers.dart';
import 'package:alumni_mobile_app/services/api_service.dart';
import 'package:alumni_mobile_app/services/auth_client.dart';
import 'package:alumni_mobile_app/services/token_store.dart';
import 'package:alumni_mobile_app/views/widgets/widget_tree.dart';
import 'helpers.dart';

const _ok = {'status': 'success', 'success': true, 'message': 'OK'};

http.Response _route(http.Request r, List<http.Request> log) {
  log.add(r);
  final p = r.url.path;
  if (p.endsWith('/Auth/login')) {
    if (r.bodyFields['password'] == 'correct-horse') {
      return jsonResponse({..._ok, 'token': 'tok123', 'user': userJson});
    }
    return jsonResponse({
      'status': 'error',
      'message': 'Invalid username or password.',
    }, 401);
  }
  if (p.endsWith('/Auth/me')) return jsonResponse({..._ok, 'user': userJson});
  if (p.endsWith('/Auth/logout')) {
    return jsonResponse({..._ok, 'message': 'Logged out.'});
  }
  if (p.endsWith('/Dashboard/summary')) {
    return jsonResponse({
      ..._ok,
      'data': {
        'alumni': {
          'first_name': 'Juan',
          'alumni_number': 'A-2020-001',
          'verification_status': 'verified',
        },
        'attendance': {'attended': 1, 'total': 2, 'rate': 50},
        'attended': [],
        'announcements': [
          {'id': 1, 'title': 'Alumni Homecoming', 'content': 'Join us'},
        ],
        'events': [],
        'studies': [],
      },
    });
  }
  if (p.endsWith('/Lookups/all')) {
    return jsonResponse({
      ..._ok,
      'data': {
        'employment_statuses': [
          {'id': 1, 'name': 'Employed'},
        ],
      },
    });
  }
  if (p.endsWith('/Employments/all')) return jsonResponse({'data': []});
  return jsonResponse({'data': []});
}

void main() {
  late MemoryTokenStore store;
  late List<http.Request> log;

  ApiService buildApi() => ApiService(
    baseUrl: 'http://localhost/alumni_tracking_system/Api',
    client: AuthClient(store, inner: MockClient((r) async => _route(r, log))),
  );

  Future<void> pumpApp(WidgetTester tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final api = buildApi();
    addTearDown(api.close);
    await tester.pumpWidget(
      MaterialApp(home: WidgetTree(api: api, tokenStore: store)),
    );
    await tester.pumpAndSettle();
  }

  setUp(() {
    store = MemoryTokenStore();
    log = [];
    sessionNotifier.value = null;
    selectedPageNotifier.value = 0;
  });

  testWidgets('signed-out users see the login page, not protected data', (
    tester,
  ) async {
    await pumpApp(tester);
    expect(find.text('Alumni Portal'), findsOneWidget);
    expect(find.text('Log in'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
    expect(log.where((r) => r.url.path.contains('Dashboard')), isEmpty);
  });

  testWidgets('login form validates empty fields before any request', (
    tester,
  ) async {
    await pumpApp(tester);
    await tester.tap(find.text('Log in'));
    await tester.pumpAndSettle();
    expect(find.text('Enter your username or email.'), findsOneWidget);
    expect(find.text('Enter your password.'), findsOneWidget);
    expect(log, isEmpty);
  });

  testWidgets('invalid credentials show the server message', (tester) async {
    await pumpApp(tester);
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Username or email'),
      'juan',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Password'),
      'wrong',
    );
    await tester.tap(find.text('Log in'));
    await tester.pumpAndSettle();
    expect(find.text('Invalid username or password.'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
    expect(await store.read(), isNull);
  });

  testWidgets('valid login opens the app and stores the token', (tester) async {
    await pumpApp(tester);
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Username or email'),
      'juan',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Password'),
      'correct-horse',
    );
    await tester.tap(find.text('Log in'));
    await tester.pumpAndSettle();
    expect(find.byType(NavigationDestination), findsNWidgets(5));
    expect(find.text('Welcome back, Juan'), findsOneWidget);
    expect(find.text('Alumni Homecoming'), findsOneWidget);
    expect(await store.read(), 'tok123');
  });

  testWidgets('a saved token restores the session without logging in', (
    tester,
  ) async {
    store = MemoryTokenStore('saved-token');
    await pumpApp(tester);
    expect(find.byType(NavigationBar), findsOneWidget);
    expect(
      log.where((r) => r.headers['authorization'] == 'Bearer saved-token'),
      isNotEmpty,
    );
  });

  testWidgets('logout confirms, revokes the token and returns to login', (
    tester,
  ) async {
    store = MemoryTokenStore('saved-token');
    await pumpApp(tester);
    await tester.tap(find.byTooltip('Log out').first);
    await tester.pumpAndSettle();
    expect(find.byType(AlertDialog), findsOneWidget);
    await tester.tap(
      find.descendant(
        of: find.byType(AlertDialog),
        matching: find.text('Log out'),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Log in'), findsOneWidget);
    expect(await store.read(), isNull);
    expect(log.any((r) => r.url.path.endsWith('/Auth/logout')), true);
  });

  testWidgets('bottom navigation switches between the five sections', (
    tester,
  ) async {
    store = MemoryTokenStore('saved-token');
    await pumpApp(tester);
    await tester.tap(find.text('Records'));
    await tester.pumpAndSettle();
    expect(find.text('Employment'), findsWidgets);
    expect(find.text('Licensures'), findsOneWidget);
    await tester.tap(find.text('Updates'));
    await tester.pumpAndSettle();
    expect(find.text('Announcements'), findsOneWidget);
    await tester.tap(find.text('Surveys'));
    await tester.pumpAndSettle();
    expect(
      find.text('There are no active tracer surveys right now.'),
      findsOneWidget,
    );
  });

  testWidgets('employment form blocks submit until required fields are set', (
    tester,
  ) async {
    store = MemoryTokenStore('saved-token');
    await pumpApp(tester);
    await tester.tap(find.text('Records'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Employment').first);
    await tester.pumpAndSettle();
    expect(
      find.text('No employment records yet. Tap + to add one.'),
      findsOneWidget,
    );
    await tester.tap(find.byTooltip('Add employment record'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('Save'));
    await tester.tap(find.text('Save'));
    await tester.pumpAndSettle();
    expect(find.text('Select Employment status.'), findsOneWidget);
    expect(
      log.any((r) => r.url.path.endsWith('/Employments/add')),
      false,
    );
  });
}
