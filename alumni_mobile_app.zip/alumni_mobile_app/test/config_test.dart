import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:alumni_mobile_app/config/api_config.dart';

void main() {
  test('base URL is configurable, normalised, and has an emulator fallback', () {
    dotenv.loadFromString(envString: 'API_BASE_URL=http://192.168.1.50/alumni_tracking_system/Api/');
    expect(ApiConfig.baseUrl, 'http://192.168.1.50/alumni_tracking_system/Api');
    dotenv.loadFromString(envString: 'API_BASE_URL=https://alumni.example.edu/Api');
    expect(ApiConfig.baseUrl, 'https://alumni.example.edu/Api');
    dotenv.loadFromString(envString: 'API_BASE_URL=');
    expect(ApiConfig.baseUrl, 'http://10.0.2.2/alumni_tracking_system/Api');
  });
}
