import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'data/notifiers.dart';
import 'theme/app_theme.dart';
import 'views/widgets/widget_tree.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env', isOptional: true);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<bool>(
    valueListenable: isDarkModeNotifier,
    builder: (context, isDarkMode, child) => MaterialApp(
      title: 'Alumni Portal',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(dark: isDarkMode),
      home: const WidgetTree(),
    ),
  );
}
