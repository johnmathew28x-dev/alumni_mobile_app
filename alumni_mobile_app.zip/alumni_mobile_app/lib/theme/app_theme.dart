import 'package:flutter/material.dart';

abstract final class AppTheme {
  static const navy = Color(0xFF0B3D91);
  static const navyDark = Color(0xFF082A66);
  static const gold = Color(0xFFD4A017);
  static const page = Color(0xFFF4F6FA);
  static const ink = Color(0xFF17243A);
  static const muted = Color(0xFF65738A);

  static ThemeData build({required bool dark}) {
    final brightness = dark ? Brightness.dark : Brightness.light;
    final scheme = ColorScheme.fromSeed(
      seedColor: navy,
      brightness: brightness,
    ).copyWith(
      primary: dark ? const Color(0xFF91B6FF) : navy,
      onPrimary: dark ? const Color(0xFF071D3F) : Colors.white,
      secondary: gold,
      onSecondary: const Color(0xFF201800),
      surface: dark ? const Color(0xFF111827) : page,
      error: const Color(0xFFB42318),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      appBarTheme: AppBarTheme(
        backgroundColor: dark ? const Color(0xFF111827) : navyDark,
        foregroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: .1,
        ),
      ),
      cardTheme: CardThemeData(
        color: dark ? const Color(0xFF182235) : Colors.white,
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: dark ? const Color(0xFF29364C) : const Color(0xFFE4E9F2),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF202B3D) : const Color(0xFFF5F7FB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: dark ? const Color(0xFF344258) : const Color(0xFFE1E7F0),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.primary, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        backgroundColor: dark ? const Color(0xFF111827) : Colors.white,
        indicatorColor: dark
            ? const Color(0xFF263A5A)
            : const Color(0xFFFFF3CF),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 11,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          );
        }),
      ),
      snackBarTheme: const SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
      ),
      dividerTheme: DividerThemeData(
        color: dark ? const Color(0xFF29364C) : const Color(0xFFE8ECF3),
      ),
    );
  }
}
