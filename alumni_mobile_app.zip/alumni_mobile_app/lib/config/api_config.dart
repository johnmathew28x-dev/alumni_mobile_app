import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiConfig {
  static String get baseUrl {
    final configured = dotenv.isInitialized
        ? dotenv.env['API_BASE_URL']
        : null;
    return (configured == null || configured.trim().isEmpty
            ? 'http://10.0.2.2/alumni_tracking_system/Api' //Fallback for the Android emulator; set API_BASE_URL in .env for other setups
            : configured.trim())
        .replaceFirst(RegExp(r'/+$'), '');
  }
}
