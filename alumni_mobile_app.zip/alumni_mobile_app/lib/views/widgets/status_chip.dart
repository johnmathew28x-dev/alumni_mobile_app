import 'package:flutter/material.dart';

/// Small coloured label for verification / account / request statuses.
class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final (Color bg, Color fg) = switch (status) {
      'verified' || 'approved' || 'active' || 'submitted' => (
        Colors.green.shade100,
        Colors.green.shade900,
      ),
      'rejected' || 'inactive' || 'archived' => (
        scheme.errorContainer,
        scheme.onErrorContainer,
      ),
      _ => (Colors.amber.shade100, Colors.amber.shade900),
    };
    final label = status.isEmpty
        ? status
        : status[0].toUpperCase() + status.substring(1);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(label, style: TextStyle(color: fg, fontSize: 12)),
    );
  }
}

/// Circle avatar that shows the uploaded picture, or an initial when none.
class PersonAvatar extends StatelessWidget {
  final String name;
  final String? pictureUrl;
  final bool hasPicture;
  final double radius;
  const PersonAvatar({
    super.key,
    required this.name,
    this.pictureUrl,
    this.hasPicture = false,
    this.radius = 20,
  });

  @override
  Widget build(BuildContext context) {
    final show = hasPicture && pictureUrl != null;
    return CircleAvatar(
      radius: radius,
      backgroundImage: show ? NetworkImage(pictureUrl!) : null,
      child: show
          ? null
          : Text(name.isEmpty ? '?' : name[0].toUpperCase()),
    );
  }
}
