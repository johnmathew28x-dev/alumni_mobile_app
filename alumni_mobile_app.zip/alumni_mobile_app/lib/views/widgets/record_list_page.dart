import 'package:flutter/material.dart';
import '../../services/api_helpers.dart';
import 'async_body.dart';

/// Generic list + add / edit / delete screen used by the alumni record pages
/// (programs, employment, licensures, examinations, trainings). It keeps the
/// demo's behaviour: pull-to-refresh, "+" button, edit/delete icons, delete
/// confirmation, snackbars, and an empty state.
class RecordListPage<T> extends StatefulWidget {
  final String title;
  final String noun; // e.g. "employment record"
  final IconData icon;
  final Future<List<T>> Function() load;
  final String Function(T item) titleOf;
  final String Function(T item) subtitleOf;
  final Future<void> Function(T item) onDelete;

  /// Builds the add (existing == null) or edit page. It must pop(true) on save.
  final Widget Function(T? existing) formBuilder;
  const RecordListPage({
    super.key,
    required this.title,
    required this.noun,
    required this.icon,
    required this.load,
    required this.titleOf,
    required this.subtitleOf,
    required this.onDelete,
    required this.formBuilder,
  });

  @override
  State<RecordListPage<T>> createState() => _RecordListPageState<T>();
}

class _RecordListPageState<T> extends State<RecordListPage<T>> {
  final _body = GlobalKey<AsyncBodyState<List<T>>>();

  String get _sentence =>
      widget.noun[0].toUpperCase() + widget.noun.substring(1);

  Future<void> _open(T? existing) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => widget.formBuilder(existing)),
    );
    if (!mounted || saved != true) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$_sentence ${existing == null ? 'added' : 'updated'} successfully.',
        ),
      ),
    );
    await _body.currentState?.reload();
  }

  Future<void> _delete(T item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete ${widget.noun}?'),
        content: Text(
          'Are you sure you want to delete "${widget.titleOf(item)}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await widget.onDelete(item);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$_sentence deleted successfully.')),
      );
      await _body.currentState?.reload();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(cleanError(error))));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: AsyncBody<List<T>>(
      key: _body,
      load: widget.load,
      isEmpty: (items) => items.isEmpty,
      emptyMessage: 'No ${widget.noun}s yet. Tap + to add one.',
      builder: (context, items) => ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
        children: [
          for (final item in items)
            Card(
              child: ListTile(
                leading: Icon(widget.icon),
                title: Text(widget.titleOf(item)),
                subtitle: Text(widget.subtitleOf(item), maxLines: 4),
                isThreeLine: widget.subtitleOf(item).contains('\n'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'Edit ${widget.noun}',
                      icon: const Icon(Icons.edit_outlined),
                      onPressed: () => _open(item),
                    ),
                    IconButton(
                      tooltip: 'Delete ${widget.noun}',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _delete(item),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    ),
    floatingActionButton: FloatingActionButton(
      tooltip: 'Add ${widget.noun}',
      onPressed: () => _open(null),
      child: const Icon(Icons.add),
    ),
  );
}
