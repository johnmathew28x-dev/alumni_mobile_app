import 'package:flutter/material.dart';
import '../../models/gts_summary_model.dart';

class StatItem {
  final IconData icon;
  final String label;
  final String value;
  const StatItem(this.icon, this.label, this.value);
}

/// Two-column grid of number tiles.
class StatGrid extends StatelessWidget {
  final List<StatItem> items;
  const StatGrid({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return LayoutBuilder(
      builder: (context, box) {
        final width = (box.maxWidth - 12) / 2;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            for (final item in items)
              SizedBox(
                width: width,
                child: Card(
                  margin: EdgeInsets.zero,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(item.icon, color: theme.colorScheme.primary),
                        const SizedBox(height: 8),
                        Text(item.value, style: theme.textTheme.headlineSmall),
                        Text(item.label, style: theme.textTheme.bodySmall),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

String percent(double? value) =>
    value == null ? '—' : '${value.toStringAsFixed(value % 1 == 0 ? 0 : 1)}%';

/// Graduate Tracer Survey headline figures.
class GtsCard extends StatelessWidget {
  final GtsSummary gts;
  const GtsCard({super.key, required this.gts});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    Widget row(String label, String value) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: theme.textTheme.titleSmall),
        ],
      ),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Graduate Tracer Survey', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            if (gts.respondents == 0)
              const Text('No surveys submitted yet.')
            else ...[
              if (!gts.reliable)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    'Only ${gts.respondents} submitted so far; percentages '
                    'are not yet reliable.',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              row('Surveys submitted', '${gts.respondents}'),
              row('Completion rate', percent(gts.completionRate)),
              row('Employment rate', percent(gts.employmentRate)),
              row('Degree-related', percent(gts.relatedRate)),
              row('Curriculum relevant', percent(gts.relevanceRate)),
            ],
          ],
        ),
      ),
    );
  }
}
