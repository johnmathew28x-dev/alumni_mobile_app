import 'package:flutter/material.dart';
import '../../models/lookup_model.dart';
import '../../services/api_helpers.dart';
import '../../services/api_service.dart';
import '../../services/lookup_service.dart';

String formatDate(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-'
    '${d.month.toString().padLeft(2, '0')}-'
    '${d.day.toString().padLeft(2, '0')}';

const _gap = EdgeInsets.only(bottom: 16);

String _label(String label, bool mandatory) => mandatory ? '$label *' : label;

Widget appTextField({
  required TextEditingController controller,
  required String label,
  bool mandatory = false,
  int? maxLength,
  int maxLines = 1,
  bool obscure = false,
  TextInputType? keyboardType,
  String? Function(String value)? validator,
}) => Padding(
  padding: _gap,
  child: TextFormField(
    controller: controller,
    maxLength: maxLength,
    maxLines: maxLines,
    obscureText: obscure,
    keyboardType: keyboardType,
    decoration: InputDecoration(labelText: _label(label, mandatory)),
    validator: (raw) {
      final value = (raw ?? '').trim();
      if (mandatory && value.isEmpty) return 'Enter $label.';
      return validator?.call(value);
    },
  ),
);

/// Optional/required four-digit year check shared by several forms.
String? validateYear(String value, {required int max, bool mandatory = false}) {
  if (value.isEmpty) return mandatory ? 'Enter a year.' : null;
  final year = int.tryParse(value);
  if (year == null || value.length != 4 || year < 1950 || year > max) {
    return 'Enter a valid year (1950-$max).';
  }
  return null;
}

class LookupDropdown extends StatelessWidget {
  final String label;
  final List<LookupItem> items;
  final int? value;
  final ValueChanged<int?> onChanged;
  final bool mandatory;
  const LookupDropdown({
    super.key,
    required this.label,
    required this.items,
    required this.value,
    required this.onChanged,
    this.mandatory = false,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: _gap,
    child: DropdownButtonFormField<int>(
      initialValue: items.any((i) => i.id == value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: _label(label, mandatory)),
      items: [
        if (!mandatory)
          const DropdownMenuItem<int>(value: null, child: Text('None')),
        for (final item in items)
          DropdownMenuItem<int>(
            value: item.id,
            child: Text(item.name, overflow: TextOverflow.ellipsis),
          ),
      ],
      onChanged: onChanged,
      validator: (v) => mandatory && v == null ? 'Select $label.' : null,
    ),
  );
}

class ChoiceDropdown extends StatelessWidget {
  final String label;
  final List<String> options;
  final String? value;
  final ValueChanged<String?> onChanged;
  final bool mandatory;
  const ChoiceDropdown({
    super.key,
    required this.label,
    required this.options,
    required this.value,
    required this.onChanged,
    this.mandatory = false,
  });

  @override
  Widget build(BuildContext context) => Padding(
    padding: _gap,
    child: DropdownButtonFormField<String>(
      initialValue: options.contains(value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: _label(label, mandatory)),
      items: [
        if (!mandatory)
          const DropdownMenuItem<String>(value: null, child: Text('None')),
        for (final option in options)
          DropdownMenuItem<String>(value: option, child: Text(option)),
      ],
      onChanged: onChanged,
      validator: (v) => mandatory && v == null ? 'Select $label.' : null,
    ),
  );
}

/// Read-only field that opens a date picker and stores yyyy-MM-dd.
class DateField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool mandatory;
  final DateTime firstDate;
  final DateTime lastDate;
  final bool enabled;
  final String? Function(String value)? validator;
  DateField({
    super.key,
    required this.controller,
    required this.label,
    required this.lastDate,
    DateTime? firstDate,
    this.mandatory = false,
    this.enabled = true,
    this.validator,
  }) : firstDate = firstDate ?? DateTime(1950);

  Future<void> _pick(BuildContext context) async {
    var initial = DateTime.tryParse(controller.text) ?? lastDate;
    if (initial.isBefore(firstDate)) initial = firstDate;
    if (initial.isAfter(lastDate)) initial = lastDate;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: firstDate,
      lastDate: lastDate,
    );
    if (picked != null) controller.text = formatDate(picked);
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: _gap,
    child: ListenableBuilder(
      listenable: controller,
      builder: (context, _) => TextFormField(
        controller: controller,
        readOnly: true,
        enabled: enabled,
        onTap: enabled ? () => _pick(context) : null,
        decoration: InputDecoration(
          labelText: _label(label, mandatory),
          suffixIcon: !mandatory && enabled && controller.text.isNotEmpty
              ? IconButton(
                  tooltip: 'Clear $label',
                  icon: const Icon(Icons.clear),
                  onPressed: controller.clear,
                )
              : const Icon(Icons.calendar_today_outlined),
        ),
        validator: (raw) {
          final value = (raw ?? '').trim();
          if (mandatory && value.isEmpty) return 'Select $label.';
          return validator?.call(value);
        },
      ),
    ),
  );
}

/// Fetches the dropdown lookups once, then builds the form. Shows its own
/// loading and retry states.
class LookupGate extends StatefulWidget {
  final ApiService api;
  final String title;
  final Widget Function(BuildContext context, Lookups lookups) builder;
  const LookupGate({
    super.key,
    required this.api,
    required this.title,
    required this.builder,
  });

  @override
  State<LookupGate> createState() => _LookupGateState();
}

class _LookupGateState extends State<LookupGate> {
  late Future<Lookups> _future = LookupService(widget.api).getAll();

  @override
  Widget build(BuildContext context) => FutureBuilder<Lookups>(
    future: _future,
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done) {
        return Scaffold(
          appBar: AppBar(title: Text(widget.title)),
          body: const Center(child: CircularProgressIndicator()),
        );
      }
      if (snapshot.hasError) {
        return Scaffold(
          appBar: AppBar(title: Text(widget.title)),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    cleanError(snapshot.error!),
                    textAlign: TextAlign.center,
                  ),
                  TextButton(
                    onPressed: () => setState(
                      () => _future = LookupService(widget.api).getAll(),
                    ),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
        );
      }
      return widget.builder(context, snapshot.data!);
    },
  );
}

/// Form page chrome: validation, saving state, error display, pop(true) on success.
class FormScaffold extends StatefulWidget {
  final String title;
  final List<Widget> fields;
  final Future<void> Function() onSave;
  final String saveLabel;
  const FormScaffold({
    super.key,
    required this.title,
    required this.fields,
    required this.onSave,
    this.saveLabel = 'Save',
  });

  @override
  State<FormScaffold> createState() => _FormScaffoldState();
}

class _FormScaffoldState extends State<FormScaffold> {
  final _form = GlobalKey<FormState>();
  bool _saving = false;
  String? _error;

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await widget.onSave();
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      final message = cleanError(error);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
      setState(() {
        _saving = false;
        _error = message;
      });
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !_saving,
    child: Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ...widget.fields,
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    _error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(_saving ? 'Saving...' : widget.saveLabel),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
