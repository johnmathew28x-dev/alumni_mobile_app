import 'package:flutter/material.dart';
import '../../data/notifiers.dart';
import '../../models/session_user.dart';
import '../../services/api_helpers.dart';
import '../../services/api_service.dart';
import '../../services/auth_client.dart';
import '../../services/auth_service.dart';
import '../../services/token_store.dart';
import '../pages/dashboard/index.dart';
import '../pages/login/index.dart';
import '../pages/profile/index.dart';
import '../pages/records/index.dart';
import '../pages/tracer/index.dart';
import '../pages/updates/index.dart';
import 'navbar_widget.dart';

/// App root: restores a saved session, shows the login page when signed out,
/// and the main tabbed shell when signed in.
///
/// [api] and [tokenStore] can be injected (tests); otherwise the real
/// token store and an [AuthClient]-backed [ApiService] are created.
class WidgetTree extends StatefulWidget {
  final ApiService? api;
  final TokenStore? tokenStore;
  const WidgetTree({super.key, this.api, this.tokenStore});
  @override
  State<WidgetTree> createState() => _WidgetTreeState();
}

class _WidgetTreeState extends State<WidgetTree> {
  late final TokenStore _tokens = widget.tokenStore ?? const SecureTokenStore();
  late final ApiService _api =
      widget.api ??
      ApiService(client: AuthClient(_tokens, onUnauthorized: _sessionExpired));
  late final AuthService _auth = AuthService(_api, _tokens);

  bool _booting = true;
  String? _bootError;
  String? _notice;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  @override
  void dispose() {
    if (widget.api == null) _api.close();
    super.dispose();
  }

  void _sessionExpired() {
    if (!mounted) return;
    selectedPageNotifier.value = 0;
    sessionNotifier.value = null;
    setState(() => _notice = 'Your session has expired. Please log in again.');
  }

  Future<void> _restore() async {
    setState(() {
      _booting = true;
      _bootError = null;
    });
    try {
      final user = await _auth.restore();
      if (!mounted) return;
      sessionNotifier.value = user;
    } catch (error) {
      if (!mounted) return;
      _bootError = cleanError(error);
    }
    if (mounted) setState(() => _booting = false);
  }

  void _loggedIn(SessionUser user) {
    selectedPageNotifier.value = 0;
    sessionNotifier.value = user;
    setState(() => _notice = null);
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('You will need to log in again to use the app.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Log out'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    await _auth.logout();
    if (!mounted) return;
    selectedPageNotifier.value = 0;
    sessionNotifier.value = null;
    setState(() => _notice = null);
  }

  @override
  Widget build(BuildContext context) {
    if (_booting) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_bootError != null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_bootError!, textAlign: TextAlign.center),
                const SizedBox(height: 8),
                FilledButton(onPressed: _restore, child: const Text('Retry')),
                TextButton(
                  onPressed: () async {
                    await _tokens.clear();
                    if (!mounted) return;
                    setState(() => _bootError = null);
                  },
                  child: const Text('Sign in again'),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return ValueListenableBuilder<SessionUser?>(
      valueListenable: sessionNotifier,
      builder: (context, user, child) => user == null
          ? LoginPage(auth: _auth, onLoggedIn: _loggedIn, notice: _notice)
          : _homeFor(user),
    );
  }

  /// The mobile app is for alumni. Staff and administrator work stays in the
  /// web portal, so their accounts do not receive mobile navigation.
  Widget _homeFor(SessionUser user) {
    if (user.role == SessionUser.roleAlumni) {
      return _Shell(api: _api, onSignOut: _logout);
    }
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'This mobile app is for alumni accounts only. Please use the '
                'web portal for administrator or staff tasks.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _logout, child: const Text('Log out')),
            ],
          ),
        ),
      ),
    );
  }
}

class _Shell extends StatelessWidget {
  final ApiService api;
  final Future<void> Function() onSignOut;
  const _Shell({required this.api, required this.onSignOut});

  static const _titles = ['Home', 'Records', 'Updates', 'Surveys', 'Profile'];

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
    valueListenable: selectedPageNotifier,
    builder: (context, index, child) => Scaffold(
      appBar: AppBar(
        leadingWidth: 52,
        leading: Padding(
          padding: const EdgeInsets.only(left: 14, top: 8, bottom: 8),
          child: Image.asset('assets/images/logo.webp'),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_titles[index]),
            const Text(
              'COLLEGE OF EDUCATION',
              style: TextStyle(
                color: Color(0xFFD4A017),
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        actions: [
          ValueListenableBuilder<bool>(
            valueListenable: isDarkModeNotifier,
            builder: (context, isDarkMode, child) => IconButton(
              tooltip: isDarkMode
                  ? 'Switch to Light Mode'
                  : 'Switch to Dark Mode',
              onPressed: () {
                isDarkModeNotifier.value = !isDarkModeNotifier.value;
              },
              icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
            ),
          ),
          IconButton(
            tooltip: 'Log out',
            onPressed: onSignOut,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: [
        DashboardPage(api: api),
        RecordsPage(api: api),
        UpdatesPage(api: api),
        TracerPage(api: api),
        ProfilePage(api: api, onSignOut: onSignOut),
      ][index],
      bottomNavigationBar: const NavbarWidget(),
    ),
  );
}
