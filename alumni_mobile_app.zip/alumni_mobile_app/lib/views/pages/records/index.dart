import 'package:flutter/material.dart';
import '../../../services/api_service.dart';
import '../academics/index.dart';
import '../employments/index.dart';
import '../licensures/index.dart';
import '../trainings/index.dart';

class RecordsPage extends StatelessWidget {
  final ApiService api;
  const RecordsPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData icon, String title, String subtitle, Widget page) =>
        Card(
          child: ListTile(
            leading: Icon(icon),
            title: Text(title),
            subtitle: Text(subtitle),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => page),
            ),
          ),
        );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        tile(
          Icons.school_outlined,
          'Educational background',
          'Programs and graduation',
          AcademicsPage(api: api),
        ),
        tile(
          Icons.work_outline,
          'Employment',
          'Jobs and employment history',
          EmploymentsPage(api: api),
        ),
        tile(
          Icons.verified_outlined,
          'Licensures',
          'Licenses and professional examination history',
          LicensuresPage(api: api),
        ),
        tile(
          Icons.workspace_premium_outlined,
          'Trainings & advanced studies',
          'Seminars, courses, graduate studies',
          TrainingsPage(api: api),
        ),
      ],
    );
  }
}
