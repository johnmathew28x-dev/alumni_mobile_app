import 'package:flutter/material.dart';
import '../../../models/lookup_model.dart';
import '../../../services/api_helpers.dart';
import '../../../services/api_service.dart';
import '../../../services/registration_service.dart';
import '../../widgets/form_fields.dart';

class RegisterPage extends StatefulWidget {
  final ApiService api;
  const RegisterPage({super.key, required this.api});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  List<LookupItem>? _programs;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final programs = await RegistrationService(widget.api).getPrograms();
      if (!mounted) return;
      setState(() => _programs = programs);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = cleanError(error));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final programs = _programs;
    if (programs != null) {
      return _RegisterForm(api: widget.api, programs: programs);
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: Center(
        child: _loading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error ?? 'Unable to load programs.',
                        textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    TextButton(onPressed: _load, child: const Text('Retry')),
                  ],
                ),
              ),
      ),
    );
  }
}

class _RegisterForm extends StatefulWidget {
  final ApiService api;
  final List<LookupItem> programs;
  const _RegisterForm({required this.api, required this.programs});

  @override
  State<_RegisterForm> createState() => _RegisterFormState();
}

class _RegisterFormState extends State<_RegisterForm> {
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  final _year = TextEditingController();
  int? _programId;

  static final _emailPattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

  @override
  void dispose() {
    _first.dispose();
    _last.dispose();
    _username.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    _year.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FormScaffold(
    title: 'Create account',
    saveLabel: 'Register',
    onSave: () => RegistrationService(widget.api).register(
      RegistrationInput(
        firstName: _first.text,
        lastName: _last.text,
        username: _username.text,
        email: _email.text,
        password: _password.text,
        confirmPassword: _confirm.text,
        programId: _programId!,
        graduationYear: int.parse(_year.text.trim()),
      ),
    ),
    fields: [
      appTextField(
        controller: _first,
        label: 'First name',
        mandatory: true,
        maxLength: 100,
      ),
      appTextField(
        controller: _last,
        label: 'Last name',
        mandatory: true,
        maxLength: 100,
      ),
      appTextField(
        controller: _username,
        label: 'Username',
        mandatory: true,
        maxLength: 55,
        validator: (v) =>
            v.contains('@') ? 'Username cannot contain the @ symbol.' : null,
      ),
      appTextField(
        controller: _email,
        label: 'Email',
        mandatory: true,
        maxLength: 150,
        keyboardType: TextInputType.emailAddress,
        validator: (v) =>
            _emailPattern.hasMatch(v) ? null : 'Enter a valid email address.',
      ),
      LookupDropdown(
        label: 'Program',
        items: widget.programs,
        value: _programId,
        mandatory: true,
        onChanged: (v) => setState(() => _programId = v),
      ),
      appTextField(
        controller: _year,
        label: 'Graduation year',
        mandatory: true,
        keyboardType: TextInputType.number,
        maxLength: 4,
        validator: (v) =>
            validateYear(v, max: DateTime.now().year + 6, mandatory: true),
      ),
      appTextField(
        controller: _password,
        label: 'Password',
        mandatory: true,
        obscure: true,
        validator: (_) => _password.text.length < 8
            ? 'Password must be at least 8 characters.'
            : null,
      ),
      appTextField(
        controller: _confirm,
        label: 'Confirm password',
        mandatory: true,
        obscure: true,
        validator: (_) =>
            _confirm.text != _password.text ? 'Passwords do not match.' : null,
      ),
    ],
  );
}
