import 'package:flutter/material.dart';
import '../../../models/exam_model.dart';
import '../../../models/licensure_model.dart';
import '../../../services/api_helpers.dart';
import '../../../services/api_service.dart';
import '../../../services/exam_service.dart';
import '../../../services/licensure_service.dart';
import '../../widgets/async_body.dart';
import '../exams/form.dart';
import 'form.dart';

class LicensuresPage extends StatefulWidget {
  final ApiService api;
  const LicensuresPage({super.key, required this.api});

  @override
  State<LicensuresPage> createState() => _LicensuresPageState();
}

class _LicensuresPageState extends State<LicensuresPage> {
  final _body = GlobalKey<AsyncBodyState<_LicensureRecords>>();

  Future<_LicensureRecords> _load() async {
    final licensures = await LicensureService(widget.api).getAll();
    final examinations = await ExamService(widget.api).getAll();
    return _LicensureRecords(licensures, examinations);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Licensures')),
    body: AsyncBody<_LicensureRecords>(
      key: _body,
      load: _load,
      isEmpty: (records) =>
          records.licensures.isEmpty && records.examinations.isEmpty,
      emptyMessage:
          'No licensure or examination records yet. Tap + to add one.',
      builder: (context, records) => ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
        children: [
          if (records.licensures.isNotEmpty) ...[
            _sectionHeading(context, 'Licensure records'),
            for (final record in records.licensures)
              _recordTile(
                icon: Icons.verified_outlined,
                title: record.licenseName,
                subtitle: [
                  record.statusName,
                  if (record.examinationYear != null)
                    'Exam year ${record.examinationYear}',
                ].where((part) => part.isNotEmpty).join(' • '),
                noun: 'licensure record',
                onEdit: () => _openLicensure(record),
                onDelete: () => _confirmDelete(
                  title: record.licenseName,
                  noun: 'licensure record',
                  delete: () => LicensureService(widget.api).delete(record.id),
                ),
              ),
          ],
          if (records.examinations.isNotEmpty) ...[
            _sectionHeading(context, 'Professional examinations'),
            for (final record in records.examinations)
              _recordTile(
                icon: Icons.fact_check_outlined,
                title: record.name,
                subtitle: [
                  record.result,
                  if (record.rating != null) 'Rating ${record.rating}',
                  if (record.dateTaken != null) record.dateTaken!,
                ].join(' • '),
                noun: 'professional examination',
                onEdit: () => _openExamination(record),
                onDelete: () => _confirmDelete(
                  title: record.name,
                  noun: 'professional examination',
                  delete: () => ExamService(widget.api).delete(record.id),
                ),
              ),
          ],
        ],
      ),
    ),
    floatingActionButton: FloatingActionButton(
      tooltip: 'Add licensure or examination record',
      onPressed: _addRecord,
      child: const Icon(Icons.add),
    ),
  );

  Widget _sectionHeading(BuildContext context, String title) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 8, 4, 12),
    child: Text(
      title,
      style: Theme.of(
        context,
      ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
    ),
  );

  Widget _recordTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required String noun,
    required VoidCallback onEdit,
    required VoidCallback onDelete,
  }) => Card(
    child: ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: subtitle.isEmpty ? null : Text(subtitle, maxLines: 3),
      trailing: PopupMenuButton<String>(
        tooltip: 'Actions for $noun',
        onSelected: (action) {
          if (action == 'edit') {
            onEdit();
          } else {
            onDelete();
          }
        },
        itemBuilder: (_) => [
          PopupMenuItem(value: 'edit', child: Text('Edit $noun')),
          PopupMenuItem(value: 'delete', child: Text('Delete $noun')),
        ],
      ),
    ),
  );

  Future<void> _addRecord() async {
    final choice = await showModalBottomSheet<_NewRecordType>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.verified_outlined),
              title: const Text('Add licensure record'),
              onTap: () => Navigator.pop(context, _NewRecordType.licensure),
            ),
            ListTile(
              leading: const Icon(Icons.fact_check_outlined),
              title: const Text('Add professional examination'),
              onTap: () => Navigator.pop(context, _NewRecordType.examination),
            ),
          ],
        ),
      ),
    );
    if (!mounted) return;
    if (choice == _NewRecordType.licensure) {
      await _openLicensure();
    } else if (choice == _NewRecordType.examination) {
      await _openExamination();
    }
  }

  Future<void> _openLicensure([LicensureModel? existing]) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => LicensureFormPage(api: widget.api, existing: existing),
      ),
    );
    await _afterSave(
      saved,
      '${existing == null ? 'Licensure record added' : 'Licensure record updated'} successfully.',
    );
  }

  Future<void> _openExamination([ExamModel? existing]) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ExamFormPage(api: widget.api, existing: existing),
      ),
    );
    await _afterSave(
      saved,
      '${existing == null ? 'Professional examination added' : 'Professional examination updated'} successfully.',
    );
  }

  Future<void> _afterSave(bool? saved, String message) async {
    if (!mounted || saved != true) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
    await _body.currentState?.reload();
  }

  Future<void> _confirmDelete({
    required String title,
    required String noun,
    required Future<void> Function() delete,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete $noun?'),
        content: Text('Are you sure you want to delete "$title"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await delete();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${noun[0].toUpperCase()}${noun.substring(1)} deleted successfully.',
          ),
        ),
      );
      await _body.currentState?.reload();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(cleanError(error))));
    }
  }
}

class _LicensureRecords {
  final List<LicensureModel> licensures;
  final List<ExamModel> examinations;

  const _LicensureRecords(this.licensures, this.examinations);
}

enum _NewRecordType { licensure, examination }
