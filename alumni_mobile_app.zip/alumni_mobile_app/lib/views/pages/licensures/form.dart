import 'package:flutter/material.dart';
import '../../../models/licensure_model.dart';
import '../../../services/api_service.dart';
import '../../../services/licensure_service.dart';
import '../../widgets/form_fields.dart';

class LicensureFormPage extends StatefulWidget {
  final ApiService api;
  final LicensureModel? existing;
  const LicensureFormPage({super.key, required this.api, this.existing});
  @override
  State<LicensureFormPage> createState() => _LicensureFormPageState();
}

class _LicensureFormPageState extends State<LicensureFormPage> {
  late final _year = TextEditingController(
    text: widget.existing?.examinationYear?.toString() ?? '',
  );
  late int? _typeId = widget.existing?.licenseTypeId;
  late int? _statusId = widget.existing?.statusId;

  @override
  void dispose() {
    _year.dispose();
    super.dispose();
  }

  Future<void> _save() {
    final service = LicensureService(widget.api);
    final year = _year.text.trim();
    return widget.existing == null
        ? service.add(
            licenseTypeId: _typeId!,
            statusId: _statusId!,
            examinationYear: year,
          )
        : service.update(
            widget.existing!.id,
            licenseTypeId: _typeId!,
            statusId: _statusId!,
            examinationYear: year,
          );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.existing == null
        ? 'Add Licensure'
        : 'Edit Licensure';
    return LookupGate(
      api: widget.api,
      title: title,
      builder: (context, lookups) => FormScaffold(
        title: title,
        onSave: _save,
        fields: [
          LookupDropdown(
            label: 'License type',
            mandatory: true,
            items: lookups.licenseTypes,
            value: _typeId,
            onChanged: (v) => setState(() => _typeId = v),
          ),
          LookupDropdown(
            label: 'Status',
            mandatory: true,
            items: lookups.licensureStatuses,
            value: _statusId,
            onChanged: (v) => setState(() => _statusId = v),
          ),
          appTextField(
            controller: _year,
            label: 'Examination year',
            maxLength: 4,
            keyboardType: TextInputType.number,
            validator: (v) => validateYear(v, max: DateTime.now().year + 1),
          ),
        ],
      ),
    );
  }
}
