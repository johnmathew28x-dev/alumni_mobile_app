import 'package:flutter/material.dart';
import '../../../data/notifiers.dart';
import '../../../models/dashboard_model.dart';
import '../../../services/api_service.dart';
import '../../../services/dashboard_service.dart';
import '../../../theme/app_theme.dart';
import '../../widgets/async_body.dart';

class DashboardPage extends StatelessWidget {
  final ApiService api;
  const DashboardPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) => AsyncBody<DashboardModel>(
    load: DashboardService(api).getSummary,
    builder: (context, data) => ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 32),
      children: [
        _WelcomeCard(data: data),
        const SizedBox(height: 10),
        const _SectionHeading(title: 'At a glance'),
        _AttendanceCard(data: data),
        const _SectionHeading(title: 'Active surveys'),
        if (data.studies.isEmpty)
          const _EmptyCard(
            icon: Icons.assignment_outlined,
            title: 'No active surveys',
            message: 'New tracer surveys will appear here.',
          )
        else
          for (final study in data.studies)
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 5,
                ),
                leading: _IconTile(
                  icon: study.answered
                      ? Icons.task_alt_rounded
                      : Icons.assignment_outlined,
                  color: study.answered ? const Color(0xFF23845B) : AppTheme.navy,
                ),
                title: Text(
                  study.title,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  study.answered
                      ? 'Completed'
                      : (study.inProgress ? 'In progress' : 'Not started'),
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => selectedPageNotifier.value = 3,
              ),
            ),
        const _SectionHeading(title: 'Upcoming events'),
        if (data.events.isEmpty)
          const _EmptyCard(
            icon: Icons.event_outlined,
            title: 'Nothing scheduled',
            message: 'Check back for upcoming alumni events.',
          )
        else
          for (final event in data.events)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _IconTile(
                      icon: Icons.event_available_outlined,
                      color: AppTheme.navy,
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            event.title,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          if (event.eventDate != null) ...[
                            const SizedBox(height: 6),
                            _DetailLine(
                              icon: Icons.calendar_today_outlined,
                              text: event.eventDate!,
                            ),
                          ],
                          if (event.location != null) ...[
                            const SizedBox(height: 4),
                            _DetailLine(
                              icon: Icons.location_on_outlined,
                              text: event.location!,
                            ),
                          ],
                        ],
                      ),
                    ),
                    if (event.isRegistered)
                      const Padding(
                        padding: EdgeInsets.only(left: 8),
                        child: Icon(
                          Icons.check_circle_rounded,
                          color: Color(0xFF23845B),
                          size: 21,
                        ),
                      ),
                  ],
                ),
              ),
            ),
        const _SectionHeading(title: 'Latest announcements'),
        if (data.announcements.isEmpty)
          const _EmptyCard(
            icon: Icons.campaign_outlined,
            title: 'You’re all caught up',
            message: 'Important updates from the college will show here.',
          )
        else
          for (final announcement in data.announcements)
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 5,
                ),
                leading: const _IconTile(
                  icon: Icons.campaign_outlined,
                  color: AppTheme.navy,
                ),
                title: Text(
                  announcement.title,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text(
                    announcement.content,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
      ],
    ),
  );
}

class _WelcomeCard extends StatelessWidget {
  final DashboardModel data;
  const _WelcomeCard({required this.data});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [AppTheme.navy, AppTheme.navyDark],
      ),
      borderRadius: BorderRadius.circular(24),
      boxShadow: const [
        BoxShadow(
          color: Color(0x26082A66),
          blurRadius: 22,
          offset: Offset(0, 10),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Stack(
        children: [
          Positioned(
            top: -50,
            right: -34,
            child: Container(
              width: 165,
              height: 165,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color.fromRGBO(255, 255, 255, .055),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: Image.asset('assets/images/logo.webp'),
                    ),
                    const SizedBox(width: 11),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'COLLEGE OF EDUCATION',
                            style: TextStyle(
                              color: Color(0xFFE3B443),
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.05,
                            ),
                          ),
                          SizedBox(height: 3),
                          Text(
                            'ALUMNI PORTAL',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              letterSpacing: .7,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 23),
                Text(
                  data.firstName.isEmpty
                      ? 'Welcome back'
                      : 'Welcome back, ${data.firstName}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    height: 1.15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -.35,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  data.alumniNumber == null
                      ? 'Stay connected with your alumni community.'
                      : 'Alumni ID  ${data.alumniNumber}',
                  style: const TextStyle(
                    color: Color(0xFFD8E2F2),
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        data.verificationStatus.toLowerCase() == 'verified'
                            ? Icons.verified_rounded
                            : Icons.hourglass_top_rounded,
                        size: 16,
                        color: const Color(0xFFE3B443),
                      ),
                      const SizedBox(width: 7),
                      Text(
                        'Profile ${data.verificationStatus}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class _AttendanceCard extends StatelessWidget {
  final DashboardModel data;
  const _AttendanceCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final hasEvents = data.eventsTotal > 0;
    final rate = data.attendanceRate;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const _IconTile(
                  icon: Icons.event_available_outlined,
                  color: AppTheme.navy,
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Event attendance',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        hasEvents
                            ? '${data.eventsAttended} of ${data.eventsTotal} completed events'
                            : 'No completed events yet',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                if (rate != null)
                  Text(
                    '$rate%',
                    style: const TextStyle(
                      color: AppTheme.navy,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
              ],
            ),
            if (hasEvents) ...[
              const SizedBox(height: 15),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: (data.eventsAttended / data.eventsTotal)
                      .clamp(0.0, 1.0)
                      .toDouble(),
                  minHeight: 7,
                  backgroundColor: const Color(0xFFE9EEF6),
                  valueColor: const AlwaysStoppedAnimation(AppTheme.gold),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _SectionHeading extends StatelessWidget {
  final String title;
  const _SectionHeading({required this.title});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(3, 14, 3, 10),
    child: Text(
      title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white
            : AppTheme.ink,
        fontWeight: FontWeight.w800,
        letterSpacing: -.15,
      ),
    ),
  );
}

class _IconTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _IconTile({required this.icon, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    width: 42,
    height: 42,
    decoration: BoxDecoration(
      color: color.withValues(alpha: .09),
      borderRadius: BorderRadius.circular(13),
    ),
    child: Icon(icon, color: color, size: 21),
  );
}

class _DetailLine extends StatelessWidget {
  final IconData icon;
  final String text;
  const _DetailLine({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Icon(icon, size: 14, color: AppTheme.muted),
      const SizedBox(width: 5),
      Expanded(
        child: Text(
          text,
          style: Theme.of(context).textTheme.bodySmall,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    ],
  );
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  const _EmptyCard({
    required this.icon,
    required this.title,
    required this.message,
  });

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      child: Row(
        children: [
          _IconTile(icon: icon, color: AppTheme.muted),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(message, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}
