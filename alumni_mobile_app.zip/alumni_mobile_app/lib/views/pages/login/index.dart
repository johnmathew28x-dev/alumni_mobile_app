import 'package:flutter/material.dart';
import '../../../models/session_user.dart';
import '../../../services/api_helpers.dart';
import '../../../services/auth_service.dart';
import '../../../theme/app_theme.dart';
import '../register/index.dart';

class LoginPage extends StatefulWidget {
  final AuthService auth;
  final ValueChanged<SessionUser> onLoggedIn;

  /// Shown above the form, e.g. "Your session has expired."
  final String? notice;
  const LoginPage({
    super.key,
    required this.auth,
    required this.onLoggedIn,
    this.notice,
  });

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hidePassword = true;
  String? _error;
  String? _registered;

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final user = await widget.auth.login(
        _username.text.trim(),
        _password.text,
      );
      if (!mounted) return;
      widget.onLoggedIn(user);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = cleanError(error);
      });
    }
  }

  Future<void> _register() async {
    final done = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => RegisterPage(api: widget.auth.api)),
    );
    if (!mounted || done != true) return;
    setState(() {
      _error = null;
      _registered =
          'Registration successful! You can now log in. '
          'An administrator will verify your alumni record.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: AppTheme.build(dark: false),
      child: Scaffold(
        body: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/campus.jpg', fit: BoxFit.cover),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color.fromRGBO(8, 42, 102, .88),
                    Color.fromRGBO(2, 12, 30, .84),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(22),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 430),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(22, 24, 22, 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(26),
                        border: Border.all(color: Colors.white70),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x55000000),
                            blurRadius: 30,
                            offset: Offset(0, 16),
                          ),
                        ],
                      ),
                      child: Form(
                        key: _form,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Center(
                              child: Container(
                                width: 88,
                                height: 88,
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: const Color(0xFFD4A017),
                                    width: 2,
                                  ),
                                ),
                                child: ClipOval(
                                  child: Image.asset('assets/images/logo.webp'),
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),
                            const Text(
                              'COLLEGE OF EDUCATION',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppTheme.navy,
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Alumni Tracking System',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppTheme.muted,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 22),
                            const Text(
                              'Welcome back',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppTheme.ink,
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -.4,
                              ),
                            ),
                            const SizedBox(height: 5),
                            const Text(
                              'Sign in to stay connected with your alumni community.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: AppTheme.muted,
                                fontSize: 13,
                                height: 1.45,
                              ),
                            ),
                            const SizedBox(height: 22),
                            if (_registered != null && _error == null)
                              _NoticeBanner(
                                message: _registered!,
                                color: const Color(0xFF23845B),
                              ),
                            if (widget.notice != null &&
                                _error == null &&
                                _registered == null)
                              _NoticeBanner(
                                message: widget.notice!,
                                color: AppTheme.navy,
                              ),
                            if (_error != null)
                              _NoticeBanner(
                                message: _error!,
                                color: const Color(0xFFB42318),
                              ),
                            TextFormField(
                              controller: _username,
                              enabled: !_busy,
                              autofillHints: const [AutofillHints.username],
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                labelText: 'Username or email',
                                prefixIcon: Icon(Icons.person_outline_rounded),
                              ),
                              validator: (value) =>
                                  (value == null || value.trim().isEmpty)
                                  ? 'Enter your username or email.'
                                  : null,
                            ),
                            const SizedBox(height: 14),
                            TextFormField(
                              controller: _password,
                              enabled: !_busy,
                              obscureText: _hidePassword,
                              autofillHints: const [AutofillHints.password],
                              onFieldSubmitted: (_) => _submit(),
                              decoration: InputDecoration(
                                labelText: 'Password',
                                prefixIcon: const Icon(Icons.lock_outline_rounded),
                                suffixIcon: IconButton(
                                  tooltip: _hidePassword
                                      ? 'Show password'
                                      : 'Hide password',
                                  icon: Icon(
                                    _hidePassword
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                  ),
                                  onPressed: () => setState(
                                    () => _hidePassword = !_hidePassword,
                                  ),
                                ),
                              ),
                              validator: (value) =>
                                  (value == null || value.isEmpty)
                                  ? 'Enter your password.'
                                  : null,
                            ),
                            const SizedBox(height: 19),
                            FilledButton.icon(
                              onPressed: _busy ? null : _submit,
                              icon: _busy
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            const AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    )
                                  : const Icon(Icons.login_rounded),
                              label: Text(_busy ? 'Signing in...' : 'Sign in'),
                            ),
                            const SizedBox(height: 8),
                            TextButton(
                              onPressed: _busy ? null : _register,
                              child: const Text(
                                'New alumnus? Create an account',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NoticeBanner extends StatelessWidget {
  final String message;
  final Color color;
  const _NoticeBanner({required this.message, required this.color});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: color.withValues(alpha: .18)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded, color: color, size: 19),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                height: 1.35,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
