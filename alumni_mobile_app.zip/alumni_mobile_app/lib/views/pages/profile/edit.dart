import 'package:flutter/material.dart';
import '../../../models/profile_model.dart';
import '../../../services/api_service.dart';
import '../../../services/profile_service.dart';
import '../../widgets/form_fields.dart';

/// Edits the profile draft, or, when [correction] is true (profile already
/// submitted and locked), files a correction request for admin review.
class ProfileEditPage extends StatefulWidget {
  final ApiService api;
  final ProfileModel profile;
  final bool correction;
  const ProfileEditPage({
    super.key,
    required this.api,
    required this.profile,
    this.correction = false,
  });
  @override
  State<ProfileEditPage> createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  late final _first = TextEditingController(text: widget.profile.firstName);
  late final _middle = TextEditingController(
    text: widget.profile.middleName ?? '',
  );
  late final _last = TextEditingController(text: widget.profile.lastName);
  late final _suffix = TextEditingController(text: widget.profile.suffix ?? '');
  late final _dob = TextEditingController(text: widget.profile.dateOfBirth ?? '');
  late final _province = TextEditingController(
    text: widget.profile.province ?? '',
  );
  late final _city = TextEditingController(
    text: widget.profile.cityMunicipality ?? '',
  );
  late final _phone = TextEditingController(
    text: widget.profile.contactNumber ?? '',
  );
  late final _address = TextEditingController(text: widget.profile.address ?? '');
  final _reason = TextEditingController();
  late String? _gender = widget.profile.gender;
  late int? _civilId = widget.profile.civilStatusId;
  late int? _regionId = widget.profile.regionId;
  late int? _residenceId = widget.profile.residenceTypeId;

  @override
  void dispose() {
    for (final c in [
      _first,
      _middle,
      _last,
      _suffix,
      _dob,
      _province,
      _city,
      _phone,
      _address,
      _reason,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  ProfileInput _input() => ProfileInput(
    firstName: _first.text.trim(),
    middleName: _middle.text.trim(),
    lastName: _last.text.trim(),
    suffix: _suffix.text.trim(),
    dateOfBirth: _dob.text.trim(),
    gender: _gender!,
    contactNumber: _phone.text.trim(),
    address: _address.text.trim(),
    civilStatusId: _civilId!,
    regionId: _regionId!,
    province: _province.text.trim(),
    cityMunicipality: _city.text.trim(),
    residenceTypeId: _residenceId,
  );

  Future<void> _save() async {
    final input = _input();
    final service = ProfileService(widget.api);
    if (!widget.correction) return service.update(input);

    final saved = widget.profile.toForm();
    final unchanged = input.toForm().entries.every(
      (e) => saved[e.key] == e.value,
    );
    if (unchanged) {
      throw Exception(
        'No changes were detected. Edit at least one field to request a correction.',
      );
    }
    return service.requestCorrection(input, reason: _reason.text);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final youngest = DateTime(now.year - 16, now.month, now.day - 1);
    final title = widget.correction ? 'Request correction' : 'Edit Profile';
    return LookupGate(
      api: widget.api,
      title: title,
      builder: (context, lookups) => FormScaffold(
        title: title,
        saveLabel: widget.correction ? 'Send request' : 'Save',
        onSave: _save,
        fields: [
          if (widget.correction)
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Text(
                'Your information is locked. Change only what is wrong or '
                'outdated; an administrator will review your request before '
                'your record is updated.',
              ),
            ),
          appTextField(
            controller: _first,
            label: 'First name',
            mandatory: true,
            maxLength: 100,
          ),
          appTextField(controller: _middle, label: 'Middle name', maxLength: 100),
          appTextField(
            controller: _last,
            label: 'Last name',
            mandatory: true,
            maxLength: 100,
          ),
          appTextField(controller: _suffix, label: 'Suffix', maxLength: 10),
          ChoiceDropdown(
            label: 'Sex',
            mandatory: true,
            options: const ['Male', 'Female', 'Other'],
            value: _gender,
            onChanged: (v) => setState(() => _gender = v),
          ),
          DateField(
            controller: _dob,
            label: 'Birthday',
            mandatory: true,
            lastDate: youngest,
          ),
          LookupDropdown(
            label: 'Civil status',
            mandatory: true,
            items: lookups.civilStatuses,
            value: _civilId,
            onChanged: (v) => setState(() => _civilId = v),
          ),
          LookupDropdown(
            label: 'Region of origin',
            mandatory: true,
            items: lookups.regions,
            value: _regionId,
            onChanged: (v) => setState(() => _regionId = v),
          ),
          appTextField(
            controller: _province,
            label: 'Province',
            mandatory: true,
            maxLength: 100,
          ),
          appTextField(
            controller: _city,
            label: 'City / municipality',
            maxLength: 100,
          ),
          LookupDropdown(
            label: 'Residence type',
            items: lookups.residenceTypes,
            value: _residenceId,
            onChanged: (v) => setState(() => _residenceId = v),
          ),
          appTextField(
            controller: _phone,
            label: 'Mobile number',
            maxLength: 20,
            keyboardType: TextInputType.phone,
            validator: (v) => v.isEmpty || RegExp(r'^[0-9+\-\s()]{7,20}$').hasMatch(v)
                ? null
                : 'Use 7-20 digits, spaces, + - ( ).',
          ),
          appTextField(
            controller: _address,
            label: 'Address',
            maxLength: 255,
            maxLines: 2,
          ),
          if (widget.correction)
            appTextField(
              controller: _reason,
              label: 'Reason for the correction',
              mandatory: true,
              maxLength: 500,
              maxLines: 3,
              validator: (v) => v.length < 10
                  ? 'Please explain the reason (at least 10 characters).'
                  : null,
            ),
        ],
      ),
    );
  }
}
