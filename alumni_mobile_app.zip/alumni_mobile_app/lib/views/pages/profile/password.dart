import 'package:flutter/material.dart';
import '../../../services/api_service.dart';
import '../../../services/profile_service.dart';
import '../../widgets/form_fields.dart';

class PasswordPage extends StatefulWidget {
  final ApiService api;
  const PasswordPage({super.key, required this.api});
  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final _current = TextEditingController();
  final _next = TextEditingController();
  final _confirm = TextEditingController();

  @override
  void dispose() {
    _current.dispose();
    _next.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FormScaffold(
    title: 'Change Password',
    saveLabel: 'Update password',
    onSave: () => ProfileService(widget.api).changePassword(
      current: _current.text,
      next: _next.text,
      confirm: _confirm.text,
    ),
    fields: [
      appTextField(
        controller: _current,
        label: 'Current password',
        mandatory: true,
        obscure: true,
      ),
      appTextField(
        controller: _next,
        label: 'New password',
        mandatory: true,
        obscure: true,
        validator: (v) =>
            v.length < 8 ? 'New password must be at least 8 characters.' : null,
      ),
      appTextField(
        controller: _confirm,
        label: 'Confirm new password',
        mandatory: true,
        obscure: true,
        validator: (v) =>
            v != _next.text.trim() ? 'Password confirmation does not match.' : null,
      ),
    ],
  );
}
