import 'package:flutter/material.dart';
import '../../../data/notifiers.dart';
import '../../../models/lookup_model.dart';
import '../../../models/profile_correction_model.dart';
import '../../../models/profile_model.dart';
import '../../../services/api_helpers.dart';
import '../../../services/api_service.dart';
import '../../../services/lookup_service.dart';
import '../../../services/profile_service.dart';
import '../../widgets/async_body.dart';
import '../../widgets/status_chip.dart';
import 'edit.dart';
import 'password.dart';

class _ProfileData {
  final ProfileModel profile;
  final Lookups lookups;
  final List<CorrectionRequest> corrections;
  final String? correctionsError;
  const _ProfileData(
    this.profile,
    this.lookups,
    this.corrections,
    this.correctionsError,
  );

  bool get hasPendingCorrection => corrections.any((c) => c.isPending);
}

class ProfilePage extends StatefulWidget {
  final ApiService api;
  final Future<void> Function() onSignOut;
  const ProfilePage({super.key, required this.api, required this.onSignOut});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _body = GlobalKey<AsyncBodyState<_ProfileData>>();
  bool _busy = false;

  Future<_ProfileData> _load() async {
    final service = ProfileService(widget.api);
    final profile = await service.getDetails();
    final lookups = await LookupService(widget.api).getAll();
    // Correction requests only exist once the profile has been submitted.
    var corrections = const <CorrectionRequest>[];
    String? correctionsError;
    if (profile.isLocked) {
      try {
        corrections = await service.getCorrections();
      } catch (error) {
        correctionsError = cleanError(error);
      }
    }
    return _ProfileData(profile, lookups, corrections, correctionsError);
  }

  void _snack(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  Future<void> _edit(ProfileModel profile, {bool correction = false}) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => ProfileEditPage(
          api: widget.api,
          profile: profile,
          correction: correction,
        ),
      ),
    );
    if (!mounted || saved != true) return;
    _snack(
      correction
          ? 'Your correction request has been sent for administrator review.'
          : 'Your information has been saved. It is not locked until you submit it.',
    );
    await _body.currentState?.reload();
  }

  Future<void> _submit(ProfileModel profile) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => const _SubmitDialog(),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await ProfileService(widget.api).submit(profile);
      if (!mounted) return;
      _snack('Your personal information has been submitted and is now locked.');
      await _body.currentState?.reload();
    } catch (error) {
      if (!mounted) return;
      _snack(cleanError(error));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _password() async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => PasswordPage(api: widget.api)),
    );
    if (!mounted || saved != true) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password updated successfully.')),
    );
  }

  Widget _row(String label, String? value) => ListTile(
    dense: true,
    title: Text(label, style: Theme.of(context).textTheme.bodySmall),
    subtitle: Text(
      value == null || value.isEmpty ? '—' : value,
      style: Theme.of(context).textTheme.bodyLarge,
    ),
  );

  static const _reviewLabels = {
    'pending': 'Awaiting review',
    'verified': 'Approved',
    'rejected': 'Rejected',
  };

  Widget _banner(ProfileModel p) => Card(
    color: p.isLocked
        ? Theme.of(context).colorScheme.secondaryContainer
        : Theme.of(context).colorScheme.tertiaryContainer,
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(p.isLocked ? Icons.lock_outline : Icons.info_outline),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              p.isLocked
                  ? 'Your personal information is locked. It was submitted and '
                        'can no longer be edited directly. If something is '
                        'wrong or outdated, use Request correction; an '
                        'administrator will review it.'
                  : 'Your personal information has not been submitted yet. '
                        'Complete it and submit it. Once submitted, it is '
                        'locked and can only be changed through a correction '
                        'request reviewed by an administrator.',
            ),
          ),
        ],
      ),
    ),
  );

  Widget _corrections(_ProfileData d) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('My correction requests', style: theme.textTheme.titleMedium),
            if (d.correctionsError != null)
              Text(
                'Could not load your requests: ${d.correctionsError}',
                style: TextStyle(color: theme.colorScheme.error),
              ),
            if (d.correctionsError == null && d.corrections.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('You have not filed any correction requests.'),
              ),
            for (final r in d.corrections) ...[
              const Divider(height: 24),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      r.created == null
                          ? 'Request #${r.id}'
                          : 'Filed ${r.created!.split(' ').first}',
                      style: theme.textTheme.titleSmall,
                    ),
                  ),
                  StatusChip(r.status),
                ],
              ),
              for (final c in r.changes)
                Text('${c.label}: ${c.oldValue ?? '—'} → ${c.newValue ?? '—'}'),
              if (r.reason != null)
                Text('Reason: ${r.reason}', style: theme.textTheme.bodySmall),
              if (r.reviewNote != null)
                Text(
                  'Admin note: ${r.reviewNote}',
                  style: theme.textTheme.bodySmall,
                ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AsyncBody<_ProfileData>(
    key: _body,
    load: _load,
    builder: (context, d) {
      final p = d.profile;
      final l = d.lookups;
      final user = sessionNotifier.value;
      final picture = user?.pictureUrl;
      // The default avatar is an SVG, which Image.network cannot draw.
      final showPicture = picture != null && !picture.endsWith('.svg');
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundImage: showPicture ? NetworkImage(picture) : null,
              child: showPicture ? null : const Icon(Icons.person, size: 44),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            p.fullName,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          if (p.alumniNumber != null)
            Text('Alumni ID: ${p.alumniNumber}', textAlign: TextAlign.center),
          const SizedBox(height: 16),
          _banner(p),
          Card(
            child: Column(
              children: [
                _row('Sex', p.gender),
                _row('Birthday', p.dateOfBirth),
                _row(
                  'Civil status',
                  Lookups.nameOf(l.civilStatuses, p.civilStatusId),
                ),
                _row('Email', p.email),
                _row('Mobile number', p.contactNumber),
                _row('Address', p.address),
                _row('City / municipality', p.cityMunicipality),
                _row('Province', p.province),
                _row('Region', Lookups.nameOf(l.regions, p.regionId)),
                _row(
                  'Residence type',
                  Lookups.nameOf(l.residenceTypes, p.residenceTypeId),
                ),
                _row(
                  'Profile submission',
                  p.isLocked ? 'Submitted (locked)' : 'Not yet submitted',
                ),
                _row(
                  'Review status',
                  _reviewLabels[p.verificationStatus] ?? p.verificationStatus,
                ),
              ],
            ),
          ),
          if (!p.isLocked) ...[
            FilledButton.icon(
              onPressed: _busy ? null : () => _edit(p),
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Edit profile'),
            ),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(
              onPressed: _busy ? null : () => _submit(p),
              icon: const Icon(Icons.lock_outline),
              label: const Text('Submit & lock'),
            ),
          ] else if (d.hasPendingCorrection)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'A correction request is awaiting administrator review.',
                textAlign: TextAlign.center,
              ),
            )
          else
            FilledButton.icon(
              onPressed: () => _edit(p, correction: true),
              icon: const Icon(Icons.edit_note),
              label: const Text('Request correction'),
            ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _password,
            icon: const Icon(Icons.lock_outline),
            label: const Text('Change password'),
          ),
          if (p.isLocked) ...[const SizedBox(height: 8), _corrections(d)],
        ],
      );
    },
  );
}

/// Privacy confirmation before "Submit & lock" (wording as on the web page).
class _SubmitDialog extends StatefulWidget {
  const _SubmitDialog();

  @override
  State<_SubmitDialog> createState() => _SubmitDialogState();
}

class _SubmitDialogState extends State<_SubmitDialog> {
  bool _ack = false;

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Submit & lock?'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'After submitting, you can no longer edit this information '
            'directly. Changes will need an administrator-approved '
            'correction request.',
          ),
          const SizedBox(height: 12),
          Text('Privacy Notice', style: Theme.of(context).textTheme.titleSmall),
          const Text(
            'Northeastern College collects this information for alumni record '
            'keeping and tracer-study purposes only. Only you and authorized '
            'administrators can see it. Once submitted, it is locked; '
            'corrections go through an administrator-reviewed request.\n\n'
            '• Legal basis: [to be provided by the institution]\n'
            '• Retention period: [to be provided by the institution]\n'
            '• Data Protection Officer / privacy contact: [to be provided by '
            'the institution]',
            style: TextStyle(fontSize: 12),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            value: _ack,
            onChanged: (v) => setState(() => _ack = v ?? false),
            title: const Text(
              'I have read the privacy notice and confirm that the '
              'information above is true and correct.',
              style: TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context, false),
        child: const Text('Cancel'),
      ),
      FilledButton(
        onPressed: _ack ? () => Navigator.pop(context, true) : null,
        child: const Text('Submit & lock'),
      ),
    ],
  );
}
