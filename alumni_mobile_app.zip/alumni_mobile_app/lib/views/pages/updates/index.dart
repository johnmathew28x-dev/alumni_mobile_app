import 'package:flutter/material.dart';
import '../../../models/feed_models.dart';
import '../../../services/api_helpers.dart';
import '../../../services/api_service.dart';
import '../../../services/feed_service.dart';
import '../../widgets/async_body.dart';

class UpdatesPage extends StatelessWidget {
  final ApiService api;
  const UpdatesPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 3,
    child: Column(
      children: [
        const TabBar(
          tabs: [
            Tab(text: 'Announcements'),
            Tab(text: 'Jobs'),
            Tab(text: 'Events'),
          ],
        ),
        Expanded(
          child: TabBarView(
            children: [
              _AnnouncementsTab(api: api),
              _JobsTab(api: api),
              _EventsTab(api: api),
            ],
          ),
        ),
      ],
    ),
  );
}

const EdgeInsets _listPadding = EdgeInsets.all(16);

class _AnnouncementsTab extends StatelessWidget {
  final ApiService api;
  const _AnnouncementsTab({required this.api});

  @override
  Widget build(BuildContext context) => AsyncBody<List<AnnouncementModel>>(
    load: FeedService(api).getAnnouncements,
    isEmpty: (l) => l.isEmpty,
    emptyMessage: 'No announcements yet.',
    builder: (context, items) => ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: _listPadding,
      children: [
        for (final a in items)
          Card(
            child: ExpansionTile(
              leading: const Icon(Icons.campaign_outlined),
              title: Text(a.title),
              subtitle: a.publishedAt == null ? null : Text(a.publishedAt!),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [Text(a.content)],
            ),
          ),
      ],
    ),
  );
}

class _JobsTab extends StatelessWidget {
  final ApiService api;
  const _JobsTab({required this.api});

  @override
  Widget build(BuildContext context) => AsyncBody<List<JobModel>>(
    load: FeedService(api).getJobs,
    isEmpty: (l) => l.isEmpty,
    emptyMessage: 'No open job postings right now.',
    builder: (context, items) => ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: _listPadding,
      children: [
        for (final j in items)
          Card(
            child: ExpansionTile(
              leading: const Icon(Icons.business_center_outlined),
              title: Text(j.title),
              subtitle: Text(
                [
                  if (j.company != null) j.company!,
                  if (j.location != null) j.location!,
                ].join(' • '),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (j.description != null) Text(j.description!),
                if (j.qualifications != null) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'Qualifications',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(j.qualifications!),
                ],
                if (j.instructions != null) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'How to apply',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(j.instructions!),
                ],
                if (j.deadline != null) ...[
                  const SizedBox(height: 12),
                  Text('Deadline: ${j.deadline}'),
                ],
              ],
            ),
          ),
      ],
    ),
  );
}

class _EventsTab extends StatefulWidget {
  final ApiService api;
  const _EventsTab({required this.api});
  @override
  State<_EventsTab> createState() => _EventsTabState();
}

class _EventsTabState extends State<_EventsTab> {
  final _body = GlobalKey<AsyncBodyState<List<EventModel>>>();
  int? _busyId;

  Future<void> _toggle(EventModel event) async {
    setState(() => _busyId = event.id);
    final service = FeedService(widget.api);
    try {
      if (event.isRegistered) {
        await service.cancelEventRegistration(event.id);
      } else {
        await service.registerForEvent(event.id);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            event.isRegistered
                ? 'Your registration has been cancelled.'
                : 'You are now registered for this event.',
          ),
        ),
      );
      await _body.currentState?.reload();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(cleanError(error))));
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  @override
  Widget build(BuildContext context) => AsyncBody<List<EventModel>>(
    key: _body,
    load: FeedService(widget.api).getEvents,
    isEmpty: (l) => l.isEmpty,
    emptyMessage: 'No upcoming events.',
    builder: (context, items) => ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: _listPadding,
      children: [
        for (final e in items)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    e.title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    [
                      if (e.eventDate != null) e.eventDate!,
                      if (e.eventTime != null) e.eventTime!,
                      if (e.location != null) e.location!,
                    ].join(' • '),
                  ),
                  if (e.registrationDeadline != null)
                    Text('Register by ${e.registrationDeadline}'),
                  if (e.description != null) ...[
                    const SizedBox(height: 8),
                    Text(e.description!),
                  ],
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: e.isRegistered
                        ? OutlinedButton(
                            onPressed: _busyId == null ? () => _toggle(e) : null,
                            child: const Text('Cancel registration'),
                          )
                        : FilledButton(
                            onPressed: _busyId == null ? () => _toggle(e) : null,
                            child: const Text('Register'),
                          ),
                  ),
                ],
              ),
            ),
          ),
      ],
    ),
  );
}
