import 'package:flutter/material.dart';
import '../../../models/session_user.dart';
import '../../../services/api_service.dart';
import '../profile/password.dart';

class AccountPage extends StatelessWidget {
  final ApiService api;
  final SessionUser user;
  final Future<void> Function() onSignOut;
  const AccountPage({
    super.key,
    required this.api,
    required this.user,
    required this.onSignOut,
  });

  Future<void> _password(BuildContext context) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => PasswordPage(api: api)),
    );
    if (!context.mounted || saved != true) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password updated successfully.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final picture = user.pictureUrl;
    final showPicture = picture != null && !picture.endsWith('.svg');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: CircleAvatar(
            radius: 44,
            backgroundImage: showPicture ? NetworkImage(picture) : null,
            child: showPicture ? null : const Icon(Icons.person, size: 44),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          user.fullName,
          textAlign: TextAlign.center,
          style: theme.textTheme.titleLarge,
        ),
        Text(
          '${user.role} • ${user.username}',
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        Card(
          child: ListTile(
            leading: const Icon(Icons.key_outlined),
            title: const Text('Change password'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _password(context),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Log out'),
            onTap: onSignOut,
          ),
        ),
      ],
    );
  }
}
