import 'package:flutter/material.dart';
import '../../../models/employment_model.dart';
import '../../../services/api_service.dart';
import '../../../services/employment_service.dart';
import '../../widgets/record_list_page.dart';
import 'form.dart';

class EmploymentsPage extends StatelessWidget {
  final ApiService api;
  const EmploymentsPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    final service = EmploymentService(api);
    return RecordListPage<EmploymentModel>(
      title: 'Employment',
      noun: 'employment record',
      icon: Icons.work_outline,
      load: service.getAll,
      titleOf: (e) =>
          e.jobPosition ?? e.employer ?? e.statusName,
      subtitleOf: (e) {
        final period = e.isCurrent
            ? '${e.dateHired ?? '—'} to present'
            : '${e.dateHired ?? '—'} to ${e.dateEnded ?? '—'}';
        return [
          if (e.employer != null && e.jobPosition != null) e.employer!,
          e.statusName + (e.isCurrent ? ' (current)' : ''),
          period,
        ].join('\n');
      },
      onDelete: (e) => service.delete(e.id),
      formBuilder: (existing) =>
          EmploymentFormPage(api: api, existing: existing),
    );
  }
}
