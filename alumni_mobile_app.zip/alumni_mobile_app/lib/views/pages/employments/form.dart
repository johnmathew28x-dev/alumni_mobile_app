import 'package:flutter/material.dart';
import '../../../models/employment_model.dart';
import '../../../services/api_service.dart';
import '../../../services/employment_service.dart';
import '../../widgets/form_fields.dart';

class EmploymentFormPage extends StatefulWidget {
  final ApiService api;
  final EmploymentModel? existing;
  const EmploymentFormPage({super.key, required this.api, this.existing});
  @override
  State<EmploymentFormPage> createState() => _EmploymentFormPageState();
}

class _EmploymentFormPageState extends State<EmploymentFormPage> {
  late final _employer = TextEditingController(
    text: widget.existing?.employer ?? '',
  );
  late final _position = TextEditingController(
    text: widget.existing?.jobPosition ?? '',
  );
  late final _location = TextEditingController(
    text: widget.existing?.location ?? '',
  );
  late final _hired = TextEditingController(
    text: widget.existing?.dateHired ?? '',
  );
  late final _ended = TextEditingController(
    text: widget.existing?.dateEnded ?? '',
  );
  late int? _statusId = widget.existing?.statusId;
  late int? _tenureId = widget.existing?.tenureId;
  late int? _industryId = widget.existing?.industryId;
  late int? _jobLevelId = widget.existing?.jobLevelId;
  late int? _salaryId = widget.existing?.salaryRangeId;
  late String? _place = widget.existing?.placeOfWork;
  late String? _related = switch (widget.existing?.relatedToDegree) {
    true => 'Yes',
    false => 'No',
    null => null,
  };
  late bool _firstJob = widget.existing?.isFirstJob ?? false;
  late bool _current = widget.existing?.isCurrent ?? false;

  @override
  void dispose() {
    _employer.dispose();
    _position.dispose();
    _location.dispose();
    _hired.dispose();
    _ended.dispose();
    super.dispose();
  }

  Future<void> _save() {
    final input = EmploymentInput(
      statusId: _statusId!,
      employer: _employer.text.trim(),
      jobPosition: _position.text.trim(),
      location: _location.text.trim(),
      placeOfWork: _place ?? '',
      tenureId: _tenureId,
      industryId: _industryId,
      jobLevelId: _jobLevelId,
      salaryRangeId: _salaryId,
      relatedToDegree: _related == null ? null : _related == 'Yes',
      isFirstJob: _firstJob,
      isCurrent: _current,
      dateHired: _hired.text.trim(),
      dateEnded: _ended.text.trim(),
    );
    final service = EmploymentService(widget.api);
    return widget.existing == null
        ? service.add(input)
        : service.update(widget.existing!.id, input);
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.existing == null
        ? 'Add Employment'
        : 'Edit Employment';
    final today = DateTime.now();
    return LookupGate(
      api: widget.api,
      title: title,
      builder: (context, lookups) => FormScaffold(
        title: title,
        onSave: _save,
        fields: [
          LookupDropdown(
            label: 'Employment status',
            mandatory: true,
            items: lookups.employmentStatuses,
            value: _statusId,
            onChanged: (v) => setState(() => _statusId = v),
          ),
          appTextField(controller: _employer, label: 'Employer', maxLength: 150),
          appTextField(
            controller: _position,
            label: 'Job position',
            maxLength: 150,
          ),
          appTextField(
            controller: _location,
            label: 'Employment location',
            maxLength: 150,
          ),
          ChoiceDropdown(
            label: 'Place of work',
            options: const ['Local', 'Abroad'],
            value: _place,
            onChanged: (v) => setState(() => _place = v),
          ),
          LookupDropdown(
            label: 'Tenure / type',
            items: lookups.employmentTypes,
            value: _tenureId,
            onChanged: (v) => setState(() => _tenureId = v),
          ),
          LookupDropdown(
            label: 'Industry',
            items: lookups.industries,
            value: _industryId,
            onChanged: (v) => setState(() => _industryId = v),
          ),
          LookupDropdown(
            label: 'Job level',
            items: lookups.jobLevels,
            value: _jobLevelId,
            onChanged: (v) => setState(() => _jobLevelId = v),
          ),
          LookupDropdown(
            label: 'Salary range',
            items: lookups.salaryRanges,
            value: _salaryId,
            onChanged: (v) => setState(() => _salaryId = v),
          ),
          ChoiceDropdown(
            label: 'Related to your degree?',
            options: const ['Yes', 'No'],
            value: _related,
            onChanged: (v) => setState(() => _related = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('This was my first job'),
            value: _firstJob,
            onChanged: (v) => setState(() => _firstJob = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('I currently work here'),
            value: _current,
            onChanged: (v) => setState(() {
              _current = v;
              if (v) _ended.clear();
            }),
          ),
          const SizedBox(height: 8),
          DateField(
            controller: _hired,
            label: 'Date hired',
            lastDate: today,
          ),
          DateField(
            controller: _ended,
            label: 'Date ended',
            lastDate: today,
            enabled: !_current,
            validator: (v) {
              if (_current || v.isEmpty || _hired.text.isEmpty) return null;
              return v.compareTo(_hired.text) < 0
                  ? 'The end date cannot be earlier than the date hired.'
                  : null;
            },
          ),
        ],
      ),
    );
  }
}
