import 'package:flutter/material.dart';
import '../../../models/exam_model.dart';
import '../../../services/api_service.dart';
import '../../../services/exam_service.dart';
import '../../widgets/form_fields.dart';

class ExamFormPage extends StatefulWidget {
  final ApiService api;
  final ExamModel? existing;
  const ExamFormPage({super.key, required this.api, this.existing});
  @override
  State<ExamFormPage> createState() => _ExamFormPageState();
}

class _ExamFormPageState extends State<ExamFormPage> {
  late final _name = TextEditingController(text: widget.existing?.name ?? '');
  late final _date = TextEditingController(
    text: widget.existing?.dateTaken ?? '',
  );
  late final _rating = TextEditingController(
    text: widget.existing?.rating ?? '',
  );
  late String? _result = widget.existing?.result;

  @override
  void dispose() {
    _name.dispose();
    _date.dispose();
    _rating.dispose();
    super.dispose();
  }

  Future<void> _save() {
    final service = ExamService(widget.api);
    return widget.existing == null
        ? service.add(
            name: _name.text.trim(),
            result: _result!,
            dateTaken: _date.text.trim(),
            rating: _rating.text.trim(),
          )
        : service.update(
            widget.existing!.id,
            name: _name.text.trim(),
            result: _result!,
            dateTaken: _date.text.trim(),
            rating: _rating.text.trim(),
          );
  }

  @override
  Widget build(BuildContext context) => FormScaffold(
    title: widget.existing == null ? 'Add Examination' : 'Edit Examination',
    onSave: _save,
    fields: [
      appTextField(
        controller: _name,
        label: 'Exam name',
        mandatory: true,
        maxLength: 200,
      ),
      DateField(
        controller: _date,
        label: 'Date taken',
        lastDate: DateTime.now(),
      ),
      appTextField(
        controller: _rating,
        label: 'Rating (0-100)',
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        validator: (v) {
          if (v.isEmpty) return null;
          final n = double.tryParse(v);
          return (n == null || n < 0 || n > 100)
              ? 'Rating must be a number from 0 to 100.'
              : null;
        },
      ),
      ChoiceDropdown(
        label: 'Result',
        mandatory: true,
        options: const ['Passed', 'Failed', 'Pending'],
        value: _result,
        onChanged: (v) => setState(() => _result = v),
      ),
    ],
  );
}
