import 'package:flutter/material.dart';
import '../../../models/tracer_models.dart';
import '../../../services/api_service.dart';
import '../../../services/tracer_service.dart';
import '../../widgets/async_body.dart';
import 'answer.dart';

class TracerPage extends StatefulWidget {
  final ApiService api;
  const TracerPage({super.key, required this.api});
  @override
  State<TracerPage> createState() => _TracerPageState();
}

class _TracerPageState extends State<TracerPage> {
  final _body = GlobalKey<AsyncBodyState<List<TracerStudyModel>>>();

  Future<void> _open(TracerStudyModel study) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => TracerAnswerPage(api: widget.api, study: study),
      ),
    );
    if (!mounted || saved != true) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Your responses have been submitted.')),
    );
    await _body.currentState?.reload();
  }

  @override
  Widget build(BuildContext context) => AsyncBody<List<TracerStudyModel>>(
    key: _body,
    load: TracerService(widget.api).getActive,
    isEmpty: (l) => l.isEmpty,
    emptyMessage: 'There are no active tracer surveys right now.',
    builder: (context, studies) => ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        for (final s in studies)
          Card(
            child: ListTile(
              leading: Icon(
                s.answered
                    ? Icons.check_circle_outline
                    : Icons.assignment_outlined,
              ),
              title: Text(s.title),
              isThreeLine: true,
              subtitle: Text(
                [
                  s.isGts
                      ? 'CHED Graduate Tracer Survey - complete it in the web portal.'
                      : (s.description ?? 'Tracer study'),
                  s.answered
                      ? 'Completed'
                      : (s.inProgress ? 'In progress' : 'Not started'),
                ].join('\n'),
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: s.isGts ? null : const Icon(Icons.chevron_right),
              onTap: s.isGts ? null : () => _open(s),
            ),
          ),
      ],
    ),
  );
}
