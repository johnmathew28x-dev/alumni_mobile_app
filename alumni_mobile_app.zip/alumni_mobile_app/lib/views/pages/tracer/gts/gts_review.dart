import 'package:flutter/material.dart';
import '../../../../models/gts_models.dart';
import '../../../../services/api_helpers.dart';
import '../../../../services/gts_service.dart';
import '../../../widgets/async_body.dart';

/// Section 14: everything that was answered, what is still missing, and the
/// Submit button. When [editable] is false it is a read-only summary.
class GtsReviewStep extends StatefulWidget {
  final GtsService service;
  final int studyId;
  final bool editable;
  final String? lockedMessage;
  final VoidCallback onSubmitted;
  const GtsReviewStep({
    super.key,
    required this.service,
    required this.studyId,
    required this.editable,
    required this.onSubmitted,
    this.lockedMessage,
  });

  @override
  State<GtsReviewStep> createState() => _GtsReviewStepState();
}

class _GtsReviewStepState extends State<GtsReviewStep> {
  bool _busy = false;

  Future<void> _submit() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Submit survey?'),
        content: const Text(
          'Once submitted you can no longer edit your answers. Ask the alumni '
          'office if you need a correction afterwards.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Submit'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await widget.service.submit(widget.studyId);
      if (!mounted) return;
      widget.onSubmitted();
    } catch (error) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(cleanError(error))));
    }
  }

  @override
  Widget build(BuildContext context) => AsyncBody<GtsReview>(
    load: () => widget.service.review(widget.studyId),
    builder: (context, review) {
      final theme = Theme.of(context);
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (widget.lockedMessage != null)
            Card(
              color: theme.colorScheme.secondaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(widget.lockedMessage!),
              ),
            ),
          if (widget.editable && review.missing.isNotEmpty)
            Card(
              color: theme.colorScheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Please complete the following before submitting:',
                      style: TextStyle(
                        color: theme.colorScheme.onErrorContainer,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    for (final m in review.missing)
                      Text(
                        '• $m',
                        style: TextStyle(
                          color: theme.colorScheme.onErrorContainer,
                        ),
                      ),
                    Text(
                      'Use Back to return to those sections.',
                      style: TextStyle(
                        color: theme.colorScheme.onErrorContainer,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          for (final section in review.sections)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(section.title, style: theme.textTheme.titleSmall),
                    const Divider(),
                    for (final row in section.rows)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(row.$1, style: theme.textTheme.bodySmall),
                            Text(row.$2.isEmpty ? '—' : row.$2),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          if (widget.editable)
            FilledButton.icon(
              onPressed: _busy || review.missing.isNotEmpty ? null : _submit,
              icon: const Icon(Icons.send),
              label: Text(_busy ? 'Submitting...' : 'Submit survey'),
            ),
        ],
      );
    },
  );
}
