import 'package:flutter/material.dart';
import '../../../../services/api_service.dart';
import '../../../../services/exam_service.dart';
import '../../../../services/training_service.dart';
import '../../../widgets/async_body.dart';
import '../../licensures/index.dart';
import '../../trainings/index.dart';

/// Sections 3 and 5: the alumnus's existing records, with a shortcut to the
/// full add / edit / delete screens used in the Records tab (the web survey
/// saves these records through the same API).
class GtsRecordsStep extends StatefulWidget {
  final ApiService api;
  final bool
  exams; // true: Section 3 (examinations), false: Section 5 (trainings)
  const GtsRecordsStep({super.key, required this.api, required this.exams});

  @override
  State<GtsRecordsStep> createState() => _GtsRecordsStepState();
}

class _GtsRecordsStepState extends State<GtsRecordsStep> {
  final _body = GlobalKey<AsyncBodyState<List<(String, String)>>>();

  Future<List<(String, String)>> _load() async {
    if (widget.exams) {
      final rows = await ExamService(widget.api).getAll();
      return [
        for (final e in rows)
          (
            e.name,
            [
              if (e.dateTaken != null) e.dateTaken!,
              if (e.rating != null) 'rating ${e.rating}',
              e.result,
            ].join(' • '),
          ),
      ];
    }
    final rows = await TrainingService(widget.api).getAll();
    return [
      for (final t in rows)
        (
          t.title,
          [
            t.type,
            if (t.organizer != null) t.organizer!,
            if (t.year != null) '${t.year}',
          ].join(' • '),
        ),
    ];
  }

  Future<void> _manage() async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(
        builder: (_) => widget.exams
            ? LicensuresPage(api: widget.api)
            : TrainingsPage(api: widget.api),
      ),
    );
    if (mounted) await _body.currentState?.reload();
  }

  @override
  Widget build(BuildContext context) => AsyncBody<List<(String, String)>>(
    key: _body,
    load: _load,
    builder: (context, rows) => ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          widget.exams
              ? 'Name of examination, date taken and rating of every '
                    'professional examination you have taken. Leave empty if none.'
              : 'Professional or work-related trainings and advanced studies '
                    'after college. Leave empty if none.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 12),
        if (rows.isEmpty)
          const Card(child: ListTile(title: Text('Nothing added yet.'))),
        for (final r in rows)
          Card(
            child: ListTile(title: Text(r.$1), subtitle: Text(r.$2)),
          ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _manage,
          icon: const Icon(Icons.edit_note),
          label: Text(
            widget.exams
                ? 'Manage in licensures and examinations'
                : 'Add or edit trainings',
          ),
        ),
      ],
    ),
  );
}
