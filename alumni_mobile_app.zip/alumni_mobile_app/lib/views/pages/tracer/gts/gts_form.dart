import 'package:flutter/material.dart';
import '../../../../models/gts_models.dart';
import '../../../../services/gts_service.dart';
import '../../../widgets/form_fields.dart';

enum GtsKind { text, textarea, date, select, yesNo, radio, checks, heading, note }

/// Current answers of one section while it is being edited.
class GtsValues {
  final Map<String, String> text;
  final Map<String, Set<String>> checks;
  GtsValues({Map<String, String>? text, Map<String, Set<String>>? checks})
    : text = {...?text},
      checks = {...?checks};
}

/// One question (or heading / note) of a survey section.
class GtsField {
  final String name; // request field name (ids field for checklists)
  final String label;
  final GtsKind kind;
  final List<GtsChoice> choices;
  final bool required;
  final int? maxLength;
  final String? hint; // select: label of the empty choice
  final String? otherName; // checklist: field holding the "Other" text
  final bool Function(GtsValues values)? visible;
  final String? Function(String value)? validate;
  final String Function(GtsValues values)? dynamicLabel;
  final DateTime? lastDate;
  final TextInputType? keyboard;
  const GtsField(
    this.name,
    this.label,
    this.kind, {
    this.choices = const [],
    this.required = false,
    this.maxLength,
    this.hint,
    this.otherName,
    this.visible,
    this.validate,
    this.dynamicLabel,
    this.lastDate,
    this.keyboard,
  });

  const GtsField.heading(String text, {bool Function(GtsValues)? visible})
    : this('', text, GtsKind.heading, visible: visible);

  const GtsField.note(String text, {bool Function(GtsValues)? visible})
    : this('', text, GtsKind.note, visible: visible);
}

/// Renders a list of [GtsField]s and collects the answers in the format the
/// Gts/saveSection endpoint expects. Call [collect] to validate and read them.
class GtsSectionForm extends StatefulWidget {
  final List<GtsField> fields;
  final GtsValues initial;
  const GtsSectionForm({super.key, required this.fields, required this.initial});

  @override
  State<GtsSectionForm> createState() => GtsSectionFormState();
}

class GtsSectionFormState extends State<GtsSectionForm> {
  final _formKey = GlobalKey<FormState>();
  final _controllers = <String, TextEditingController>{};
  final _choice = <String, String>{};
  final _checks = <String, Set<String>>{};

  @override
  void initState() {
    super.initState();
    for (final f in widget.fields) {
      switch (f.kind) {
        case GtsKind.text:
        case GtsKind.textarea:
        case GtsKind.date:
          _controllers[f.name] = TextEditingController(
            text: widget.initial.text[f.name] ?? '',
          );
        case GtsKind.select:
        case GtsKind.yesNo:
        case GtsKind.radio:
          _choice[f.name] = widget.initial.text[f.name] ?? '';
        case GtsKind.checks:
          _checks[f.name] = {...?widget.initial.checks[f.name]};
          final other = f.otherName;
          if (other != null) {
            _controllers[other] = TextEditingController(
              text: widget.initial.text[other] ?? '',
            );
          }
        case GtsKind.heading:
        case GtsKind.note:
          break;
      }
    }
  }

  @override
  void dispose() {
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  GtsValues _current() => GtsValues(
    text: {
      for (final e in _controllers.entries) e.key: e.value.text,
      ..._choice,
    },
    checks: _checks,
  );

  bool _shown(GtsField f, GtsValues v) => f.visible?.call(v) ?? true;

  bool _otherPicked(GtsField f) => f.choices.any(
    (c) => c.isOther && (_checks[f.name]?.contains(c.value) ?? false),
  );

  /// Validates the visible fields. Returns the request fields, or null when
  /// something is invalid (the errors are shown on the form).
  Map<String, String>? collect() {
    if (!(_formKey.currentState?.validate() ?? false)) return null;
    final v = _current();
    final out = <String, String>{};
    for (final f in widget.fields) {
      if (!_shown(f, v)) continue;
      switch (f.kind) {
        case GtsKind.text:
        case GtsKind.textarea:
        case GtsKind.date:
          out[f.name] = _controllers[f.name]!.text.trim();
        case GtsKind.select:
        case GtsKind.yesNo:
        case GtsKind.radio:
          out[f.name] = _choice[f.name] ?? '';
        case GtsKind.checks:
          final picked = f.choices
              .where((c) => _checks[f.name]!.contains(c.value))
              .map((c) => c.value);
          out.addAll(GtsService.indexed(f.name, picked));
          final other = f.otherName;
          if (other != null) {
            out[other] = _otherPicked(f) ? _controllers[other]!.text.trim() : '';
          }
        case GtsKind.heading:
        case GtsKind.note:
          break;
      }
    }
    return out;
  }

  String _star(String label, bool required) => required ? '$label *' : label;

  Widget _gap(Widget child) =>
      Padding(padding: const EdgeInsets.only(bottom: 16), child: child);

  Widget _build(GtsField f, GtsValues v) {
    final theme = Theme.of(context);
    final label = f.dynamicLabel?.call(v) ?? f.label;
    switch (f.kind) {
      case GtsKind.heading:
        return Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 12),
          child: Text(
            f.label,
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.primary,
            ),
          ),
        );
      case GtsKind.note:
        return _gap(Text(f.label, style: theme.textTheme.bodySmall));
      case GtsKind.text:
      case GtsKind.textarea:
        return _gap(
          TextFormField(
            controller: _controllers[f.name],
            maxLength: f.maxLength,
            maxLines: f.kind == GtsKind.textarea ? 6 : 1,
            keyboardType: f.keyboard,
            decoration: InputDecoration(
              labelText: _star(label, f.required),
              hintText: f.hint,
            ),
            validator: (raw) {
              final value = (raw ?? '').trim();
              if (f.required && value.isEmpty) return 'Enter $label.';
              return f.validate?.call(value);
            },
          ),
        );
      case GtsKind.date:
        return _gap(
          DateField(
            controller: _controllers[f.name]!,
            label: label,
            mandatory: f.required,
            lastDate: f.lastDate ?? DateTime.now(),
            validator: f.validate,
          ),
        );
      case GtsKind.select:
        final value = _choice[f.name] ?? '';
        return _gap(
          DropdownButtonFormField<String>(
            initialValue: f.choices.any((c) => c.value == value) ? value : '',
            isExpanded: true,
            decoration: InputDecoration(labelText: _star(label, f.required)),
            items: [
              DropdownMenuItem(value: '', child: Text(f.hint ?? 'Select')),
              for (final c in f.choices)
                DropdownMenuItem(
                  value: c.value,
                  child: Text(c.label, overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (picked) =>
                setState(() => _choice[f.name] = picked ?? ''),
            validator: (picked) => f.required && (picked ?? '').isEmpty
                ? 'Select $label.'
                : null,
          ),
        );
      case GtsKind.yesNo:
      case GtsKind.radio:
        final options = f.kind == GtsKind.yesNo
            ? const [GtsChoice('1', 'Yes'), GtsChoice('0', 'No')]
            : f.choices;
        return _gap(
          FormField<String>(
            initialValue: _choice[f.name] ?? '',
            validator: (picked) => f.required && (picked ?? '').isEmpty
                ? 'Please answer: $label'
                : null,
            builder: (state) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_star(label, f.required), style: theme.textTheme.bodyLarge),
                for (final c in options)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      state.value == c.value
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      color: state.value == c.value
                          ? theme.colorScheme.primary
                          : null,
                    ),
                    title: Text(c.label),
                    selected: state.value == c.value,
                    onTap: () {
                      state.didChange(c.value);
                      setState(() => _choice[f.name] = c.value);
                    },
                  ),
                if (state.hasError)
                  Text(
                    state.errorText!,
                    style: TextStyle(
                      color: theme.colorScheme.error,
                      fontSize: 12,
                    ),
                  ),
              ],
            ),
          ),
        );
      case GtsKind.checks:
        final other = f.otherName;
        return _gap(
          FormField<Set<String>>(
            initialValue: _checks[f.name],
            validator: (picked) => f.required && (picked ?? {}).isEmpty
                ? 'Select at least one.'
                : null,
            builder: (state) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_star(label, f.required), style: theme.textTheme.bodyLarge),
                for (final c in f.choices)
                  CheckboxListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: Text(c.label),
                    value: _checks[f.name]!.contains(c.value),
                    onChanged: (on) {
                      setState(() {
                        if (on ?? false) {
                          _checks[f.name]!.add(c.value);
                        } else {
                          _checks[f.name]!.remove(c.value);
                        }
                      });
                      state.didChange({..._checks[f.name]!});
                    },
                  ),
                if (state.hasError)
                  Text(
                    state.errorText!,
                    style: TextStyle(
                      color: theme.colorScheme.error,
                      fontSize: 12,
                    ),
                  ),
                if (other != null && _otherPicked(f))
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: TextFormField(
                      controller: _controllers[other],
                      maxLength: 150,
                      decoration: const InputDecoration(
                        labelText: 'Please specify *',
                      ),
                      validator: (raw) => (raw ?? '').trim().isEmpty
                          ? 'Please specify "Other".'
                          : null,
                    ),
                  ),
              ],
            ),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final v = _current();
    // A plain scroll view (not a lazy ListView) so every field is mounted and
    // validated, including the ones below the visible area.
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final f in widget.fields)
              if (_shown(f, v)) _build(f, v),
          ],
        ),
      ),
    );
  }
}
