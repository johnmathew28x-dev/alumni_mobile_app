import 'package:flutter/material.dart';
import '../../../../models/gts_models.dart';
import '../../../../services/api_helpers.dart';
import 'gts_form.dart';

String _t(Object? v) => asText(v) ?? '';
String _id(Object? v) => asInt(v)?.toString() ?? '';
String _yn(Object? v) => v == null || '$v'.isEmpty ? '' : (asBool(v) ? '1' : '0');
String _flag(bool? v) => v == null ? '' : (v ? '1' : '0');

final _phone = RegExp(r'^[0-9+\-\s()]{7,20}$');

/// Latest allowed birthday (the server requires the alumnus to be 16+).
DateTime _latestBirthday() {
  final now = DateTime.now();
  return DateTime(now.year - 16, now.month, now.day).subtract(const Duration(days: 1));
}

/// Sections that are filled in with the generic form (not 3, 5 or 14).
bool gtsIsFormSection(int n) => n != 3 && n != 5 && n != 14;

/// The questions of section [n]. Same questions, required rules and
/// conditions as the web survey (views/Tracer/gts.php, Gts.php).
List<GtsField> gtsFields(int n, GtsData d, GtsOptions o) {
  final s = d.survey;
  List<GtsChoice> opt(String key) => o.of(key);

  switch (n) {
    case 1:
      return [
        const GtsField('first_name', 'First name', GtsKind.text, required: true, maxLength: 100),
        const GtsField('middle_name', 'Middle name', GtsKind.text, maxLength: 100),
        const GtsField('last_name', 'Last name', GtsKind.text, required: true, maxLength: 100),
        const GtsField('suffix', 'Suffix', GtsKind.text, maxLength: 10),
        const GtsField('gender', 'Sex', GtsKind.select, required: true, choices: [
          GtsChoice('Male', 'Male'),
          GtsChoice('Female', 'Female'),
          GtsChoice('Other', 'Other'),
        ]),
        GtsField('date_of_birth', 'Birthday', GtsKind.date, required: true, lastDate: _latestBirthday()),
        GtsField('civil_status_id', 'Civil status', GtsKind.select, required: true, choices: opt('civil_statuses')),
        GtsField('region_id', 'Region of origin', GtsKind.select, required: true, choices: opt('regions')),
        const GtsField('address', 'Permanent address', GtsKind.text, maxLength: 255),
        const GtsField('province', 'Province', GtsKind.text, required: true, maxLength: 100),
        const GtsField('city_municipality', 'City / municipality of residence', GtsKind.text, maxLength: 100),
        GtsField('residence_type_id', 'Residence type', GtsKind.select, choices: opt('residence_types')),
        GtsField(
          'contact_number',
          'Mobile number',
          GtsKind.text,
          maxLength: 20,
          keyboard: TextInputType.phone,
          validate: (v) => v.isEmpty || _phone.hasMatch(v)
              ? null
              : 'Use digits, spaces, + - ( ) (7-20 characters).',
        ),
        GtsField.note('Email: ${_t(d.general['email']).isEmpty ? '—' : _t(d.general['email'])} (changed by the alumni office only).'),
      ];

    case 2:
      return [
        GtsField.note(
          'College / University: Northeastern College\n'
          'Program: ${_t(d.education['program_name']).isEmpty ? '—' : _t(d.education['program_name'])}\n'
          'Year graduated: ${_t(d.education['graduation_year']).isEmpty ? '—' : _t(d.education['graduation_year'])}\n'
          'These come from your school record. Tell the alumni office if something is wrong.',
        ),
        const GtsField('degree', 'Degree', GtsKind.text, required: true, maxLength: 150),
        const GtsField('specialization', 'Specialization', GtsKind.text, maxLength: 150),
        GtsField(
          'academic_year',
          'Academic year graduated',
          GtsKind.text,
          maxLength: 9,
          hint: '2022-2023',
          validate: (v) {
            if (v.isEmpty) return null;
            final m = RegExp(r'^(\d{4})-(\d{4})$').firstMatch(v);
            if (m == null || int.parse(m[2]!) != int.parse(m[1]!) + 1) {
              return 'Academic year must look like 2022-2023.';
            }
            return null;
          },
        ),
        const GtsField('honors_awards', 'Honors / awards received', GtsKind.text, maxLength: 255),
      ];

    case 4:
      return [
        const GtsField.note('Select all that apply.'),
        GtsField(
          'course_reason_ids',
          'Reasons for taking the course',
          GtsKind.checks,
          required: true,
          choices: opt('course_reasons'),
          otherName: 'course_reason_other',
        ),
      ];

    case 6:
      return [
        const GtsField(
          'employment_state',
          'Are you presently employed?',
          GtsKind.radio,
          required: true,
          choices: [
            GtsChoice('employed', 'Yes, I am currently employed'),
            GtsChoice('not_employed', 'No, I am not currently employed'),
            GtsChoice('never_employed', 'I have never been employed'),
          ],
        ),
        GtsField(
          'unemployment_reason_ids',
          'Reason(s) why you are not employed (select all that apply)',
          GtsKind.checks,
          required: true,
          choices: opt('unemployment_reasons'),
          otherName: 'unemployment_reason_other',
          visible: (v) {
            final state = v.text['employment_state'] ?? '';
            return state == 'not_employed' || state == 'never_employed';
          },
        ),
      ];

    case 7:
      return [
        GtsField('employment_type_id', 'Employment status', GtsKind.select, required: true, choices: opt('employment_types')),
        const GtsField('job_position', 'Present occupation', GtsKind.text, required: true, maxLength: 150, hint: 'e.g. Teacher, Software Developer'),
        GtsField(
          'employer',
          'Employer / company',
          GtsKind.text,
          maxLength: 150,
          dynamicLabel: (v) {
            final picked = opt('employment_types').where((c) => c.value == v.text['employment_type_id']);
            return picked.isNotEmpty && picked.first.label == 'Self-employed'
                ? 'Business / enterprise name'
                : 'Employer / company';
          },
        ),
        GtsField('industry_id', 'Major line of business / industry', GtsKind.select, required: true, choices: opt('industries')),
        const GtsField('place_of_work', 'Place of work', GtsKind.select, required: true, choices: [
          GtsChoice('Local', 'Local'),
          GtsChoice('Abroad', 'Abroad'),
        ]),
        const GtsField('employment_location', 'Work location (city / country)', GtsKind.text, maxLength: 150),
        const GtsField('related_to_degree', 'Is your work related to your degree?', GtsKind.yesNo, required: true),
        const GtsField('current_is_first_job', 'Is this your first job?', GtsKind.yesNo, required: true),
        GtsField('date_hired', 'Date hired (optional)', GtsKind.date, lastDate: DateTime.now()),
      ];

    case 8:
      return [
        if (s.merged)
          const GtsField.note('Your current job is your first job, so its details were already collected in Section 7.')
        else ...[
          const GtsField('first_job_position', 'First job position', GtsKind.text, required: true, maxLength: 150),
          const GtsField('first_employer', 'Employer / company (optional)', GtsKind.text, maxLength: 150),
          const GtsField('first_job_location', 'First job location', GtsKind.text, maxLength: 150),
          GtsField('first_industry_id', 'First job industry', GtsKind.select, required: true, choices: opt('industries')),
          const GtsField('first_related_to_degree', 'Was your first job related to your degree?', GtsKind.yesNo, required: true),
        ],
        GtsField('duration_id', 'How long did you stay in your first job?', GtsKind.select, required: true, choices: opt('duration_ranges')),
        GtsField(
          'accept_reason_ids',
          'Reason(s) for accepting your first job (select all that apply)',
          GtsKind.checks,
          required: true,
          choices: opt('accept_reasons'),
          otherName: 'accept_reason_other',
        ),
      ];

    case 9:
      return [
        GtsField('search_method_id', 'How did you find your first job?', GtsKind.select, required: true, choices: opt('job_search_methods')),
        GtsField('time_to_job_id', 'How long did it take to land your first job?', GtsKind.select, required: true, choices: opt('duration_ranges')),
        if (s.isEmployed && !s.merged)
          GtsField(
            'change_reason_ids',
            'Reason(s) for changing jobs (select all that apply)',
            GtsKind.checks,
            required: true,
            choices: opt('change_reasons'),
            otherName: 'change_reason_other',
          ),
      ];

    case 10:
      return [
        GtsField.heading(s.merged ? 'Your first (and present) job' : 'First job'),
        GtsField('first_job_level_id', 'Job level', GtsKind.select, required: true, choices: opt('job_levels')),
        GtsField('first_salary_range_id', 'Initial gross monthly earnings', GtsKind.select, hint: 'Prefer not to say', choices: opt('salary_ranges')),
        if (s.isEmployed && !s.merged) ...[
          const GtsField.heading('Present job'),
          GtsField('current_job_level_id', 'Job level', GtsKind.select, required: true, choices: opt('job_levels')),
          GtsField('current_salary_range_id', 'Gross monthly earnings', GtsKind.select, hint: 'Prefer not to say', choices: opt('salary_ranges')),
        ],
        const GtsField.note('You do not have to give your exact salary, only the bracket, and you may choose "Prefer not to say".'),
      ];

    case 11:
      return [
        const GtsField(
          'curriculum_relevant',
          'Was the curriculum you had in college relevant to your first job?',
          GtsKind.yesNo,
          required: true,
        ),
      ];

    case 12:
      return [
        const GtsField.note('Which competencies learned in college were useful in your first job? Select all that apply.'),
        GtsField(
          'competency_ids',
          'Competencies',
          GtsKind.checks,
          required: true,
          choices: opt('competencies'),
          otherName: 'competency_other',
        ),
      ];

    case 13:
      return [
        const GtsField(
          'curriculum_feedback',
          'Suggestions to further improve the course curriculum',
          GtsKind.textarea,
          maxLength: 2000,
        ),
      ];
  }
  return const [];
}

/// The saved answers of section [n], to prefill its form.
GtsValues gtsInitial(int n, GtsData d) {
  final g = d.general;
  final e = d.education;
  final cur = d.current;
  final first = d.first;
  final s = d.survey;

  switch (n) {
    case 1:
      return GtsValues(text: {
        for (final k in [
          'first_name', 'middle_name', 'last_name', 'suffix', 'gender',
          'date_of_birth', 'address', 'province', 'city_municipality', 'contact_number',
        ])
          k: _t(g[k]),
        for (final k in ['civil_status_id', 'region_id', 'residence_type_id']) k: _id(g[k]),
      });
    case 2:
      return GtsValues(text: {
        for (final k in ['degree', 'specialization', 'academic_year', 'honors_awards']) k: _t(e[k]),
      });
    case 4:
      return GtsValues(
        text: {'course_reason_other': d.course.other},
        checks: {'course_reason_ids': d.course.ids.toSet()},
      );
    case 6:
      return GtsValues(
        text: {
          'employment_state': s.employmentState ?? '',
          'unemployment_reason_other': d.unemployment.other,
        },
        checks: {'unemployment_reason_ids': d.unemployment.ids.toSet()},
      );
    case 7:
      return GtsValues(text: {
        'employment_type_id': _id(cur['employment_type_id']),
        'job_position': _t(cur['job_position']),
        'employer': _t(cur['employer']),
        'industry_id': _id(cur['industry_id']),
        'place_of_work': _t(cur['place_of_work']),
        'employment_location': _t(cur['employment_location']),
        'related_to_degree': _yn(cur['related_to_degree']),
        'current_is_first_job': _flag(s.currentIsFirstJob),
        'date_hired': _t(cur['date_hired']),
      });
    case 8:
      return GtsValues(
        text: {
          'first_job_position': _t(first['job_position']),
          'first_employer': _t(first['employer']),
          'first_job_location': _t(first['employment_location']),
          'first_industry_id': _id(first['industry_id']),
          'first_related_to_degree': _yn(first['related_to_degree']),
          'duration_id': _id(first['duration_id']),
          'accept_reason_other': d.accept.other,
        },
        checks: {'accept_reason_ids': d.accept.ids.toSet()},
      );
    case 9:
      return GtsValues(
        text: {
          'search_method_id': _id(first['search_method_id']),
          'time_to_job_id': _id(first['time_to_job_id']),
          'change_reason_other': d.change.other,
        },
        checks: {'change_reason_ids': d.change.ids.toSet()},
      );
    case 10:
      return GtsValues(text: {
        'first_job_level_id': _id(first['job_level_id']),
        'first_salary_range_id': _id(first['salary_range_id']),
        'current_job_level_id': _id(cur['job_level_id']),
        'current_salary_range_id': _id(cur['salary_range_id']),
      });
    case 11:
      return GtsValues(text: {'curriculum_relevant': _flag(s.curriculumRelevant)});
    case 12:
      return GtsValues(
        text: {'competency_other': d.competencies.other},
        checks: {'competency_ids': d.competencies.ids.toSet()},
      );
    case 13:
      return GtsValues(text: {'curriculum_feedback': d.feedback});
  }
  return GtsValues();
}
