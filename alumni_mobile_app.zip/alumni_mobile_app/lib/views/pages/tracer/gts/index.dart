import 'package:flutter/material.dart';
import '../../../../models/gts_models.dart';
import '../../../../models/tracer_models.dart';
import '../../../../services/api_helpers.dart';
import '../../../../services/api_service.dart';
import '../../../../services/gts_service.dart';
import 'gts_form.dart';
import 'gts_records_step.dart';
import 'gts_review.dart';
import 'gts_sections.dart';

/// The CHED Graduate Tracer Survey: 13 sections saved one at a time, then a
/// review. Same flow and rules as the web survey; progress is kept on the
/// server so the alumnus can leave and come back. Pops `true` once submitted.
class GtsPage extends StatefulWidget {
  final ApiService api;
  final TracerStudyModel study;
  const GtsPage({super.key, required this.api, required this.study});

  @override
  State<GtsPage> createState() => _GtsPageState();
}

class _GtsPageState extends State<GtsPage> {
  late final GtsService _service = GtsService(widget.api);
  final _formKey = GlobalKey<GtsSectionFormState>();

  GtsStart? _start;
  String? _error;
  bool _loading = true;
  bool _saving = false;
  int _section = 1;
  int _version = 0; // changes whenever fresh data is loaded, to rebuild forms

  @override
  void initState() {
    super.initState();
    _load();
  }

  int? _next(GtsSurvey s, int from) {
    for (var i = from + 1; i <= 14; i++) {
      if (s.isVisible(i)) return i;
    }
    return null;
  }

  int? _prev(GtsSurvey s, int from) {
    for (var i = from - 1; i >= 1; i--) {
      if (s.isVisible(i)) return i;
    }
    return null;
  }

  int _initialSection(GtsStart start) {
    if (!start.editable) return 14;
    final survey = start.data.survey;
    final target = survey.lastSection.clamp(1, 14);
    return survey.isVisible(target) ? target : (_next(survey, target) ?? 14);
  }

  Future<void> _load({int? section}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final start = await _service.start(widget.study.id);
      if (!mounted) return;
      setState(() {
        _start = start;
        _version++;
        _section = section ?? _initialSection(start);
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = cleanError(error));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _snack(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  Future<void> _saveAndContinue() async {
    final n = _section;
    final Map<String, String> form;
    if (gtsIsFormSection(n)) {
      final collected = _formKey.currentState?.collect();
      if (collected == null) return; // invalid: errors are shown on the form
      form = collected;
    } else {
      form = const {}; // sections 3 and 5 are saved through their own screens
    }
    setState(() => _saving = true);
    try {
      final survey = await _service.saveSection(widget.study.id, n, form);
      if (!mounted) return;
      _snack('Section $n saved.');
      await _load(section: _next(survey, n) ?? 14);
    } catch (error) {
      if (!mounted) return;
      _snack(cleanError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _back() {
    final survey = _start?.data.survey;
    if (survey == null) return;
    final previous = _prev(survey, _section);
    if (previous != null) setState(() => _section = previous);
  }

  Widget _body(GtsStart start) {
    final n = _section;
    final key = ValueKey('$n-$_version');
    if (n == 14 || !start.editable) {
      return GtsReviewStep(
        key: key,
        service: _service,
        studyId: widget.study.id,
        editable: start.editable,
        lockedMessage: start.editable
            ? null
            : 'This survey can no longer be edited (already submitted or the '
                  'survey period is closed). Here are your saved answers.',
        onSubmitted: () => Navigator.pop(context, true),
      );
    }
    if (n == 3 || n == 5) {
      return GtsRecordsStep(key: key, api: widget.api, exams: n == 3);
    }
    return KeyedSubtree(
      key: key,
      child: GtsSectionForm(
        key: _formKey,
        fields: gtsFields(n, start.data, start.options),
        initial: gtsInitial(n, start.data),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final start = _start;
    return Scaffold(
      appBar: AppBar(title: const Text('Graduate Tracer Survey')),
      body: start == null
          ? Center(
              child: _loading
                  ? const CircularProgressIndicator()
                  : Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _error ?? 'Unable to load the survey.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          TextButton(
                            onPressed: _load,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    ),
            )
          : _content(start),
    );
  }

  Widget _content(GtsStart start) {
    final survey = start.data.survey;
    final visible = survey.visibleSections;
    final position = visible.indexOf(_section) + 1;
    final title = start.sections[_section] ?? 'Section $_section';
    final editing = start.editable && _section != 14;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                start.editable
                    ? 'Step $position of ${visible.length}'
                    : 'Your answers',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              Text(
                _section == 14 ? '14. $title' : '$_section. $title',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              if (start.editable)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: LinearProgressIndicator(
                    value: visible.isEmpty ? 0 : position / visible.length,
                  ),
                ),
            ],
          ),
        ),
        if (_loading) const LinearProgressIndicator(),
        Expanded(child: _body(start)),
        if (start.editable)
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: OverflowBar(
                alignment: MainAxisAlignment.spaceBetween,
                spacing: 8,
                overflowAlignment: OverflowBarAlignment.end,
                overflowSpacing: 8,
                children: [
                  OutlinedButton(
                    onPressed: _saving || _prev(survey, _section) == null
                        ? null
                        : _back,
                    child: const Text('Back'),
                  ),
                  if (editing)
                    FilledButton(
                      onPressed: _saving ? null : _saveAndContinue,
                      child: Text(_saving ? 'Saving...' : 'Save & Continue'),
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
