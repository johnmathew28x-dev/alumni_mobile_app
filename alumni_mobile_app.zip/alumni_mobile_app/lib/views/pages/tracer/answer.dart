import 'package:flutter/material.dart';
import '../../../models/tracer_models.dart';
import '../../../services/api_helpers.dart';
import '../../../services/api_service.dart';
import '../../../services/tracer_service.dart';

class TracerAnswerPage extends StatefulWidget {
  final ApiService api;
  final TracerStudyModel study;
  const TracerAnswerPage({super.key, required this.api, required this.study});
  @override
  State<TracerAnswerPage> createState() => _TracerAnswerPageState();
}

class _TracerAnswerPageState extends State<TracerAnswerPage> {
  TracerQuestionnaire? _questionnaire;
  final Map<int, String> _answers = {};
  final Map<int, TextEditingController> _controllers = {};
  bool _loading = true;
  bool _submitting = false;
  String? _error;
  String? _submitError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final q = await TracerService(
        widget.api,
      ).getQuestionnaire(widget.study.id);
      if (!mounted) return;
      for (final c in _controllers.values) {
        c.dispose();
      }
      _controllers.clear();
      _answers
        ..clear()
        ..addAll(q.answers);
      for (final question in q.questions) {
        if (question.type == 'text') {
          _controllers[question.id] = TextEditingController(
            text: _answers[question.id] ?? '',
          );
        }
      }
      setState(() => _questionnaire = q);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = cleanError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _submit() async {
    final q = _questionnaire!;
    for (final question in q.questions) {
      final value = question.type == 'text'
          ? (_controllers[question.id]?.text ?? '').trim()
          : (_answers[question.id] ?? '').trim();
      if (question.isRequired && value.isEmpty) {
        setState(
          () => _submitError = 'Please answer all required questions (*).',
        );
        return;
      }
    }
    setState(() {
      _submitting = true;
      _submitError = null;
    });
    final answers = <int, String>{
      for (final question in q.questions)
        question.id: question.type == 'text'
            ? (_controllers[question.id]?.text ?? '').trim()
            : (_answers[question.id] ?? '').trim(),
    };
    try {
      await TracerService(widget.api).submit(widget.study.id, answers);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _submitError = cleanError(e);
      });
    }
  }

  Widget _input(TracerQuestion q) {
    switch (q.type) {
      case 'text':
        return TextField(
          controller: _controllers[q.id],
          maxLines: 3,
          enabled: !_submitting,
        );
      case 'select':
        return DropdownButtonFormField<String>(
          initialValue: q.options.contains(_answers[q.id])
              ? _answers[q.id]
              : null,
          isExpanded: true,
          decoration: const InputDecoration(hintText: 'Select an option'),
          items: [
            for (final o in q.options)
              DropdownMenuItem(value: o, child: Text(o)),
          ],
          onChanged: _submitting
              ? null
              : (v) => setState(() => _answers[q.id] = v ?? ''),
        );
      default: // yes_no, multiple_choice
        return Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            for (final option in q.choices)
              ChoiceChip(
                label: Text(option),
                selected: _answers[q.id] == option,
                onSelected: _submitting
                    ? null
                    : (_) => setState(() => _answers[q.id] = option),
              ),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _questionnaire;
    return PopScope(
      canPop: !_submitting,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.study.title)),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      TextButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ),
                ),
              )
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (q!.description != null) ...[
                    Text(q.description!),
                    const SizedBox(height: 16),
                  ],
                  if (q.questions.isEmpty)
                    const Text('This study has no questions yet.'),
                  for (final question in q.questions)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            question.isRequired
                                ? '${question.question} *'
                                : question.question,
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          const SizedBox(height: 8),
                          _input(question),
                        ],
                      ),
                    ),
                  if (_submitError != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Text(
                        _submitError!,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ),
                  if (q.questions.isNotEmpty)
                    FilledButton(
                      onPressed: _submitting ? null : _submit,
                      child: Text(
                        _submitting ? 'Submitting...' : 'Submit responses',
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
