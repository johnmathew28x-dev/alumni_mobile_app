import 'package:flutter/material.dart';
import '../../../models/academic_model.dart';
import '../../../services/academic_service.dart';
import '../../../services/api_service.dart';
import '../../widgets/form_fields.dart';

class AcademicFormPage extends StatefulWidget {
  final ApiService api;
  final AcademicModel? existing;
  const AcademicFormPage({super.key, required this.api, this.existing});
  @override
  State<AcademicFormPage> createState() => _AcademicFormPageState();
}

class _AcademicFormPageState extends State<AcademicFormPage> {
  late final _year = TextEditingController(
    text: widget.existing?.graduationYear.toString() ?? '',
  );
  late final _major = TextEditingController(text: widget.existing?.major ?? '');
  late final _batch = TextEditingController(text: widget.existing?.batch ?? '');
  late final _studentId = TextEditingController(
    text: widget.existing?.studentId ?? '',
  );
  late int? _programId = widget.existing?.programId;

  @override
  void dispose() {
    _year.dispose();
    _major.dispose();
    _batch.dispose();
    _studentId.dispose();
    super.dispose();
  }

  Future<void> _save() {
    final service = AcademicService(widget.api);
    final year = int.parse(_year.text.trim());
    if (widget.existing == null) {
      return service.add(
        programId: _programId!,
        graduationYear: year,
        major: _major.text.trim(),
        batch: _batch.text.trim(),
        studentId: _studentId.text.trim(),
      );
    }
    return service.update(
      widget.existing!.id,
      programId: _programId!,
      graduationYear: year,
      major: _major.text.trim(),
      batch: _batch.text.trim(),
      studentId: _studentId.text.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.existing == null
        ? 'Add Program Record'
        : 'Edit Program Record';
    return LookupGate(
      api: widget.api,
      title: title,
      builder: (context, lookups) => FormScaffold(
        title: title,
        onSave: _save,
        fields: [
          LookupDropdown(
            label: 'Program',
            mandatory: true,
            items: lookups.programs,
            value: _programId,
            onChanged: (v) => setState(() => _programId = v),
          ),
          appTextField(
            controller: _year,
            label: 'Graduation year',
            mandatory: true,
            maxLength: 4,
            keyboardType: TextInputType.number,
            validator: (v) =>
                validateYear(v, max: DateTime.now().year + 6, mandatory: true),
          ),
          appTextField(controller: _major, label: 'Major', maxLength: 100),
          appTextField(controller: _batch, label: 'Batch', maxLength: 50),
          appTextField(
            controller: _studentId,
            label: 'Student ID',
            maxLength: 50,
          ),
        ],
      ),
    );
  }
}
