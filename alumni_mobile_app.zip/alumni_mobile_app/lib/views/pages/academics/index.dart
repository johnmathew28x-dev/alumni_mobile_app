import 'package:flutter/material.dart';
import '../../../models/academic_model.dart';
import '../../../services/academic_service.dart';
import '../../../services/api_service.dart';
import '../../widgets/record_list_page.dart';
import 'form.dart';

class AcademicsPage extends StatelessWidget {
  final ApiService api;
  const AcademicsPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    final service = AcademicService(api);
    return RecordListPage<AcademicModel>(
      title: 'Educational Background',
      noun: 'program record',
      icon: Icons.school_outlined,
      load: service.getAll,
      titleOf: (a) => a.programName,
      subtitleOf: (a) => [
        'Graduated ${a.graduationYear}',
        if (a.major != null) 'Major: ${a.major}',
        if (a.batch != null) 'Batch: ${a.batch}',
      ].join(' • '),
      onDelete: (a) => service.delete(a.id),
      formBuilder: (existing) => AcademicFormPage(api: api, existing: existing),
    );
  }
}
