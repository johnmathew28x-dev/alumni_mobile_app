import 'package:flutter/material.dart';
import '../../../models/training_model.dart';
import '../../../services/api_service.dart';
import '../../../services/training_service.dart';
import '../../widgets/record_list_page.dart';
import 'form.dart';

class TrainingsPage extends StatelessWidget {
  final ApiService api;
  const TrainingsPage({super.key, required this.api});

  @override
  Widget build(BuildContext context) {
    final service = TrainingService(api);
    return RecordListPage<TrainingModel>(
      title: 'Trainings & Advanced Studies',
      noun: 'training record',
      icon: Icons.workspace_premium_outlined,
      load: service.getAll,
      titleOf: (t) => t.title,
      subtitleOf: (t) => [
        t.type,
        if (t.organizer != null) t.organizer!,
        if (t.year != null) '${t.year}',
      ].join(' • '),
      onDelete: (t) => service.delete(t.id),
      formBuilder: (existing) => TrainingFormPage(api: api, existing: existing),
    );
  }
}
