import 'package:flutter/material.dart';
import '../../../models/training_model.dart';
import '../../../services/api_service.dart';
import '../../../services/training_service.dart';
import '../../widgets/form_fields.dart';

class TrainingFormPage extends StatefulWidget {
  final ApiService api;
  final TrainingModel? existing;
  const TrainingFormPage({super.key, required this.api, this.existing});
  @override
  State<TrainingFormPage> createState() => _TrainingFormPageState();
}

class _TrainingFormPageState extends State<TrainingFormPage> {
  late final _title = TextEditingController(
    text: widget.existing?.title ?? '',
  );
  late final _organizer = TextEditingController(
    text: widget.existing?.organizer ?? '',
  );
  late final _start = TextEditingController(
    text: widget.existing?.dateStart ?? '',
  );
  late final _end = TextEditingController(
    text: widget.existing?.dateEnd ?? '',
  );
  late final _duration = TextEditingController(
    text: widget.existing?.duration ?? '',
  );
  late final _credits = TextEditingController(
    text: widget.existing?.credits ?? '',
  );
  late final _college = TextEditingController(
    text: widget.existing?.college ?? '',
  );
  late final _year = TextEditingController(
    text: widget.existing?.year?.toString() ?? '',
  );
  late final _purposeOther = TextEditingController(
    text: widget.existing?.purposeOther ?? '',
  );
  late String? _type = widget.existing?.type;
  late String? _purpose = widget.existing?.purpose;

  @override
  void dispose() {
    for (final c in [
      _title,
      _organizer,
      _start,
      _end,
      _duration,
      _credits,
      _college,
      _year,
      _purposeOther,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() {
    final input = TrainingInput(
      title: _title.text.trim(),
      type: _type!,
      organizer: _organizer.text.trim(),
      dateStart: _start.text.trim(),
      dateEnd: _end.text.trim(),
      duration: _duration.text.trim(),
      credits: _credits.text.trim(),
      college: _college.text.trim(),
      year: _year.text.trim(),
      purpose: _purpose ?? '',
      purposeOther: _purposeOther.text.trim(),
    );
    final service = TrainingService(widget.api);
    return widget.existing == null
        ? service.add(input)
        : service.update(widget.existing!.id, input);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return FormScaffold(
      title: widget.existing == null ? 'Add Training' : 'Edit Training',
      onSave: _save,
      fields: [
        appTextField(
          controller: _title,
          label: 'Training title',
          mandatory: true,
          maxLength: 200,
        ),
        ChoiceDropdown(
          label: 'Type',
          mandatory: true,
          options: const ['Training', 'Advanced Study'],
          value: _type,
          onChanged: (v) => setState(() => _type = v),
        ),
        appTextField(controller: _organizer, label: 'Organizer', maxLength: 150),
        appTextField(
          controller: _college,
          label: 'College / university',
          maxLength: 150,
        ),
        DateField(
          controller: _start,
          label: 'Start date',
          lastDate: DateTime(now.year + 1, 12, 31),
        ),
        DateField(
          controller: _end,
          label: 'End date',
          lastDate: DateTime(now.year + 1, 12, 31),
          validator: (v) {
            if (v.isEmpty || _start.text.isEmpty) return null;
            return v.compareTo(_start.text) < 0
                ? 'The end date cannot be earlier than the start date.'
                : null;
          },
        ),
        appTextField(controller: _duration, label: 'Duration', maxLength: 60),
        appTextField(
          controller: _credits,
          label: 'Credits earned',
          maxLength: 30,
        ),
        appTextField(
          controller: _year,
          label: 'Year',
          maxLength: 4,
          keyboardType: TextInputType.number,
          validator: (v) => validateYear(v, max: now.year + 1),
        ),
        ChoiceDropdown(
          label: 'Purpose',
          options: const ['Promotion', 'Professional Development', 'Other'],
          value: _purpose,
          onChanged: (v) => setState(() => _purpose = v),
        ),
        if (_purpose == 'Other')
          appTextField(
            controller: _purposeOther,
            label: 'Specify other purpose',
            mandatory: true,
            maxLength: 150,
          ),
      ],
    );
  }
}
