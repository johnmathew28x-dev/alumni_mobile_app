import '../services/api_helpers.dart';

class TracerStudyModel {
  final int id;
  final String title;
  final String? description;
  final String? startDate;
  final String? endDate;
  final String surveyType;
  final bool answered;
  final bool inProgress;
  const TracerStudyModel({
    required this.id,
    required this.title,
    required this.surveyType,
    required this.answered,
    required this.inProgress,
    this.description,
    this.startDate,
    this.endDate,
  });

  bool get isGts => surveyType == 'gts';

  factory TracerStudyModel.fromJson(Map<String, dynamic> json) {
    final title = asText(json['title']);
    if (title == null) throw const FormatException('Invalid tracer study.');
    return TracerStudyModel(
      id: requireId(json['id'], 'tracer study'),
      title: title,
      description: asText(json['description']),
      startDate: asText(json['start_date']),
      endDate: asText(json['end_date']),
      surveyType: asText(json['survey_type']) ?? 'custom',
      answered: asBool(json['answered']),
      inProgress: asBool(json['in_progress']),
    );
  }
}

class TracerQuestion {
  final int id;
  final String question;
  final String type;
  final List<String> options;
  final bool isRequired;
  const TracerQuestion({
    required this.id,
    required this.question,
    required this.type,
    required this.options,
    required this.isRequired,
  });


  List<String> get choices => type == 'yes_no' ? const ['Yes', 'No'] : options;

  factory TracerQuestion.fromJson(Map<String, dynamic> json) {
    final question = asText(json['question']);
    if (question == null) throw const FormatException('Invalid question.');
    final raw = json['options'];
    return TracerQuestion(
      id: requireId(json['id'], 'question'),
      question: question,
      type: asText(json['question_type']) ?? 'text',
      options: raw is List ? raw.map((e) => '$e').toList() : const [],
      isRequired: asBool(json['is_required']),
    );
  }
}

class TracerQuestionnaire {
  final String title;
  final String? description;
  final List<TracerQuestion> questions;
  final Map<int, String> answers;
  const TracerQuestionnaire({
    required this.title,
    required this.questions,
    required this.answers,
    this.description,
  });

  factory TracerQuestionnaire.fromJson(Map<String, dynamic> body) {
    final study = objectOf(body, 'study');
    final rawQuestions = body['questions'];
    if (rawQuestions is! List ||
        rawQuestions.any((q) => q is! Map<String, dynamic>)) {
      throw Exception('Unexpected response from the server.');
    }
    final answers = <int, String>{};
    final rawAnswers = body['answers'];
    if (rawAnswers is Map) {
      rawAnswers.forEach((key, value) {
        final id = asInt(key);
        if (id != null && value != null) answers[id] = '$value';
      });
    }
    return TracerQuestionnaire(
      title: asText(study['title']) ?? 'Tracer study',
      description: asText(study['description']),
      questions: rawQuestions
          .cast<Map<String, dynamic>>()
          .map(TracerQuestion.fromJson)
          .toList(),
      answers: answers,
    );
  }
}
