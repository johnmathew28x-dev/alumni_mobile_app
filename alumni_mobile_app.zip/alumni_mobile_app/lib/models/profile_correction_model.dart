import '../services/api_helpers.dart';

class CorrectionChange {
  final String label;
  final String? oldValue;
  final String? newValue;
  final bool sensitive;
  const CorrectionChange({
    required this.label,
    this.oldValue,
    this.newValue,
    this.sensitive = false,
  });

  factory CorrectionChange.fromJson(Map<String, dynamic> json) =>
      CorrectionChange(
        label: asText(json['label']) ?? asText(json['field']) ?? 'Field',
        oldValue: asText(json['old']),
        newValue: asText(json['new']),
        sensitive: asBool(json['sensitive']),
      );
}

/// A profile correction request created by the signed-in alumnus.
class CorrectionRequest {
  final int id;
  final int? alumniId;
  final String? alumniNumber;
  final String fullName;
  final String status;
  final String? reason;
  final String? reviewNote;
  final String? reviewer;
  final String? created;
  final String? reviewedAt;
  final List<CorrectionChange> changes;
  const CorrectionRequest({
    required this.id,
    required this.fullName,
    required this.status,
    required this.changes,
    this.alumniId,
    this.alumniNumber,
    this.reason,
    this.reviewNote,
    this.reviewer,
    this.created,
    this.reviewedAt,
  });

  factory CorrectionRequest.fromJson(Map<String, dynamic> json) {
    final list = json['change_list'];
    if (list != null &&
        (list is! List || list.any((e) => e is! Map<String, dynamic>))) {
      throw const FormatException('Invalid correction request.');
    }
    final name = [
      asText(json['first_name']),
      asText(json['last_name']),
    ].whereType<String>().join(' ');
    return CorrectionRequest(
      id: requireId(json['id'], 'correction request'),
      alumniId: asInt(json['alumni_id']),
      alumniNumber: asText(json['alumni_number']),
      fullName: name.isEmpty ? 'Unknown alumnus' : name,
      status: asText(json['status']) ?? 'pending',
      reason: asText(json['reason']),
      reviewNote: asText(json['review_note']),
      reviewer: asText(json['reviewer']),
      created: asText(json['created']),
      reviewedAt: asText(json['reviewed_at']),
      changes: (list as List? ?? const [])
          .cast<Map<String, dynamic>>()
          .map(CorrectionChange.fromJson)
          .toList(),
    );
  }

  bool get isPending => status == 'pending';
}
