import '../services/api_helpers.dart';

/// Editable alumni profile fields (api: Profile/details, Profile/update).
class ProfileModel {
  final String? alumniNumber;
  final String firstName;
  final String? middleName;
  final String lastName;
  final String? suffix;
  final String? dateOfBirth; // yyyy-MM-dd
  final String? gender;
  final String? contactNumber;
  final String? email;
  final String? address;
  final int? civilStatusId;
  final int? regionId;
  final String? province;
  final String? cityMunicipality;
  final int? residenceTypeId;
  final String verificationStatus;

  /// 'draft' (editable) or 'submitted' (locked; changes need a correction
  /// request). From Profile/details.
  final String submissionStatus;
  const ProfileModel({
    required this.firstName,
    required this.lastName,
    required this.verificationStatus,
    this.submissionStatus = 'draft',
    this.alumniNumber,
    this.middleName,
    this.suffix,
    this.dateOfBirth,
    this.gender,
    this.contactNumber,
    this.email,
    this.address,
    this.civilStatusId,
    this.regionId,
    this.province,
    this.cityMunicipality,
    this.residenceTypeId,
  });

  bool get isLocked => submissionStatus == 'submitted';

  /// The editable fields as the API expects them (empty text for no value).
  /// Used to submit the saved draft and to detect "no changes" on a correction.
  Map<String, String> toForm() => {
    'first_name': firstName,
    'middle_name': middleName ?? '',
    'last_name': lastName,
    'suffix': suffix ?? '',
    'date_of_birth': dateOfBirth ?? '',
    'gender': gender ?? '',
    'contact_number': contactNumber ?? '',
    'address': address ?? '',
    'civil_status_id': civilStatusId?.toString() ?? '',
    'region_id': regionId?.toString() ?? '',
    'province': province ?? '',
    'city_municipality': cityMunicipality ?? '',
    'residence_type_id': residenceTypeId?.toString() ?? '',
  };

  String get fullName => [
    firstName,
    middleName,
    lastName,
    suffix,
  ].where((p) => p != null && p.isNotEmpty).join(' ');

  factory ProfileModel.fromJson(Map<String, dynamic> json) {
    final first = asText(json['first_name']);
    final last = asText(json['last_name']);
    if (first == null || last == null) {
      throw const FormatException('Invalid profile record.');
    }
    return ProfileModel(
      alumniNumber: asText(json['alumni_number']),
      firstName: first,
      middleName: asText(json['middle_name']),
      lastName: last,
      suffix: asText(json['suffix']),
      dateOfBirth: asText(json['date_of_birth']),
      gender: asText(json['gender']),
      contactNumber: asText(json['contact_number']),
      email: asText(json['email']),
      address: asText(json['address']),
      civilStatusId: asInt(json['civil_status_id']),
      regionId: asInt(json['region_id']),
      province: asText(json['province']),
      cityMunicipality: asText(json['city_municipality']),
      residenceTypeId: asInt(json['residence_type_id']),
      verificationStatus: asText(json['verification_status']) ?? 'pending',
      submissionStatus: asText(json['submission_status']) ?? 'draft',
    );
  }
}
