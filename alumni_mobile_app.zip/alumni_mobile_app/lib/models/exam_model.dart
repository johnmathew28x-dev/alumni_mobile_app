import '../services/api_helpers.dart';

class ExamModel {
  final int id;
  final String name;
  final String? dateTaken;
  final String? rating;
  final String result;
  const ExamModel({
    required this.id,
    required this.name,
    required this.result,
    this.dateTaken,
    this.rating,
  });

  factory ExamModel.fromJson(Map<String, dynamic> json) {
    final name = asText(json['exam_name']);
    if (name == null) throw const FormatException('Invalid examination.');
    return ExamModel(
      id: requireId(json['id'], 'examination'),
      name: name,
      dateTaken: asText(json['date_taken']),
      rating: asText(json['rating']),
      result: asText(json['result']) ?? 'Pending',
    );
  }
}
