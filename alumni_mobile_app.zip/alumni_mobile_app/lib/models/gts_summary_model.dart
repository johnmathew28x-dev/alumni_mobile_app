import '../services/api_helpers.dart';

double? _asDouble(Object? value) =>
    value == null ? null : double.tryParse('$value');

/// Summary figures shown on the alumni dashboard.
class GtsSummary {
  final int respondents;
  final double? completionRate;
  final double? employmentRate;
  final double? relatedRate;
  final double? relevanceRate;
  final bool reliable;
  const GtsSummary({
    this.respondents = 0,
    this.completionRate,
    this.employmentRate,
    this.relatedRate,
    this.relevanceRate,
    this.reliable = false,
  });

  factory GtsSummary.fromJson(Object? json) {
    if (json is! Map<String, dynamic>) return const GtsSummary();
    final kpis = json['kpis'] is Map<String, dynamic>
        ? json['kpis'] as Map<String, dynamic>
        : const <String, dynamic>{};
    final part = json['participation'] is Map<String, dynamic>
        ? json['participation'] as Map<String, dynamic>
        : const <String, dynamic>{};
    return GtsSummary(
      respondents: asInt(kpis['respondents']) ?? 0,
      completionRate: _asDouble(part['rate']),
      employmentRate: _asDouble(kpis['employment_rate']),
      relatedRate: _asDouble(kpis['related_rate']),
      relevanceRate: _asDouble(kpis['relevance_rate']),
      reliable: asBool(kpis['reliable']),
    );
  }
}
