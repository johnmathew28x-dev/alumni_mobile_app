import '../services/api_helpers.dart';

class LookupItem {
  final int id;
  final String name;
  final String? code;
  const LookupItem({required this.id, required this.name, this.code});

  factory LookupItem.fromJson(Map<String, dynamic> json) {
    final name = json['name'];
    if (name is! String || name.isEmpty) {
      throw const FormatException('Invalid lookup item.');
    }
    return LookupItem(
      id: requireId(json['id'], 'lookup'),
      name: name,
      code: asText(json['code']),
    );
  }
}

class Lookups {
  final List<LookupItem> programs;
  final List<LookupItem> employmentStatuses;
  final List<LookupItem> licenseTypes;
  final List<LookupItem> licensureStatuses;
  final List<LookupItem> civilStatuses;
  final List<LookupItem> regions;
  final List<LookupItem> residenceTypes;
  final List<LookupItem> employmentTypes;
  final List<LookupItem> industries;
  final List<LookupItem> jobLevels;
  final List<LookupItem> salaryRanges;

  const Lookups({
    this.programs = const [],
    this.employmentStatuses = const [],
    this.licenseTypes = const [],
    this.licensureStatuses = const [],
    this.civilStatuses = const [],
    this.regions = const [],
    this.residenceTypes = const [],
    this.employmentTypes = const [],
    this.industries = const [],
    this.jobLevels = const [],
    this.salaryRanges = const [],
  });

  factory Lookups.fromJson(Map<String, dynamic> json) {
    List<LookupItem> list(String key) {
      final value = json[key];
      if (value == null) return const [];
      if (value is! List || value.any((e) => e is! Map<String, dynamic>)) {
        throw FormatException('Invalid lookup list: $key.');
      }
      return value
          .cast<Map<String, dynamic>>()
          .map(LookupItem.fromJson)
          .toList();
    }

    return Lookups(
      programs: list('programs'),
      employmentStatuses: list('employment_statuses'),
      licenseTypes: list('license_types'),
      licensureStatuses: list('licensure_statuses'),
      civilStatuses: list('civil_statuses'),
      regions: list('regions'),
      residenceTypes: list('residence_types'),
      employmentTypes: list('employment_types'),
      industries: list('industries'),
      jobLevels: list('job_levels'),
      salaryRanges: list('salary_ranges'),
    );
  }

  static String? nameOf(List<LookupItem> items, int? id) {
    if (id == null) return null;
    for (final item in items) {
      if (item.id == id) return item.name;
    }
    return null;
  }
}
