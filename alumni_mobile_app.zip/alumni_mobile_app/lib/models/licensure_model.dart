import '../services/api_helpers.dart';

class LicensureModel {
  final int id;
  final int licenseTypeId;
  final String licenseName;
  final int statusId;
  final String statusName;
  final int? examinationYear;
  const LicensureModel({
    required this.id,
    required this.licenseTypeId,
    required this.licenseName,
    required this.statusId,
    required this.statusName,
    this.examinationYear,
  });

  factory LicensureModel.fromJson(Map<String, dynamic> json) => LicensureModel(
    id: requireId(json['id'], 'licensure'),
    licenseTypeId: requireId(json['license_type_id'], 'licensure'),
    licenseName: asText(json['license_name']) ?? 'License',
    statusId: requireId(json['status_id'], 'licensure'),
    statusName: asText(json['status_name']) ?? '',
    examinationYear: asInt(json['examination_year']),
  );
}
