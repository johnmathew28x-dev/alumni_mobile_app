import '../services/api_helpers.dart';

class AcademicModel {
  final int id;
  final int programId;
  final String programName;
  final String? programCode;
  final String? major;
  final int graduationYear;
  final String? batch;
  final String? studentId;
  const AcademicModel({
    required this.id,
    required this.programId,
    required this.programName,
    required this.graduationYear,
    this.programCode,
    this.major,
    this.batch,
    this.studentId,
  });

  factory AcademicModel.fromJson(Map<String, dynamic> json) {
    final year = asInt(json['graduation_year']);
    if (year == null) throw const FormatException('Invalid program record.');
    return AcademicModel(
      id: requireId(json['id'], 'program'),
      programId: requireId(json['program_id'], 'program'),
      programName: asText(json['program_name']) ?? 'Program',
      programCode: asText(json['program_code']),
      major: asText(json['major']),
      graduationYear: year,
      batch: asText(json['batch']),
      studentId: asText(json['student_id']),
    );
  }
}
