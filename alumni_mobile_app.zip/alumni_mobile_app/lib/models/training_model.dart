import '../services/api_helpers.dart';

class TrainingModel {
  final int id;
  final String title;
  final String type;
  final String? organizer;
  final String? dateStart;
  final String? dateEnd;
  final String? duration;
  final String? credits;
  final String? college;
  final int? year;
  final String? purpose;
  final String? purposeOther;
  const TrainingModel({
    required this.id,
    required this.title,
    required this.type,
    this.organizer,
    this.dateStart,
    this.dateEnd,
    this.duration,
    this.credits,
    this.college,
    this.year,
    this.purpose,
    this.purposeOther,
  });

  factory TrainingModel.fromJson(Map<String, dynamic> json) {
    final title = asText(json['training_title']);
    if (title == null) throw const FormatException('Invalid training record.');
    return TrainingModel(
      id: requireId(json['id'], 'training'),
      title: title,
      type: asText(json['training_type']) ?? 'Training',
      organizer: asText(json['organizer']),
      dateStart: asText(json['date_start']),
      dateEnd: asText(json['date_end']),
      duration: asText(json['duration']),
      credits: asText(json['credits_earned']),
      college: asText(json['college_university']),
      year: asInt(json['training_year']),
      purpose: asText(json['purpose']),
      purposeOther: asText(json['purpose_other']),
    );
  }
}
