import '../services/api_helpers.dart';
import 'feed_models.dart';
import 'tracer_models.dart';

class DashboardModel {
  final String firstName;
  final String? alumniNumber;
  final String verificationStatus;
  final int eventsAttended;
  final int eventsTotal;
  final double? attendanceRate;
  final List<AnnouncementModel> announcements;
  final List<EventModel> events;
  final List<TracerStudyModel> studies;
  const DashboardModel({
    required this.firstName,
    required this.verificationStatus,
    required this.eventsAttended,
    required this.eventsTotal,
    required this.announcements,
    required this.events,
    required this.studies,
    this.alumniNumber,
    this.attendanceRate,
  });

  factory DashboardModel.fromJson(Map<String, dynamic> json) {
    final alumni = objectOf(json, 'alumni');
    final attendance = json['attendance'] is Map<String, dynamic>
        ? json['attendance'] as Map<String, dynamic>
        : const <String, dynamic>{};
    List<T> list<T>(String key, T Function(Map<String, dynamic>) parse) {
      final value = json[key];
      if (value == null) return <T>[];
      if (value is! List || value.any((e) => e is! Map<String, dynamic>)) {
        throw FormatException('Invalid dashboard list: $key.');
      }
      return value.cast<Map<String, dynamic>>().map(parse).toList();
    }

    return DashboardModel(
      firstName: asText(alumni['first_name']) ?? '',
      alumniNumber: asText(alumni['alumni_number']),
      verificationStatus: asText(alumni['verification_status']) ?? 'pending',
      eventsAttended: asInt(attendance['attended']) ?? 0,
      eventsTotal: asInt(attendance['total']) ?? 0,
      attendanceRate: double.tryParse('${attendance['rate']}'),
      announcements: list('announcements', AnnouncementModel.fromJson),
      events: list('events', EventModel.fromJson),
      studies: list('studies', TracerStudyModel.fromJson),
    );
  }
}
