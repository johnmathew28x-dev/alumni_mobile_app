import '../services/api_helpers.dart';

class EmploymentModel {
  final int id;
  final int statusId;
  final String statusName;
  final String? employer;
  final String? jobPosition;
  final String? location;
  final String? placeOfWork;
  final int? tenureId;
  final int? industryId;
  final int? jobLevelId;
  final int? salaryRangeId;
  final bool? relatedToDegree;
  final bool isFirstJob;
  final bool isCurrent;
  final String? dateHired;
  final String? dateEnded;
  final String? industryName;
  const EmploymentModel({
    required this.id,
    required this.statusId,
    required this.statusName,
    required this.isFirstJob,
    required this.isCurrent,
    this.employer,
    this.jobPosition,
    this.location,
    this.placeOfWork,
    this.tenureId,
    this.industryId,
    this.jobLevelId,
    this.salaryRangeId,
    this.relatedToDegree,
    this.dateHired,
    this.dateEnded,
    this.industryName,
  });

  factory EmploymentModel.fromJson(Map<String, dynamic> json) {
    final related = json['related_to_degree'];
    return EmploymentModel(
      id: requireId(json['id'], 'employment'),
      statusId: requireId(json['employment_status_id'], 'employment'),
      statusName: asText(json['status_name']) ?? 'Employment',
      employer: asText(json['employer']),
      jobPosition: asText(json['job_position']),
      location: asText(json['employment_location']),
      placeOfWork: asText(json['place_of_work']),
      tenureId: asInt(json['employment_type_id']),
      industryId: asInt(json['industry_id']),
      jobLevelId: asInt(json['job_level_id']),
      salaryRangeId: asInt(json['salary_range_id']),
      relatedToDegree: related == null || '$related'.isEmpty
          ? null
          : asBool(related),
      isFirstJob: asBool(json['is_first_job']),
      isCurrent: asBool(json['is_current']),
      dateHired: asText(json['date_hired']),
      dateEnded: asText(json['date_ended']),
      industryName: asText(json['industry_name']),
    );
  }
}
