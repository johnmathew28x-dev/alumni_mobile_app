import '../services/api_helpers.dart';

class AnnouncementModel {
  final int id;
  final String title;
  final String content;
  final String? publishedAt;
  const AnnouncementModel({
    required this.id,
    required this.title,
    required this.content,
    this.publishedAt,
  });

  factory AnnouncementModel.fromJson(Map<String, dynamic> json) {
    final title = asText(json['title']);
    if (title == null) throw const FormatException('Invalid announcement.');
    return AnnouncementModel(
      id: requireId(json['id'], 'announcement'),
      title: title,
      content: asText(json['content']) ?? '',
      publishedAt: asText(json['published_at']),
    );
  }
}

class JobModel {
  final int id;
  final String title;
  final String? company;
  final String? location;
  final String? description;
  final String? qualifications;
  final String? instructions;
  final String? deadline;
  const JobModel({
    required this.id,
    required this.title,
    this.company,
    this.location,
    this.description,
    this.qualifications,
    this.instructions,
    this.deadline,
  });

  factory JobModel.fromJson(Map<String, dynamic> json) {
    final title = asText(json['job_title']);
    if (title == null) throw const FormatException('Invalid job posting.');
    return JobModel(
      id: requireId(json['id'], 'job'),
      title: title,
      company: asText(json['company']),
      location: asText(json['location']),
      description: asText(json['description']),
      qualifications: asText(json['qualifications']),
      instructions: asText(json['application_instructions']),
      deadline: asText(json['deadline']),
    );
  }
}

class EventModel {
  final int id;
  final String title;
  final String? description;
  final String? eventDate;
  final String? eventTime;
  final String? location;
  final String? registrationDeadline;
  final String status;
  final bool isRegistered;
  const EventModel({
    required this.id,
    required this.title,
    required this.status,
    required this.isRegistered,
    this.description,
    this.eventDate,
    this.eventTime,
    this.location,
    this.registrationDeadline,
  });

  factory EventModel.fromJson(Map<String, dynamic> json) {
    final title = asText(json['title']);
    if (title == null) throw const FormatException('Invalid event.');
    return EventModel(
      id: requireId(json['id'], 'event'),
      title: title,
      description: asText(json['description']),
      eventDate: asText(json['event_date']),
      eventTime: asText(json['event_time']),
      location: asText(json['location']),
      registrationDeadline: asText(json['registration_deadline']),
      status: asText(json['status']) ?? 'upcoming',
      isRegistered: (asInt(json['is_registered']) ?? 0) > 0,
    );
  }
}
