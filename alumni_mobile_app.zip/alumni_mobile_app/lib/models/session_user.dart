import '../services/api_helpers.dart';

class SessionUser {
  static const roleAlumni = 'Alumni';

  final int id;
  final String username;
  final String role;
  final int? alumniId;
  final String? alumniNumber;
  final String fullName;
  final String? pictureUrl;
  const SessionUser({
    required this.id,
    required this.username,
    required this.role,
    required this.fullName,
    this.alumniId,
    this.alumniNumber,
    this.pictureUrl,
  });

  factory SessionUser.fromJson(Map<String, dynamic> json) {
    final username = json['username'];
    final role = json['role'];
    if (username is! String || role is! String) {
      throw const FormatException('Invalid user record.');
    }
    return SessionUser(
      id: requireId(json['id'], 'user'),
      username: username,
      role: role,
      alumniId: asInt(json['alumni_id']),
      alumniNumber: asText(json['alumni_number']),
      fullName: asText(json['full_name']) ?? username,
      pictureUrl: asText(json['picture_url']),
    );
  }
}
