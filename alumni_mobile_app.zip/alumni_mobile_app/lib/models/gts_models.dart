import '../services/api_helpers.dart';

/// One answer choice offered by the survey (api: Gts/start -> options).
class GtsChoice {
  final String value;
  final String label;
  final bool isOther;
  const GtsChoice(this.value, this.label, {this.isOther = false});

  factory GtsChoice.fromJson(Map<String, dynamic> json) {
    final name = asText(json['name']);
    if (name == null) throw const FormatException('Invalid survey option.');
    return GtsChoice(
      '${requireId(json['id'], 'survey option')}',
      name,
      isOther: asBool(json['is_other']),
    );
  }
}

/// All answer lists for the form, keyed as the server sends them.
class GtsOptions {
  final Map<String, List<GtsChoice>> lists;
  const GtsOptions(this.lists);

  factory GtsOptions.fromJson(Map<String, dynamic> json) => GtsOptions({
    for (final entry in json.entries)
      entry.key: _choices(entry.value, entry.key),
  });

  static List<GtsChoice> _choices(Object? value, String key) {
    if (value is! List || value.any((e) => e is! Map<String, dynamic>)) {
      throw FormatException('Invalid $key list.');
    }
    return value.cast<Map<String, dynamic>>().map(GtsChoice.fromJson).toList();
  }

  List<GtsChoice> of(String key) => lists[key] ?? const [];
}

/// Survey progress and the answers that decide which sections apply.
class GtsSurvey {
  final String status; // draft | submitted
  final String? employmentState; // employed | not_employed | never_employed
  final bool? currentIsFirstJob;
  final bool? curriculumRelevant;
  final int lastSection;
  const GtsSurvey({
    required this.status,
    required this.lastSection,
    this.employmentState,
    this.currentIsFirstJob,
    this.curriculumRelevant,
  });

  factory GtsSurvey.fromJson(Map<String, dynamic> json) {
    bool? flag(Object? v) => v == null || '$v'.isEmpty ? null : asBool(v);
    return GtsSurvey(
      status: asText(json['status']) ?? 'draft',
      employmentState: asText(json['employment_state']),
      currentIsFirstJob: flag(json['current_is_first_job']),
      curriculumRelevant: flag(json['curriculum_relevant']),
      lastSection: asInt(json['last_section']) ?? 1,
    );
  }

  bool get isEmployed => employmentState == 'employed';

  /// The current job is also the first job, so the first-job details were
  /// already collected in Section 7.
  bool get merged => isEmployed && currentIsFirstJob == true;

  /// Same rule as the web form: which of the 14 steps apply to this person.
  bool isVisible(int n) {
    if (n <= 6 || n == 13 || n == 14) return true;
    if (employmentState == null) return false;
    if (n <= 11) return isEmployed;
    if (n == 12) return isEmployed && curriculumRelevant == true;
    return true;
  }

  List<int> get visibleSections => [
    for (var n = 1; n <= 14; n++)
      if (isVisible(n)) n,
  ];
}

/// Selected ids of a checklist question plus the free text for "Other".
class GtsChecked {
  final List<String> ids;
  final String other;
  const GtsChecked(this.ids, this.other);

  factory GtsChecked.fromJson(Object? json) {
    if (json is! Map<String, dynamic>) return const GtsChecked([], '');
    final ids = json['ids'];
    return GtsChecked(
      ids is List ? ids.map((e) => '$e').toList() : const [],
      asText(json['other']) ?? '',
    );
  }
}

/// The saved answers (api: Gts/start -> data).
class GtsData {
  final GtsSurvey survey;
  final Map<String, dynamic> general;
  final Map<String, dynamic> education;
  final GtsChecked course;
  final GtsChecked unemployment;
  final Map<String, dynamic> current;
  final Map<String, dynamic> first;
  final GtsChecked accept;
  final GtsChecked change;
  final GtsChecked competencies;
  final String feedback;
  const GtsData({
    required this.survey,
    required this.general,
    required this.education,
    required this.course,
    required this.unemployment,
    required this.current,
    required this.first,
    required this.accept,
    required this.change,
    required this.competencies,
    required this.feedback,
  });

  factory GtsData.fromJson(Map<String, dynamic> json) {
    Map<String, dynamic> map(String key) {
      final v = json[key];
      return v is Map<String, dynamic> ? v : const <String, dynamic>{};
    }

    return GtsData(
      survey: GtsSurvey.fromJson(objectOf(json, 'survey')),
      general: map('general'),
      education: map('education'),
      course: GtsChecked.fromJson(json['course']),
      unemployment: GtsChecked.fromJson(json['unemployment']),
      current: map('current'),
      first: map('first'),
      accept: GtsChecked.fromJson(json['accept']),
      change: GtsChecked.fromJson(json['change']),
      competencies: GtsChecked.fromJson(json['competencies']),
      feedback: asText(json['feedback']) ?? '',
    );
  }
}

/// Response of Gts/start.
class GtsStart {
  final int studyId;
  final bool editable;
  final Map<int, String> sections;
  final GtsData data;
  final GtsOptions options;
  const GtsStart({
    required this.studyId,
    required this.editable,
    required this.sections,
    required this.data,
    required this.options,
  });

  factory GtsStart.fromJson(Map<String, dynamic> json) {
    final titles = json['sections'];
    return GtsStart(
      studyId: requireId(json['study_id'], 'survey'),
      editable: asBool(json['editable']),
      sections: {
        if (titles is Map)
          for (final e in titles.entries)
            if (int.tryParse('${e.key}') != null)
              int.parse('${e.key}'): '${e.value}',
      },
      data: GtsData.fromJson(objectOf(json, 'data')),
      options: GtsOptions.fromJson(objectOf(json, 'options')),
    );
  }
}

class GtsReviewSection {
  final String title;
  final List<(String, String)> rows;
  const GtsReviewSection(this.title, this.rows);
}

/// Response of Gts/review: what was answered and what is still missing.
class GtsReview {
  final List<GtsReviewSection> sections;
  final List<String> missing;
  const GtsReview(this.sections, this.missing);

  factory GtsReview.fromJson(Map<String, dynamic> json) {
    final raw = json['sections'];
    final missing = json['missing'];
    if (raw is! List) throw const FormatException('Invalid survey review.');
    return GtsReview(
      [
        for (final s in raw)
          if (s is Map<String, dynamic>)
            GtsReviewSection(asText(s['title']) ?? '', [
              for (final r in (s['rows'] is List ? s['rows'] as List : const []))
                if (r is List && r.length >= 2)
                  (asText(r[0]) ?? '', asText(r[1]) ?? '—'),
            ]),
      ],
      missing is List ? missing.map((e) => '$e').toList() : const [],
    );
  }
}
