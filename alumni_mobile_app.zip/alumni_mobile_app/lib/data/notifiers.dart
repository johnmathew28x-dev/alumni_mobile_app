import 'package:flutter/material.dart';
import '../models/session_user.dart';

final ValueNotifier<int> selectedPageNotifier = ValueNotifier<int>(0);

final ValueNotifier<bool> isDarkModeNotifier = ValueNotifier(false);

final ValueNotifier<SessionUser?> sessionNotifier = ValueNotifier<SessionUser?>(
  null,
);
