import '../models/academic_model.dart';
import 'api_service.dart';

class AcademicService {
  final ApiService api;
  AcademicService(this.api);

  Future<List<AcademicModel>> getAll() async =>
      (await api.list('Academics')).map(AcademicModel.fromJson).toList();

  Map<String, String> _form({
    required int programId,
    required int graduationYear,
    String major = '',
    String batch = '',
    String studentId = '',
  }) => {
    'program_id': '$programId',
    'graduation_year': '$graduationYear',
    'major': major,
    'batch': batch,
    'student_id': studentId,
  };

  Future<void> add({
    required int programId,
    required int graduationYear,
    String major = '',
    String batch = '',
    String studentId = '',
  }) => api.mutate(
    'Academics/add',
    form: _form(
      programId: programId,
      graduationYear: graduationYear,
      major: major,
      batch: batch,
      studentId: studentId,
    ),
  );

  Future<void> update(
    int id, {
    required int programId,
    required int graduationYear,
    String major = '',
    String batch = '',
    String studentId = '',
  }) => api.mutate(
    'Academics/edit/$id',
    form: _form(
      programId: programId,
      graduationYear: graduationYear,
      major: major,
      batch: batch,
      studentId: studentId,
    ),
  );

  Future<void> delete(int id) =>
      api.mutate('Academics/delete/$id', form: const <String, String>{});
}
