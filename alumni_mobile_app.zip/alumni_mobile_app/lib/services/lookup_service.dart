import '../models/lookup_model.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class LookupService {
  final ApiService api;
  LookupService(this.api);

  Future<Lookups> getAll() async =>
      Lookups.fromJson(objectOf(await api.request('Lookups/all'), 'data'));
}
