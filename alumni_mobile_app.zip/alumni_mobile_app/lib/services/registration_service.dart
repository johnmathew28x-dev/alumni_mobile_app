import '../models/lookup_model.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class RegistrationInput {
  final String firstName;
  final String lastName;
  final String username;
  final String email;
  final String password;
  final String confirmPassword;
  final int programId;
  final int graduationYear;
  const RegistrationInput({
    required this.firstName,
    required this.lastName,
    required this.username,
    required this.email,
    required this.password,
    required this.confirmPassword,
    required this.programId,
    required this.graduationYear,
  });

  Map<String, String> toForm() => {
    'first_name': firstName.trim(),
    'last_name': lastName.trim(),
    'username': username.trim(),
    'email': email.trim(),
    // Passwords are sent exactly as typed (not trimmed).
    'password': password,
    'confirm_password': confirmPassword,
    'program_id': '$programId',
    'graduation_year': '$graduationYear',
  };
}

class RegistrationService {
  final ApiService api;
  RegistrationService(this.api);

  Future<List<LookupItem>> getPrograms() async =>
      rowsOf(await api.request('Auth/programs'))
          .map(LookupItem.fromJson)
          .toList();

  Future<void> register(RegistrationInput input) =>
      api.mutate('Auth/register', form: input.toForm());
}
