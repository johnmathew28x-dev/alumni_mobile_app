import '../models/licensure_model.dart';
import 'api_service.dart';

class LicensureService {
  final ApiService api;
  LicensureService(this.api);

  Future<List<LicensureModel>> getAll() async =>
      (await api.list('Licensures')).map(LicensureModel.fromJson).toList();

  Map<String, String> _form(int typeId, int statusId, String year) => {
    'license_type_id': '$typeId',
    'status_id': '$statusId',
    'examination_year': year,
  };

  Future<void> add({
    required int licenseTypeId,
    required int statusId,
    String examinationYear = '',
  }) => api.mutate(
    'Licensures/add',
    form: _form(licenseTypeId, statusId, examinationYear),
  );

  Future<void> update(
    int id, {
    required int licenseTypeId,
    required int statusId,
    String examinationYear = '',
  }) => api.mutate(
    'Licensures/edit/$id',
    form: _form(licenseTypeId, statusId, examinationYear),
  );

  Future<void> delete(int id) =>
      api.mutate('Licensures/delete/$id', form: const <String, String>{});
}
