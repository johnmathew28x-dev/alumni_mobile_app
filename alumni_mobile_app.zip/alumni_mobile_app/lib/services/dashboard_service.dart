import '../models/dashboard_model.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class DashboardService {
  final ApiService api;
  DashboardService(this.api);

  Future<DashboardModel> getSummary() async => DashboardModel.fromJson(
    objectOf(await api.request('Dashboard/summary'), 'data'),
  );
}
