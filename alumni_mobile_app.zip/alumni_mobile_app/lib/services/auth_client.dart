import 'dart:convert';
import 'package:http/http.dart' as http;
import 'token_store.dart';

class AuthClient extends http.BaseClient {
  final TokenStore _tokens;
  final http.Client _inner;
  final void Function()? onUnauthorized;

  AuthClient(this._tokens, {http.Client? inner, this.onUnauthorized})
    : _inner = inner ?? http.Client();

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    final token = await _tokens.read();
    final hadToken = token != null && token.isNotEmpty;
    if (hadToken) request.headers['Authorization'] = 'Bearer $token';

    final response = await _inner.send(request);
    final code = response.statusCode;
    if (code < 400 || code >= 500) return response;

    final bytes = await response.stream.toBytes();
    if (code == 401 && hadToken) {
      await _tokens.clear();
      onUnauthorized?.call();
    }
    return http.StreamedResponse(
      Stream<List<int>>.value(bytes),
      _isApiError(bytes) ? 200 : code,
      contentLength: bytes.length,
      request: response.request,
      headers: response.headers,
      isRedirect: response.isRedirect,
      persistentConnection: response.persistentConnection,
      reasonPhrase: response.reasonPhrase,
    );
  }

  static bool _isApiError(List<int> bytes) {
    try {
      final body = jsonDecode(utf8.decode(bytes));
      return body is Map && body['status'] == 'error';
    } catch (_) {
      return false;
    }
  }

  @override
  void close() => _inner.close();
}
