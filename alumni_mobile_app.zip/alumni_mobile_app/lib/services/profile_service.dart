import '../models/profile_model.dart';
import '../models/profile_correction_model.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class ProfileInput {
  final String firstName;
  final String middleName;
  final String lastName;
  final String suffix;
  final String dateOfBirth; // yyyy-MM-dd
  final String gender; // Male | Female | Other
  final String contactNumber;
  final String address;
  final int civilStatusId;
  final int regionId;
  final String province;
  final String cityMunicipality;
  final int? residenceTypeId;
  const ProfileInput({
    required this.firstName,
    required this.lastName,
    required this.dateOfBirth,
    required this.gender,
    required this.civilStatusId,
    required this.regionId,
    required this.province,
    this.middleName = '',
    this.suffix = '',
    this.contactNumber = '',
    this.address = '',
    this.cityMunicipality = '',
    this.residenceTypeId,
  });

  Map<String, String> toForm() => {
    'first_name': firstName,
    'middle_name': middleName,
    'last_name': lastName,
    'suffix': suffix,
    'date_of_birth': dateOfBirth,
    'gender': gender,
    'contact_number': contactNumber,
    'address': address,
    'civil_status_id': '$civilStatusId',
    'region_id': '$regionId',
    'province': province,
    'city_municipality': cityMunicipality,
    'residence_type_id': residenceTypeId?.toString() ?? '',
  };
}

class ProfileService {
  final ApiService api;
  ProfileService(this.api);

  Future<ProfileModel> getDetails() async => ProfileModel.fromJson(
    objectOf(await api.request('Profile/details'), 'data'),
  );

  Future<void> update(ProfileInput input) =>
      api.mutate('Profile/update', form: input.toForm());

  Future<void> submit(ProfileModel saved) => api.mutate(
    'Profile/submit',
    form: {...saved.toForm(), 'privacy_ack': '1'},
  );

  Future<void> requestCorrection(
    ProfileInput input, {
    required String reason,
  }) => api.mutate(
    'Profile/requestCorrection',
    form: {...input.toForm(), 'reason': reason.trim()},
  );

  Future<List<CorrectionRequest>> getCorrections() async => rowsOf(
    await api.request('Profile/corrections'),
  ).map(CorrectionRequest.fromJson).toList();

  Future<void> changePassword({
    required String current,
    required String next,
    required String confirm,
  }) => api.mutate(
    'Profile/password',
    form: {
      'current_password': current,
      'new_password': next,
      'confirm_password': confirm,
    },
  );
}
