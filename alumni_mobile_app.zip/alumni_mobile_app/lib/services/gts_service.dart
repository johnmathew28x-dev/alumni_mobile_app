import '../models/gts_models.dart';
import 'api_helpers.dart';
import 'api_service.dart';

/// CHED Graduate Tracer Survey (api: Gts/*). The server validates every
/// section and decides which sections apply; this class only moves data.
class GtsService {
  final ApiService api;
  GtsService(this.api);

  Future<GtsStart> start(int studyId) async =>
      GtsStart.fromJson(await api.request('Gts/start/$studyId'));

  /// Saves one section and returns the updated survey progress.
  Future<GtsSurvey> saveSection(
    int studyId,
    int section,
    Map<String, String> form,
  ) async {
    final body = await api.request(
      'Gts/saveSection/$studyId',
      form: {...form, 'section': '$section'},
    );
    return GtsSurvey.fromJson(objectOf(objectOf(body, 'data'), 'survey'));
  }

  Future<GtsReview> review(int studyId) async =>
      GtsReview.fromJson(await api.request('Gts/review/$studyId'));

  Future<void> submit(int studyId) =>
      api.mutate('Gts/submit/$studyId', form: const <String, String>{});

  /// Checklist answers are sent as PHP arrays: name[0]=1&name[1]=4 ...
  static Map<String, String> indexed(String name, Iterable<String> values) => {
    for (final (i, v) in values.indexed) '$name[$i]': v,
  };
}
