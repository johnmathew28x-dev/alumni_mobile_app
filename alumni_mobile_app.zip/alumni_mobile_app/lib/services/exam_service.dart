import '../models/exam_model.dart';
import 'api_service.dart';

class ExamService {
  final ApiService api;
  ExamService(this.api);

  Future<List<ExamModel>> getAll() async =>
      (await api.list('Exams')).map(ExamModel.fromJson).toList();

  Map<String, String> _form(
    String name,
    String dateTaken,
    String rating,
    String result,
  ) => {
    'exam_name': name,
    'date_taken': dateTaken,
    'rating': rating,
    'result': result,
  };

  Future<void> add({
    required String name,
    required String result,
    String dateTaken = '',
    String rating = '',
  }) => api.mutate(
    'Exams/add',
    form: _form(name, dateTaken, rating, result),
  );

  Future<void> update(
    int id, {
    required String name,
    required String result,
    String dateTaken = '',
    String rating = '',
  }) => api.mutate(
    'Exams/edit/$id',
    form: _form(name, dateTaken, rating, result),
  );

  Future<void> delete(int id) =>
      api.mutate('Exams/delete/$id', form: const <String, String>{});
}
