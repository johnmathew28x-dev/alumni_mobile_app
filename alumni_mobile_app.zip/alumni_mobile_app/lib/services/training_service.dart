import '../models/training_model.dart';
import 'api_service.dart';

class TrainingInput {
  final String title;
  final String type; 
  final String organizer;
  final String dateStart;
  final String dateEnd;
  final String duration;
  final String credits;
  final String college;
  final String year;
  final String purpose;
  final String purposeOther;
  const TrainingInput({
    required this.title,
    required this.type,
    this.organizer = '',
    this.dateStart = '',
    this.dateEnd = '',
    this.duration = '',
    this.credits = '',
    this.college = '',
    this.year = '',
    this.purpose = '',
    this.purposeOther = '',
  });

  Map<String, String> toForm() => {
    'training_title': title,
    'training_type': type,
    'organizer': organizer,
    'date_start': dateStart,
    'date_end': dateEnd,
    'duration': duration,
    'credits_earned': credits,
    'college_university': college,
    'training_year': year,
    'purpose': purpose,
    'purpose_other': purpose == 'Other' ? purposeOther : '',
  };
}

class TrainingService {
  final ApiService api;
  TrainingService(this.api);

  Future<List<TrainingModel>> getAll() async =>
      (await api.list('Trainings')).map(TrainingModel.fromJson).toList();

  Future<void> add(TrainingInput input) =>
      api.mutate('Trainings/add', form: input.toForm());

  Future<void> update(int id, TrainingInput input) =>
      api.mutate('Trainings/edit/$id', form: input.toForm());

  Future<void> delete(int id) =>
      api.mutate('Trainings/delete/$id', form: const <String, String>{});
}
