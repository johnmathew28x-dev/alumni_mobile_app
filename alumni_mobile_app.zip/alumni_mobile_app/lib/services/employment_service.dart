import '../models/employment_model.dart';
import 'api_service.dart';

class EmploymentInput {
  final int statusId;
  final String employer;
  final String jobPosition;
  final String location;
  final String placeOfWork; 
  final int? tenureId;
  final int? industryId;
  final int? jobLevelId;
  final int? salaryRangeId;
  final bool? relatedToDegree;
  final bool isFirstJob;
  final bool isCurrent;
  final String dateHired; 
  final String dateEnded;
  const EmploymentInput({
    required this.statusId,
    this.employer = '',
    this.jobPosition = '',
    this.location = '',
    this.placeOfWork = '',
    this.tenureId,
    this.industryId,
    this.jobLevelId,
    this.salaryRangeId,
    this.relatedToDegree,
    this.isFirstJob = false,
    this.isCurrent = false,
    this.dateHired = '',
    this.dateEnded = '',
  });

  Map<String, String> toForm() => {
    'employment_status_id': '$statusId',
    'employer': employer,
    'job_position': jobPosition,
    'employment_location': location,
    'place_of_work': placeOfWork,
    'employment_type_id': tenureId?.toString() ?? '',
    'industry_id': industryId?.toString() ?? '',
    'job_level_id': jobLevelId?.toString() ?? '',
    'salary_range_id': salaryRangeId?.toString() ?? '',
    'related_to_degree': relatedToDegree == null
        ? ''
        : (relatedToDegree! ? '1' : '0'),
    'is_first_job': isFirstJob ? '1' : '0',
    'is_current': isCurrent ? '1' : '0',
    'date_hired': dateHired,
    'date_ended': isCurrent ? '' : dateEnded,
  };
}

class EmploymentService {
  final ApiService api;
  EmploymentService(this.api);

  Future<List<EmploymentModel>> getAll() async =>
      (await api.list('Employments')).map(EmploymentModel.fromJson).toList();

  Future<void> add(EmploymentInput input) =>
      api.mutate('Employments/add', form: input.toForm());

  Future<void> update(int id, EmploymentInput input) =>
      api.mutate('Employments/edit/$id', form: input.toForm());

  Future<void> delete(int id) =>
      api.mutate('Employments/delete/$id', form: const <String, String>{});
}
