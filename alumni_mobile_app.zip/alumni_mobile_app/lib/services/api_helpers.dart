List<Map<String, dynamic>> rowsOf(Map<String, dynamic> body) {
  final data = body['data'];
  if (data is! List || data.any((row) => row is! Map<String, dynamic>)) {
    throw Exception('Expected a data array of records from PHP.');
  }
  return data.cast<Map<String, dynamic>>();
}

Map<String, dynamic> objectOf(Map<String, dynamic> body, String key) {
  final value = body[key];
  if (value is! Map<String, dynamic>) {
    throw Exception('Unexpected response from the server.');
  }
  return value;
}

int? asInt(Object? value) => value == null ? null : int.tryParse('$value');

String? asText(Object? value) {
  final text = value?.toString().trim();
  return (text == null || text.isEmpty) ? null : text;
}

bool asBool(Object? value) => value == true || value == 1 || value == '1';

String cleanError(Object error) =>
    error.toString().replaceFirst('Exception: ', '');

int requireId(Object? value, String what) {
  final id = asInt(value);
  if (id == null || id <= 0) throw FormatException('Invalid $what record.');
  return id;
}
