import '../models/feed_models.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class FeedService {
  final ApiService api;
  FeedService(this.api);

  Future<List<AnnouncementModel>> getAnnouncements() async =>
      rowsOf(await api.request('Browse/announcements'))
          .map(AnnouncementModel.fromJson)
          .toList();

  Future<List<JobModel>> getJobs() async =>
      rowsOf(await api.request('Browse/jobs')).map(JobModel.fromJson).toList();

  Future<List<EventModel>> getEvents() async =>
      rowsOf(await api.request('Browse/events'))
          .map(EventModel.fromJson)
          .toList();

  Future<void> registerForEvent(int id) =>
      api.mutate('Events/register/$id', form: const <String, String>{});

  Future<void> cancelEventRegistration(int id) =>
      api.mutate('Events/cancel/$id', form: const <String, String>{});
}
