import '../models/session_user.dart';
import 'api_service.dart';
import 'token_store.dart';

class AuthService {
  final ApiService api;
  final TokenStore tokens;
  AuthService(this.api, this.tokens);

  Future<SessionUser> login(
    String username,
    String password, {
    String deviceName = 'Alumni mobile app',
  }) async {
    final body = await api.request(
      'Auth/login',
      form: {
        'username': username,
        'password': password,
        'device_name': deviceName,
      },
    );
    final token = body['token'];
    final user = body['user'];
    if (token is! String || token.isEmpty || user is! Map<String, dynamic>) {
      throw Exception('Unexpected login response from the server.');
    }
    await tokens.write(token);
    return SessionUser.fromJson(user);
  }

  Future<SessionUser?> restore() async {
    final token = await tokens.read();
    if (token == null || token.isEmpty) return null;
    try {
      final body = await api.request('Auth/me');
      final user = body['user'];
      if (user is! Map<String, dynamic>) {
        throw Exception('Unexpected response from the server.');
      }
      return SessionUser.fromJson(user);
    } catch (_) {
      if ((await tokens.read()) == null) return null;
      rethrow;
    }
  }

  Future<void> logout() async {
    try {
      await api.mutate('Auth/logout', form: const <String, String>{});
    } catch (_) {
    } finally {
      await tokens.clear();
    }
  }
}
