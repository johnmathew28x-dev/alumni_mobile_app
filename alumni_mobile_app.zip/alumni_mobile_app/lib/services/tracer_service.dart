import '../models/tracer_models.dart';
import 'api_helpers.dart';
import 'api_service.dart';

class TracerService {
  final ApiService api;
  TracerService(this.api);

  Future<List<TracerStudyModel>> getActive() async =>
      rowsOf(await api.request('Tracer/active'))
          .map(TracerStudyModel.fromJson)
          .toList();

  Future<TracerQuestionnaire> getQuestionnaire(int studyId) async =>
      TracerQuestionnaire.fromJson(
        await api.request('Tracer/questions/$studyId'),
      );

  Future<void> submit(int studyId, Map<int, String> answers) => api.mutate(
    'Tracer/submit',
    form: {
      'tracer_study_id': '$studyId',
      for (final entry in answers.entries) 'answers[${entry.key}]': entry.value,
    },
  );
}
